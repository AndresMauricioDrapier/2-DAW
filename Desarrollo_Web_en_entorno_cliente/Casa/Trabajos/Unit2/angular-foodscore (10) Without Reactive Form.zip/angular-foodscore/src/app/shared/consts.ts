export const OPENDAYS: string[] = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
