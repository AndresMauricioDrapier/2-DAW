export interface Restaurant {
  name:string;
  image:string;
  cuisine:string;
  description:string;
  phone:string;
  daysOpen:string[];
}
