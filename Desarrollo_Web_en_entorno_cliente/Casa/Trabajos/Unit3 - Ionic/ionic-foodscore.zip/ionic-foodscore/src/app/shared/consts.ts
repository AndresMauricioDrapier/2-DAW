export const OPENDAYS: string[] = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
export const ARCGIS_TOKEN = "AAPK0080cf4d2b314a7ca365c372c5bcda77xOJKtldS42NpvMCqQsLRcwveEQDv3b7u2J0-HKKpKws9a7ovEnlHUH8bQhsMgfcd";
