"use strict";(self.webpackChunkapp=self.webpackChunkapp||[]).push([[4511],{96160:(fe,Y,v)=>{v.d(Y,{D:()=>Tt,b:()=>Oe});var y=v(62208),w=v(43703),I=v(52382),W=v(73132),V=v(13934),H=v(78925),L=v(24255),A=v(60355),S=v(26859),j=v(84833),K=v(72326),Q=v(36603),z=v(58173),Z=v(21799),te=v(52071),q=v(75958),$=v(29052),k=v(53520),J=v(36412),ie=v(31166),de=v(10109),le=v(96395),ge=v(98898),ve=v(92724),Ee=v(72968),Ce=v(70489),at=v(67938),xe=v(67022),ue=v(72397),ce=v(49974),Ke=v(99198),Je=v(97139),ke=v(69960),st=v(65787),Be=v(17625),me=v(63123),Ne=v(22355),ut=v(35387),ct=v(44835),se=v(16396);function Oe(he){const ze=new Ne.kG,{vertex:It,fragment:ht,varyings:qt}=ze;return(0,Ke.Sv)(It,he),ze.include(j.f),qt.add("vpos","vec3"),ze.include(at.k,he),ze.include(A.f,he),ze.include(te.L,he),he.hasColorTextureTransform&&ze.include(Ce.av),he.output!==V.H.Color&&he.output!==V.H.Alpha||(he.hasNormalTextureTransform&&ze.include(Ce.NI),he.hasEmissionTextureTransform&&ze.include(Ce.R5),he.hasOcclusionTextureTransform&&ze.include(Ce.jF),he.hasMetallicRoughnessTextureTransform&&ze.include(Ce.DT),(0,Ke.hY)(It,he),ze.include(S.O,he),ze.include(L.w,he),he.normalType===S.h.Attribute&&he.offsetBackfaces&&ze.include(W.w),ze.include($.Q,he),ze.include(Z.Bb,he),he.instancedColor&&ze.attributes.add(se.T.INSTANCECOLOR,"vec4"),qt.add("localvpos","vec3"),ze.include(Q.D,he),ze.include(I.qj,he),ze.include(K.R,he),ze.include(z.c,he),It.uniforms.add(new ke.N("externalColor",ye=>ye.externalColor)),qt.add("vcolorExt","vec4"),he.hasMultipassTerrain&&qt.add("depth","float"),he.hasModelTransformation&&It.uniforms.add(new me.g("model",ye=>(0,y.pC)(ye.modelTransformation)?ye.modelTransformation:w.I)),It.code.add(Be.H`
      void main(void) {
        forwardNormalizedVertexColor();
        vcolorExt = externalColor;
        ${he.instancedColor?"vcolorExt *= instanceColor;":""}
        vcolorExt *= vvColor();
        vcolorExt *= getSymbolColor();
        forwardColorMixMode();

        if (vcolorExt.a < ${Be.H.float(xe.b)}) {
          gl_Position = vec4(1e38, 1e38, 1e38, 1.0);
        } else {
          vpos = calculateVPos();
          localvpos = vpos - view[3].xyz;
          vpos = subtractOrigin(vpos);
          ${he.normalType===S.h.Attribute?Be.H`vNormalWorld = dpNormal(vvLocalNormal(normalModel()));`:""}
          vpos = addVerticalOffset(vpos, localOrigin);
          ${he.hasVertexTangents?"vTangent = dpTransformVertexTangent(tangent);":""}
          gl_Position = transformPosition(proj, view, ${he.hasModelTransformation?"model,":""} vpos);
          ${he.normalType===S.h.Attribute&&he.offsetBackfaces?"gl_Position = offsetBackfacingClipPosition(gl_Position, vpos, vNormalWorld, cameraPosition);":""}
        }

        ${he.hasMultipassTerrain?"depth = (view * vec4(vpos, 1.0)).z;":""}
        forwardLinearDepth();
        forwardTextureCoordinates();
        ${he.hasColorTextureTransform?Be.H`forwardColorUV();`:""}
        ${he.hasNormalTextureTransform?Be.H`forwardNormalUV();`:""}
        ${he.hasEmissionTextureTransform?Be.H`forwardEmissiveUV();`:""}
        ${he.hasOcclusionTextureTransform?Be.H`forwardOcclusionUV();`:""}
        ${he.hasMetallicRoughnessTextureTransform?Be.H`forwardMetallicRoughnessUV();`:""}
      }
    `)),he.output===V.H.Alpha&&(ze.include(H.f5,he),ze.include(ue.z,he),ze.include(de.l,he),ht.uniforms.add([new st.p("opacity",ye=>ye.opacity),new st.p("layerOpacity",ye=>ye.layerOpacity)]),he.hasColorTexture&&ht.uniforms.add(new ut.A("tex",ye=>ye.texture)),ht.include(ce.y),ht.code.add(Be.H`
      void main() {
        discardBySlice(vpos);
        ${he.hasMultipassTerrain?"terrainDepthTest(gl_FragCoord, depth);":""}
        ${he.hasColorTexture?Be.H`
                vec4 texColor = texture2D(tex, ${he.hasColorTextureTransform?Be.H`colorUV`:Be.H`vuv0`});
                ${he.textureAlphaPremultiplied?"texColor.rgb /= texColor.a;":""}
                discardOrAdjustAlpha(texColor);`:Be.H`vec4 texColor = vec4(1.0);`}
        ${he.hasVertexColors?Be.H`float opacity_ = layerOpacity * mixExternalOpacity(vColor.a * opacity, texColor.a, vcolorExt.a, int(colorMixMode));`:Be.H`float opacity_ = layerOpacity * mixExternalOpacity(opacity, texColor.a, vcolorExt.a, int(colorMixMode));`}
        gl_FragColor = vec4(opacity_);
      }
    `)),he.output===V.H.Color&&(ze.include(H.f5,he),ze.include(J.XP,he),ze.include(k.K,he),ze.include(ue.z,he),ze.include(he.instancedDoublePrecision?Ee.hb:Ee.XE,he),ze.include(de.l,he),(0,Ke.hY)(ht,he),ht.uniforms.add([It.uniforms.get("localOrigin"),new Je.J("ambient",ye=>ye.ambient),new Je.J("diffuse",ye=>ye.diffuse),new st.p("opacity",ye=>ye.opacity),new st.p("layerOpacity",ye=>ye.layerOpacity)]),he.hasColorTexture&&ht.uniforms.add(new ut.A("tex",ye=>ye.texture)),ze.include(ve.jV,he),ze.include(ge.T,he),ht.include(ce.y),ze.include(le.k,he),(0,J.PN)(ht),(0,J.sC)(ht),(0,ie.F1)(ht),ht.code.add(Be.H`
      void main() {
        discardBySlice(vpos);
        ${he.hasMultipassTerrain?"terrainDepthTest(gl_FragCoord, depth);":""}
        ${he.hasColorTexture?Be.H`
                vec4 texColor = texture2D(tex, ${he.hasColorTextureTransform?Be.H`colorUV`:Be.H`vuv0`});
                ${he.textureAlphaPremultiplied?"texColor.rgb /= texColor.a;":""}
                discardOrAdjustAlpha(texColor);`:Be.H`vec4 texColor = vec4(1.0);`}
        shadingParams.viewDirection = normalize(vpos - cameraPosition);
        ${he.normalType===S.h.ScreenDerivative?Be.H`
                vec3 normal = screenDerivativeNormal(localvpos);`:Be.H`
                shadingParams.normalView = vNormalWorld;
                vec3 normal = shadingNormal(shadingParams);`}
        ${he.pbrMode===ve.f7.Normal?"applyPBRFactors();":""}
        float ssao = evaluateAmbientOcclusionInverse();
        ssao *= getBakedOcclusion();

        vec3 posWorld = vpos + localOrigin;

        float additionalAmbientScale = additionalDirectedAmbientLight(posWorld);
        float shadow = ${he.receiveShadows?"readShadowMap(vpos, linearDepth)":he.spherical?"lightingGlobalFactor * (1.0 - additionalAmbientScale)":"0.0"};

        vec3 matColor = max(ambient, diffuse);
        ${he.hasVertexColors?Be.H`
                vec3 albedo = mixExternalColor(vColor.rgb * matColor, texColor.rgb, vcolorExt.rgb, int(colorMixMode));
                float opacity_ = layerOpacity * mixExternalOpacity(vColor.a * opacity, texColor.a, vcolorExt.a, int(colorMixMode));`:Be.H`
                vec3 albedo = mixExternalColor(matColor, texColor.rgb, vcolorExt.rgb, int(colorMixMode));
                float opacity_ = layerOpacity * mixExternalOpacity(opacity, texColor.a, vcolorExt.a, int(colorMixMode));`}
        ${he.hasNormalTexture?Be.H`
                mat3 tangentSpace = ${he.hasVertexTangents?"computeTangentSpace(normal);":"computeTangentSpace(normal, vpos, vuv0);"}
                vec3 shadingNormal = computeTextureNormal(tangentSpace, vuv0);`:Be.H`vec3 shadingNormal = normal;`}
        vec3 normalGround = ${he.spherical?Be.H`normalize(posWorld);`:Be.H`vec3(0.0, 0.0, 1.0);`}

        ${he.snowCover?Be.H`
                float snow = smoothstep(0.5, 0.55, dot(normal, normalGround));
                albedo = mix(albedo, vec3(1), snow);
                shadingNormal = mix(shadingNormal, normal, snow);
                ssao = mix(ssao, 1.0, snow);`:""}

        vec3 additionalLight = ssao * mainLightIntensity * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor;

        ${he.pbrMode===ve.f7.Normal||he.pbrMode===ve.f7.Schematic?Be.H`
                float additionalAmbientIrradiance = additionalAmbientIrradianceFactor * mainLightIntensity[2];
                ${he.snowCover?Be.H`
                        mrr = mix(mrr, vec3(0.0, 1.0, 0.04), snow);
                        emission = mix(emission, vec3(0.0), snow);`:""}

                vec3 shadedColor = evaluateSceneLightingPBR(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight, shadingParams.viewDirection, normalGround, mrr, emission, additionalAmbientIrradiance);`:Be.H`vec3 shadedColor = evaluateSceneLighting(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight);`}
        gl_FragColor = highlightSlice(vec4(shadedColor, opacity_), vpos);
        ${he.transparencyPassType===ct.A.Color?Be.H`gl_FragColor = premultiplyAlpha(gl_FragColor);`:""}
      }
    `)),ze.include(q.s,he),ze}const Tt=Object.freeze(Object.defineProperty({__proto__:null,build:Oe},Symbol.toStringTag,{value:"Module"}))},77133:(fe,Y,v)=>{v.d(Y,{R:()=>Be,b:()=>st});var y=v(52382),w=v(73132),I=v(13934),W=v(78925),V=v(24255),H=v(60355),L=v(26859),A=v(84833),S=v(72326),j=v(36603),K=v(58173),Q=v(52071),z=v(75958),Z=v(53520),te=v(36412),q=v(31166),$=v(10109),k=v(98898),J=v(92724),ie=v(72968),de=v(67938),le=v(67022),ge=v(72397),ve=v(49974),Ee=v(99198),Ce=v(97139),at=v(69960),xe=v(65787),ue=v(17625),ce=v(22355),Ke=v(35387),Je=v(44835),ke=v(16396);function st(me){const Ne=new ce.kG,{vertex:ut,fragment:ct,varyings:se}=Ne;return(0,Ee.Sv)(ut,me),Ne.include(A.f),se.add("vpos","vec3"),Ne.include(de.k,me),Ne.include(H.f,me),Ne.include(Q.L,me),me.output!==I.H.Color&&me.output!==I.H.Alpha||((0,Ee.hY)(Ne.vertex,me),Ne.include(L.O,me),Ne.include(V.w,me),me.offsetBackfaces&&Ne.include(w.w),me.instancedColor&&Ne.attributes.add(ke.T.INSTANCECOLOR,"vec4"),se.add("vNormalWorld","vec3"),se.add("localvpos","vec3"),me.hasMultipassTerrain&&se.add("depth","float"),Ne.include(j.D,me),Ne.include(y.qj,me),Ne.include(S.R,me),Ne.include(K.c,me),ut.uniforms.add(new at.N("externalColor",Oe=>Oe.externalColor)),se.add("vcolorExt","vec4"),ut.code.add(ue.H`
        void main(void) {
          forwardNormalizedVertexColor();
          vcolorExt = externalColor;
          ${me.instancedColor?"vcolorExt *= instanceColor;":""}
          vcolorExt *= vvColor();
          vcolorExt *= getSymbolColor();
          forwardColorMixMode();

          if (vcolorExt.a < ${ue.H.float(le.b)}) {
            gl_Position = vec4(1e38, 1e38, 1e38, 1.0);
          } else {
            vpos = calculateVPos();
            localvpos = vpos - view[3].xyz;
            vpos = subtractOrigin(vpos);
            vNormalWorld = dpNormal(vvLocalNormal(normalModel()));
            vpos = addVerticalOffset(vpos, localOrigin);
            gl_Position = transformPosition(proj, view, vpos);
            ${me.offsetBackfaces?"gl_Position = offsetBackfacingClipPosition(gl_Position, vpos, vNormalWorld, cameraPosition);":""}
          }
          ${me.hasMultipassTerrain?ue.H`depth = (view * vec4(vpos, 1.0)).z;`:""}
          forwardLinearDepth();
          forwardTextureCoordinates();
        }
      `)),me.output===I.H.Alpha&&(Ne.include(W.f5,me),Ne.include(ge.z,me),Ne.include($.l,me),ct.uniforms.add([new xe.p("opacity",Oe=>Oe.opacity),new xe.p("layerOpacity",Oe=>Oe.layerOpacity)]),me.hasColorTexture&&ct.uniforms.add(new Ke.A("tex",Oe=>Oe.texture)),ct.include(ve.y),ct.code.add(ue.H`
      void main() {
        discardBySlice(vpos);
        ${me.hasMultipassTerrain?ue.H`terrainDepthTest(gl_FragCoord, depth);`:""}
        ${me.hasColorTexture?ue.H`
                vec4 texColor = texture2D(tex, ${me.hasColorTextureTransform?ue.H`colorUV`:ue.H`vuv0`});
                ${me.textureAlphaPremultiplied?"texColor.rgb /= texColor.a;":""}
                discardOrAdjustAlpha(texColor);`:ue.H`vec4 texColor = vec4(1.0);`}
        ${me.hasVertexColors?ue.H`float opacity_ = layerOpacity * mixExternalOpacity(vColor.a * opacity, texColor.a, vcolorExt.a, int(colorMixMode));`:ue.H`float opacity_ = layerOpacity * mixExternalOpacity(opacity, texColor.a, vcolorExt.a, int(colorMixMode));`}

        gl_FragColor = vec4(opacity_);
      }
    `)),me.output===I.H.Color&&(Ne.include(W.f5,me),Ne.include(te.XP,me),Ne.include(Z.K,me),Ne.include(ge.z,me),Ne.include(me.instancedDoublePrecision?ie.hb:ie.XE,me),Ne.include($.l,me),(0,Ee.hY)(Ne.fragment,me),(0,q.Pe)(ct),(0,te.PN)(ct),(0,te.sC)(ct),ct.uniforms.add([ut.uniforms.get("localOrigin"),ut.uniforms.get("view"),new Ce.J("ambient",Oe=>Oe.ambient),new Ce.J("diffuse",Oe=>Oe.diffuse),new xe.p("opacity",Oe=>Oe.opacity),new xe.p("layerOpacity",Oe=>Oe.layerOpacity)]),me.hasColorTexture&&ct.uniforms.add(new Ke.A("tex",Oe=>Oe.texture)),Ne.include(J.jV,me),Ne.include(k.T,me),ct.include(ve.y),Ne.extensions.add("GL_OES_standard_derivatives"),(0,q.F1)(ct),ct.code.add(ue.H`
      void main() {
        discardBySlice(vpos);
        ${me.hasMultipassTerrain?ue.H`terrainDepthTest(gl_FragCoord, depth);`:""}
        ${me.hasColorTexture?ue.H`
                vec4 texColor = texture2D(tex, ${me.hasColorTextureTransform?ue.H`colorUV`:ue.H`vuv0`});
                ${me.textureAlphaPremultiplied?"texColor.rgb /= texColor.a;":""}
                discardOrAdjustAlpha(texColor);`:ue.H`vec4 texColor = vec4(1.0);`}
        vec3 viewDirection = normalize(vpos - cameraPosition);
        ${me.pbrMode===J.f7.Normal?"applyPBRFactors();":""}
        float ssao = evaluateAmbientOcclusionInverse();
        ssao *= getBakedOcclusion();

        float additionalAmbientScale = additionalDirectedAmbientLight(vpos + localOrigin);
        vec3 additionalLight = ssao * mainLightIntensity * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor;
        ${me.receiveShadows?"float shadow = readShadowMap(vpos, linearDepth);":me.spherical?"float shadow = lightingGlobalFactor * (1.0 - additionalAmbientScale);":"float shadow = 0.0;"}
        vec3 matColor = max(ambient, diffuse);
        ${me.hasVertexColors?ue.H`
                vec3 albedo = mixExternalColor(vColor.rgb * matColor, texColor.rgb, vcolorExt.rgb, int(colorMixMode));
                float opacity_ = layerOpacity * mixExternalOpacity(vColor.a * opacity, texColor.a, vcolorExt.a, int(colorMixMode));`:ue.H`
                vec3 albedo = mixExternalColor(matColor, texColor.rgb, vcolorExt.rgb, int(colorMixMode));
                float opacity_ = layerOpacity * mixExternalOpacity(opacity, texColor.a, vcolorExt.a, int(colorMixMode));`}
        ${me.snowCover?ue.H`albedo = mix(albedo, vec3(1), 0.9);`:ue.H``}
        ${ue.H`
            vec3 shadingNormal = normalize(vNormalWorld);
            albedo *= 1.2;
            vec3 viewForward = vec3(view[0][2], view[1][2], view[2][2]);
            float alignmentLightView = clamp(dot(viewForward, -mainLightDirection), 0.0, 1.0);
            float transmittance = 1.0 - clamp(dot(viewForward, shadingNormal), 0.0, 1.0);
            float treeRadialFalloff = vColor.r;
            float backLightFactor = 0.5 * treeRadialFalloff * alignmentLightView * transmittance * (1.0 - shadow);
            additionalLight += backLightFactor * mainLightIntensity;`}
        ${me.pbrMode===J.f7.Normal||me.pbrMode===J.f7.Schematic?me.spherical?ue.H`vec3 normalGround = normalize(vpos + localOrigin);`:ue.H`vec3 normalGround = vec3(0.0, 0.0, 1.0);`:ue.H``}
        ${me.pbrMode===J.f7.Normal||me.pbrMode===J.f7.Schematic?ue.H`
                float additionalAmbientIrradiance = additionalAmbientIrradianceFactor * mainLightIntensity[2];
                ${me.snowCover?ue.H`
                        mrr = vec3(0.0, 1.0, 0.04);
                        emission = vec3(0.0);`:""}

                vec3 shadedColor = evaluateSceneLightingPBR(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight, viewDirection, normalGround, mrr, emission, additionalAmbientIrradiance);`:ue.H`vec3 shadedColor = evaluateSceneLighting(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight);`}
        gl_FragColor = highlightSlice(vec4(shadedColor, opacity_), vpos);
        ${me.transparencyPassType===Je.A.Color?ue.H`gl_FragColor = premultiplyAlpha(gl_FragColor);`:ue.H``}
      }
    `)),Ne.include(z.s,me),Ne}const Be=Object.freeze(Object.defineProperty({__proto__:null,build:st},Symbol.toStringTag,{value:"Module"}))},52376:(fe,Y,v)=>{v.d(Y,{S:()=>$,b:()=>Z});var y=v(62208),w=v(67831),I=v(99770),W=v(98071),V=v(47923),H=v(39832),L=v(95285),A=v(65787),S=v(17625),j=v(22355),K=v(35387);function Z(){const k=new j.kG,J=k.fragment;return k.include(W.k),J.include(V.S),k.include(H.G),J.uniforms.add(new A.p("radius",(ie,de)=>te(de))),J.code.add(S.H`vec3 sphere[16];
void fillSphere() {
sphere[0] = vec3(0.186937, 0.0, 0.0);
sphere[1] = vec3(0.700542, 0.0, 0.0);
sphere[2] = vec3(-0.864858, -0.481795, -0.111713);
sphere[3] = vec3(-0.624773, 0.102853, -0.730153);
sphere[4] = vec3(-0.387172, 0.260319, 0.007229);
sphere[5] = vec3(-0.222367, -0.642631, -0.707697);
sphere[6] = vec3(-0.01336, -0.014956, 0.169662);
sphere[7] = vec3(0.122575, 0.1544, -0.456944);
sphere[8] = vec3(-0.177141, 0.85997, -0.42346);
sphere[9] = vec3(-0.131631, 0.814545, 0.524355);
sphere[10] = vec3(-0.779469, 0.007991, 0.624833);
sphere[11] = vec3(0.308092, 0.209288,0.35969);
sphere[12] = vec3(0.359331, -0.184533, -0.377458);
sphere[13] = vec3(0.192633, -0.482999, -0.065284);
sphere[14] = vec3(0.233538, 0.293706, -0.055139);
sphere[15] = vec3(0.417709, -0.386701, 0.442449);
}
float fallOffFunction(float vv, float vn, float bias) {
float f = max(radius * radius - vv, 0.0);
return f * f * f * max(vn-bias, 0.0);
}`),J.code.add(S.H`float aoValueFromPositionsAndNormal(vec3 C, vec3 n_C, vec3 Q) {
vec3 v = Q - C;
float vv = dot(v, v);
float vn = dot(normalize(v), n_C);
return fallOffFunction(vv, vn, 0.1);
}`),J.uniforms.add([new L.A("nearFar",(ie,de)=>de.camera.nearFar),new K.A("normalMap",ie=>ie.normalTexture),new K.A("depthMap",ie=>ie.depthTexture),new L.A("zScale",(ie,de)=>(0,H.R)(de)),new A.p("projScale",ie=>ie.projScale),new K.A("rnm",ie=>ie.noiseTexture),new L.A("rnmScale",(ie,de)=>(0,w.s)(q,de.camera.fullWidth/(0,y.Wg)(ie.noiseTexture).descriptor.width,de.camera.fullHeight/(0,y.Wg)(ie.noiseTexture).descriptor.height)),new A.p("intensity",(ie,de)=>2/te(de)**6),new L.A("screenSize",(ie,de)=>(0,w.s)(q,de.camera.fullWidth,de.camera.fullHeight))]),J.code.add(S.H`
    void main(void) {
      fillSphere();
      vec3 fres = normalize((texture2D(rnm, uv * rnmScale).xyz * 2.0) - vec3(1.0));
      float currentPixelDepth = linearDepthFromTexture(depthMap, uv, nearFar);

      if (-currentPixelDepth>nearFar.y || -currentPixelDepth<nearFar.x) {
        gl_FragColor = vec4(0.0);
        return;
      }

      vec3 currentPixelPos = reconstructPosition(gl_FragCoord.xy,currentPixelDepth);

      // get the normal of current fragment
      vec4 norm4 = texture2D(normalMap, uv);
      vec3 norm = vec3(-1.0) + 2.0 * norm4.xyz;
      bool isTerrain = norm4.w<0.5;

      float sum = .0;
      vec3 tapPixelPos;

      // note: the factor 2.0 should not be necessary, but makes ssao much nicer.
      // bug or deviation from CE somewhere else?
      float ps = projScale / (2.0 * currentPixelPos.z * zScale.x + zScale.y);

      for(int i = 0; i < ${S.H.int(16)}; ++i) {
        vec2 unitOffset = reflect(sphere[i], fres).xy;
        vec2 offset = vec2(-unitOffset * radius * ps);

        //don't use current or very nearby samples
        if ( abs(offset.x)<2.0 || abs(offset.y)<2.0) continue;

        vec2 tc = vec2(gl_FragCoord.xy + offset);
        if (tc.x < 0.0 || tc.y < 0.0 || tc.x > screenSize.x || tc.y > screenSize.y) continue;
        vec2 tcTap = tc / screenSize;
        float occluderFragmentDepth = linearDepthFromTexture(depthMap, tcTap, nearFar);

        if (isTerrain) {
          bool isTerrainTap = texture2D(normalMap, tcTap).w<0.5;
          if (isTerrainTap) {
            continue;
          }
        }

        tapPixelPos = reconstructPosition(tc, occluderFragmentDepth);

        sum+= aoValueFromPositionsAndNormal(currentPixelPos, norm, tapPixelPos);
      }

      // output the result
      float A = max(1.0 - sum * intensity / float(${S.H.int(16)}),0.0);

      // Anti-tone map to reduce contrast and drag dark region farther: (x^0.2 + 1.2 * x^4)/2.2
      A = (pow(A, 0.2) + 1.2 * A*A*A*A) / 2.2;
      gl_FragColor = vec4(A);
    }
  `),k}function te(k){return Math.max(10,20*k.camera.computeRenderPixelSizeAtDist(Math.abs(4*k.camera.relativeElevation)))}const q=(0,I.a)(),$=Object.freeze(Object.defineProperty({__proto__:null,build:Z},Symbol.toStringTag,{value:"Module"}))},86962:(fe,Y,v)=>{v.d(Y,{S:()=>z,b:()=>Q});var y=v(84161),w=v(98071),I=v(47923),W=v(32181),V=v(95285),H=v(65787),L=v(17625),A=v(22355),S=v(5864),j=v(35387);function Q(){const Z=new A.kG,te=Z.fragment;return Z.include(w.k),te.include(I.S),te.uniforms.add([new j.A("depthMap",k=>k.depthTexture),new S.R("tex",k=>k.colorTexture),new W.q("blurSize",k=>k.blurSize),new H.p("projScale",(k,J)=>{const ie=(0,y.i)(J.camera.eye,J.camera.center);return ie>5e4?Math.max(0,k.projScale-(ie-5e4)):k.projScale}),new V.A("nearFar",(k,J)=>J.camera.nearFar)]),te.code.add(L.H`
    void blurFunction(vec2 uv, float r, float center_d, float sharpness, inout float wTotal, inout float bTotal) {
      float c = texture2D(tex, uv).r;
      float d = linearDepthFromTexture(depthMap, uv, nearFar);

      float ddiff = d - center_d;

      float w = exp(-r * r * ${L.H.float(.08)} - ddiff * ddiff * sharpness);
      wTotal += w;
      bTotal += w * c;
    }
  `),te.code.add(L.H`
    void main(void) {
      float b = 0.0;
      float w_total = 0.0;

      float center_d = linearDepthFromTexture(depthMap, uv, nearFar);

      float sharpness = -0.05 * projScale / center_d;
      for (int r = -${L.H.int(4)}; r <= ${L.H.int(4)}; ++r) {
        float rf = float(r);
        vec2 uvOffset = uv + rf * blurSize;
        blurFunction(uvOffset, rf, center_d, sharpness, w_total, b);
      }

      gl_FragColor = vec4(b / w_total);
    }
  `),Z}const z=Object.freeze(Object.defineProperty({__proto__:null,build:Q},Symbol.toStringTag,{value:"Module"}))},9545:(fe,Y,v)=>{function y(){return new Float32Array(2)}function I(Z,te){const q=new Float32Array(2);return q[0]=Z,q[1]=te,q}function V(){return y()}function H(){return I(1,1)}function L(){return I(1,0)}function A(){return I(0,1)}v.d(Y,{O:()=>j,Z:()=>S,c:()=>y,f:()=>I});const S=V(),j=H(),K=L(),Q=A();Object.freeze(Object.defineProperty({__proto__:null,create:y,clone:function w(Z){const te=new Float32Array(2);return te[0]=Z[0],te[1]=Z[1],te},fromValues:I,createView:function W(Z,te){return new Float32Array(Z,te,2)},zeros:V,ones:H,unitX:L,unitY:A,ZEROS:S,ONES:j,UNIT_X:K,UNIT_Y:Q},Symbol.toStringTag,{value:"Module"}))},79800:(fe,Y,v)=>{v.d(Y,{a:()=>I,b:()=>H,n:()=>V,s:()=>W,t:()=>w});var y=v(96286);function w(A,S,j){if(A.count!==S.count)return void y.c.error("source and destination buffers need to have the same number of elements");const K=A.count,Q=j[0],z=j[1],Z=j[2],te=j[4],q=j[5],$=j[6],k=j[8],J=j[9],ie=j[10],de=j[12],le=j[13],ge=j[14],ve=A.typedBuffer,Ee=A.typedBufferStride,Ce=S.typedBuffer,at=S.typedBufferStride;for(let xe=0;xe<K;xe++){const ue=xe*Ee,ce=xe*at,Ke=Ce[ce],Je=Ce[ce+1],ke=Ce[ce+2];ve[ue]=Q*Ke+te*Je+k*ke+de,ve[ue+1]=z*Ke+q*Je+J*ke+le,ve[ue+2]=Z*Ke+$*Je+ie*ke+ge}}function I(A,S,j){if(A.count!==S.count)return void y.c.error("source and destination buffers need to have the same number of elements");const K=A.count,Q=j[0],z=j[1],Z=j[2],te=j[3],q=j[4],$=j[5],k=j[6],J=j[7],ie=j[8],de=A.typedBuffer,le=A.typedBufferStride,ge=S.typedBuffer,ve=S.typedBufferStride;for(let Ee=0;Ee<K;Ee++){const Ce=Ee*le,at=Ee*ve,xe=ge[at],ue=ge[at+1],ce=ge[at+2];de[Ce]=Q*xe+te*ue+k*ce,de[Ce+1]=z*xe+q*ue+J*ce,de[Ce+2]=Z*xe+$*ue+ie*ce}}function W(A,S,j){const K=Math.min(A.count,S.count),Q=A.typedBuffer,z=A.typedBufferStride,Z=S.typedBuffer,te=S.typedBufferStride;for(let q=0;q<K;q++){const $=q*z,k=q*te;Q[$]=j*Z[k],Q[$+1]=j*Z[k+1],Q[$+2]=j*Z[k+2]}}function V(A,S){const j=Math.min(A.count,S.count),K=A.typedBuffer,Q=A.typedBufferStride,z=S.typedBuffer,Z=S.typedBufferStride;for(let te=0;te<j;te++){const q=te*Q,$=te*Z,k=z[$],J=z[$+1],ie=z[$+2],de=k*k+J*J+ie*ie;if(de>0){const le=1/Math.sqrt(de);K[q]=le*k,K[q+1]=le*J,K[q+2]=le*ie}}}function H(A,S,j){const K=Math.min(A.count,S.count),Q=A.typedBuffer,z=A.typedBufferStride,Z=S.typedBuffer,te=S.typedBufferStride;for(let q=0;q<K;q++){const $=q*z,k=q*te;Q[$]=Z[k]>>j,Q[$+1]=Z[k+1]>>j,Q[$+2]=Z[k+2]>>j}}Object.freeze(Object.defineProperty({__proto__:null,transformMat4:w,transformMat3:I,scale:W,normalize:V,shiftRight:H},Symbol.toStringTag,{value:"Module"}))},9554:(fe,Y,v)=>{function y(W,V,H){const L=W.typedBuffer,A=W.typedBufferStride,S=V.typedBuffer,j=V.typedBufferStride,K=H?H.count:V.count;let Q=(H&&H.dstIndex?H.dstIndex:0)*A,z=(H&&H.srcIndex?H.srcIndex:0)*j;for(let Z=0;Z<K;++Z)L[Q]=S[z],L[Q+1]=S[z+1],L[Q+2]=S[z+2],Q+=A,z+=j}function w(W,V,H,L,A){var S,j;const K=W.typedBuffer,Q=W.typedBufferStride,z=null!==(S=null==A?void 0:A.count)&&void 0!==S?S:W.count;let Z=(null!==(j=null==A?void 0:A.dstIndex)&&void 0!==j?j:0)*Q;for(let te=0;te<z;++te)K[Z]=V,K[Z+1]=H,K[Z+2]=L,Z+=Q}v.d(Y,{c:()=>y,f:()=>w}),Object.freeze(Object.defineProperty({__proto__:null,copy:y,fill:w},Symbol.toStringTag,{value:"Module"}))},4794:(fe,Y,v)=>{function y(){return[0,0,0,0]}function I(J,ie,de,le){return[J,ie,de,le]}function V(J,ie){return new Float64Array(J,ie,4)}function L(){return I(1,1,1,1)}function A(){return I(1,0,0,0)}function S(){return I(0,1,0,0)}function j(){return I(0,0,1,0)}function K(){return I(0,0,0,1)}v.d(Y,{a:()=>V,c:()=>y,f:()=>I});const z=L(),Z=A(),te=S(),q=j(),$=K();Object.freeze(Object.defineProperty({__proto__:null,create:y,clone:function w(J){return[J[0],J[1],J[2],J[3]]},fromValues:I,fromArray:function W(J){const ie=[0,0,0,0],de=Math.min(4,J.length);for(let le=0;le<de;++le)ie[le]=J[le];return ie},createView:V,zeros:function H(){return[0,0,0,0]},ones:L,unitX:A,unitY:S,unitZ:j,unitW:K,ZEROS:[0,0,0,0],ONES:z,UNIT_X:Z,UNIT_Y:te,UNIT_Z:q,UNIT_W:$},Symbol.toStringTag,{value:"Module"}))},83100:(fe,Y,v)=>{function y(S){return S=S||globalThis.location.hostname,A.some(j=>{var K;return null!=(null===(K=S)||void 0===K?void 0:K.match(j))})}function w(S,j){return S&&(j=j||globalThis.location.hostname)?null!=j.match(W)||null!=j.match(H)?S.replace("static.arcgis.com","staticdev.arcgis.com"):null!=j.match(V)||null!=j.match(L)?S.replace("static.arcgis.com","staticqa.arcgis.com"):S:S}v.d(Y,{XO:()=>y,pJ:()=>w});const W=/^devext.arcgis.com$/,V=/^qaext.arcgis.com$/,H=/^[\w-]*\.mapsdevext.arcgis.com$/,L=/^[\w-]*\.mapsqa.arcgis.com$/,A=[/^([\w-]*\.)?[\w-]*\.zrh-dev-local.esri.com$/,W,V,/^jsapps.esri.com$/,H,L]},96286:(fe,Y,v)=>{v.d(Y,{c:()=>w});const w=v(63290).Z.getLogger("esri.views.3d.support.buffer.math")},84511:(fe,Y,v)=>{v.r(Y),v.d(Y,{fetch:()=>vs,gltfToEngineResources:()=>ti,parseUrl:()=>ei});var y=v(15861),w=v(83100),I=v(62208),W=v(30217),V=v(550),H=v(28347),L=v(43703),A=v(84161),S=v(28093),j=v(5548),K=v(60479),Q=v(79800),z=v(63657),Z=v(60490),te=v(9160),q=v(93831),$=v(96170),k=v(49966),J=v(9545);function ie(M){if((0,I.Wi)(M))return null;const x=(0,I.pC)(M.offset)?M.offset:J.Z,C=(0,I.pC)(M.rotation)?M.rotation:0,D=(0,I.pC)(M.scale)?M.scale:J.O,R=(0,k.f)(1,0,0,0,1,0,x[0],x[1],1),N=(0,k.f)(Math.cos(C),-Math.sin(C),0,Math.sin(C),Math.cos(C),0,0,0,1),U=(0,k.f)(D[0],0,0,0,D[1],0,0,0,1),G=(0,k.c)();return(0,W.m)(G,N,U),(0,W.m)(G,R,G),G}class de{constructor(x,C,D,R,N){this.name=x,this.stageResources=C,this.lodThreshold=D,this.pivotOffset=R,this.numberOfVertices=N}}var le=v(84792),ge=v(59213),ve=v(27306),Ee=v(26584),Ce=v(63290),at=v(10699),xe=v(10349),ue=v(70026),ce=v(42743),Ke=v(77029),Je=v(2282);class ke{constructor(x,C,D,R){this.primitiveIndices=x,this._numIndexPerPrimitive=C,this.indices=D,this.position=R,this.center=(0,S.c)(),this._children=void 0,(0,Je.hu)(x.length>=1),(0,Je.hu)(D.length%this._numIndexPerPrimitive==0),(0,Je.hu)(D.length>=x.length*this._numIndexPerPrimitive),(0,Je.hu)(3===R.size||4===R.size);const{data:N,size:U}=R,G=x.length;let ee=U*D[this._numIndexPerPrimitive*x[0]];st.clear(),st.push(ee),this.bbMin=(0,S.f)(N[ee],N[ee+1],N[ee+2]),this.bbMax=(0,S.a)(this.bbMin);for(let ae=0;ae<G;++ae){const Te=this._numIndexPerPrimitive*x[ae];for(let Ie=0;Ie<this._numIndexPerPrimitive;++Ie){ee=U*D[Te+Ie],st.push(ee);let Le=N[ee];this.bbMin[0]=Math.min(Le,this.bbMin[0]),this.bbMax[0]=Math.max(Le,this.bbMax[0]),Le=N[ee+1],this.bbMin[1]=Math.min(Le,this.bbMin[1]),this.bbMax[1]=Math.max(Le,this.bbMax[1]),Le=N[ee+2],this.bbMin[2]=Math.min(Le,this.bbMin[2]),this.bbMax[2]=Math.max(Le,this.bbMax[2])}}(0,A.h)(this.center,this.bbMin,this.bbMax,.5),this.radius=.5*Math.max(Math.max(this.bbMax[0]-this.bbMin[0],this.bbMax[1]-this.bbMin[1]),this.bbMax[2]-this.bbMin[2]);let X=this.radius*this.radius;for(let ae=0;ae<st.length;++ae){ee=st.getItemAt(ae);const Te=N[ee]-this.center[0],Ie=N[ee+1]-this.center[1],Le=N[ee+2]-this.center[2],Fe=Te*Te+Ie*Ie+Le*Le;if(Fe<=X)continue;const Ye=Math.sqrt(Fe),Ue=.5*(Ye-this.radius);this.radius=this.radius+Ue,X=this.radius*this.radius;const $e=Ue/Ye;this.center[0]+=Te*$e,this.center[1]+=Ie*$e,this.center[2]+=Le*$e}st.clear()}getCenter(){return this.center}getBSRadius(){return this.radius}getBBMin(){return this.bbMin}getBBMax(){return this.bbMax}getChildren(){if(this._children)return this._children;if((0,A.d)(this.bbMin,this.bbMax)>1){const x=(0,A.h)((0,S.c)(),this.bbMin,this.bbMax,.5),C=this.primitiveIndices.length,D=new Uint8Array(C),R=new Array(8);for(let X=0;X<8;++X)R[X]=0;const{data:N,size:U}=this.position;for(let X=0;X<C;++X){let ae=0;const Te=this._numIndexPerPrimitive*this.primitiveIndices[X];let Ie=U*this.indices[Te],Le=N[Ie],Fe=N[Ie+1],Ye=N[Ie+2];for(let Ue=1;Ue<this._numIndexPerPrimitive;++Ue){Ie=U*this.indices[Te+Ue];const $e=N[Ie],De=N[Ie+1],ot=N[Ie+2];$e<Le&&(Le=$e),De<Fe&&(Fe=De),ot<Ye&&(Ye=ot)}Le<x[0]&&(ae|=1),Fe<x[1]&&(ae|=2),Ye<x[2]&&(ae|=4),D[X]=ae,++R[ae]}let G=0;for(let X=0;X<8;++X)R[X]>0&&++G;if(G<2)return;const ee=new Array(8);for(let X=0;X<8;++X)ee[X]=R[X]>0?new Uint32Array(R[X]):void 0;for(let X=0;X<8;++X)R[X]=0;for(let X=0;X<C;++X){const ae=D[X];ee[ae][R[ae]++]=this.primitiveIndices[X]}this._children=new Array(8);for(let X=0;X<8;++X)void 0!==ee[X]&&(this._children[X]=new ke(ee[X],this._numIndexPerPrimitive,this.indices,this.position))}return this._children}static prune(){st.prune()}}const st=new Ke.Z({deallocator:null});var Be=v(12699),me=v(24425),Ne=v(97535),ut=v(10992);function ye(M,x,C){return(0,A.b)(He,x,M),(0,A.b)(Se,C,M),(0,A.l)((0,A.f)(He,He,Se))/2}v(26242),new Ne.x(ut.Ue),new Ne.x(()=>function se(M){return M?{p0:(0,S.a)(M.p0),p1:(0,S.a)(M.p1),p2:(0,S.a)(M.p2)}:{p0:(0,S.c)(),p1:(0,S.c)(),p2:(0,S.c)()}}());const He=(0,S.c)(),Se=(0,S.c)(),Qe=(0,S.c)(),Jt=(0,S.c)(),ne=(0,S.c)(),oe=(0,S.c)();var _e=v(37187),re=v(16396);class Ae extends Be.c{constructor(x,C=[],D=ce.MX.Triangle,R=null,N=-1){super(),this._primitiveType=D,this.objectAndLayerIdColor=R,this.edgeIndicesLength=N,this.type=me.U.Geometry,this._vertexAttributes=new Map,this._indices=new Map,this._boundingInfo=null;for(const[U,G]of x)G&&this._vertexAttributes.set(U,{...G});if(null==C||0===C.length){const U=function et(M){const x=M.values().next().value;return null==x?0:x.data.length/x.size}(this._vertexAttributes),G=(0,_e.p)(U);this.edgeIndicesLength=this.edgeIndicesLength<0?U:this.edgeIndicesLength;for(const ee of this._vertexAttributes.keys())this._indices.set(ee,G)}else for(const[U,G]of C)G&&(this._indices.set(U,(0,_e.mi)(G)),U===re.T.POSITION&&(this.edgeIndicesLength=this.edgeIndicesLength<0?this._indices.get(U).length:this.edgeIndicesLength))}cloneShallow(){const x=new Ae([],void 0,this._primitiveType,this.objectAndLayerIdColor,void 0),{_vertexAttributes:C,_indices:D}=x;return this._vertexAttributes.forEach((R,N)=>C.set(N,R)),this._indices.forEach((R,N)=>D.set(N,R)),x.screenToWorldRatio=this.screenToWorldRatio,x._boundingInfo=this._boundingInfo,x}get vertexAttributes(){return this._vertexAttributes}getMutableAttribute(x){const C=this._vertexAttributes.get(x);return C&&!C.exclusive&&(C.data=Array.from(C.data),C.exclusive=!0),C}get indices(){return this._indices}get indexCount(){const x=this._indices.values().next().value;return x?x.length:0}get primitiveType(){return this._primitiveType}get faceCount(){return this.indexCount/3}get boundingInfo(){return(0,I.Wi)(this._boundingInfo)&&(this._boundingInfo=this._calculateBoundingInfo()),this._boundingInfo}computeAttachmentOrigin(x){return this.primitiveType===ce.MX.Triangle?this._computeAttachmentOriginTriangles(x):this._computeAttachmentOriginPoints(x)}_computeAttachmentOriginTriangles(x){const C=this.indices.get(re.T.POSITION);return function Pe(M,x,C){if(!M||!x)return!1;const{size:D,data:R}=M;(0,A.s)(C,0,0,0),(0,A.s)(oe,0,0,0);let N=0,U=0;for(let G=0;G<x.length-2;G+=3){const ee=x[G+0]*D,X=x[G+1]*D,ae=x[G+2]*D;(0,A.s)(Qe,R[ee+0],R[ee+1],R[ee+2]),(0,A.s)(Jt,R[X+0],R[X+1],R[X+2]),(0,A.s)(ne,R[ae+0],R[ae+1],R[ae+2]);const Te=ye(Qe,Jt,ne);Te?((0,A.a)(Qe,Qe,Jt),(0,A.a)(Qe,Qe,ne),(0,A.g)(Qe,Qe,1/3*Te),(0,A.a)(C,C,Qe),N+=Te):((0,A.a)(oe,oe,Qe),(0,A.a)(oe,oe,Jt),(0,A.a)(oe,oe,ne),U+=3)}return!(0===U&&0===N||(0!==N?((0,A.g)(C,C,1/N),0):0===U||((0,A.g)(C,oe,1/U),0)))}(this.vertexAttributes.get(re.T.POSITION),C,x)}_computeAttachmentOriginPoints(x){const C=this.indices.get(re.T.POSITION);return function At(M,x,C){if(!M||!x)return!1;const{size:D,data:R}=M;(0,A.s)(C,0,0,0);let N=-1,U=0;for(let G=0;G<x.length;G++){const ee=x[G]*D;N!==ee&&(C[0]+=R[ee+0],C[1]+=R[ee+1],C[2]+=R[ee+2],U++),N=ee}return U>1&&(0,A.g)(C,C,1/U),U>0}(this.vertexAttributes.get(re.T.POSITION),C,x)}invalidateBoundingInfo(){this._boundingInfo=null}_calculateBoundingInfo(){const x=this.indices.get(re.T.POSITION);if(!x||0===x.length)return null;const C=this.primitiveType===ce.MX.Triangle?3:1;(0,Je.hu)(x.length%C==0,"Indexing error: "+x.length+" not divisible by "+C);const D=(0,_e.p)(x.length/C),R=this.vertexAttributes.get(re.T.POSITION);return R?new ke(D,C,x,R):null}}var tt=v(94573),Xe=v(61885),rt=v(21286),Ge=v(55713),dt=v(21726),mt=v(33899),ft=v(4794),Ht=v(98071),Ot=v(69960),Ct=v(17625),Ut=v(22355),xt=v(35387);class jt extends Ct.K{constructor(){super(...arguments),this.color=(0,ft.f)(1,1,1,1)}}Object.freeze(Object.defineProperty({__proto__:null,TextureOnlyPassParameters:jt,build:function gt(){const M=new Ut.kG;return M.include(Ht.k),M.fragment.uniforms.add([new xt.A("tex",x=>x.texture),new Ot.N("uColor",x=>x.color)]),M.fragment.code.add(Ct.H`void main() {
vec4 texColor = texture2D(tex, uv);
gl_FragColor = texColor * uColor;
}`),M}},Symbol.toStringTag,{value:"Module"}));var Dt=v(54346);function yt(){if((0,I.Wi)(St)){const M=x=>(0,Dt.V)(`esri/libs/basisu/${x}`);St=v.e(2405).then(v.bind(v,52405)).then(x=>x.b).then(({default:x})=>x({locateFile:M}).then(C=>(C.initializeBasis(),delete C.then,C)))}return St}let St;var bt,M;(M=bt||(bt={}))[M.ETC1_RGB=0]="ETC1_RGB",M[M.ETC2_RGBA=1]="ETC2_RGBA",M[M.BC1_RGB=2]="BC1_RGB",M[M.BC3_RGBA=3]="BC3_RGBA",M[M.BC4_R=4]="BC4_R",M[M.BC5_RG=5]="BC5_RG",M[M.BC7_M6_RGB=6]="BC7_M6_RGB",M[M.BC7_M5_RGBA=7]="BC7_M5_RGBA",M[M.PVRTC1_4_RGB=8]="PVRTC1_4_RGB",M[M.PVRTC1_4_RGBA=9]="PVRTC1_4_RGBA",M[M.ASTC_4x4_RGBA=10]="ASTC_4x4_RGBA",M[M.ATC_RGB=11]="ATC_RGB",M[M.ATC_RGBA=12]="ATC_RGBA",M[M.FXT1_RGB=17]="FXT1_RGB",M[M.PVRTC2_4_RGB=18]="PVRTC2_4_RGB",M[M.PVRTC2_4_RGBA=19]="PVRTC2_4_RGBA",M[M.ETC2_EAC_R11=20]="ETC2_EAC_R11",M[M.ETC2_EAC_RG11=21]="ETC2_EAC_RG11",M[M.RGBA32=13]="RGBA32",M[M.RGB565=14]="RGB565",M[M.BGR565=15]="BGR565",M[M.RGBA4444=16]="RGBA4444";var be=v(67969),Lt=v(55086),er=v(26906);let Pt=null,Wt=null;function Gt(){return zt.apply(this,arguments)}function zt(){return(zt=(0,y.Z)(function*(){return(0,I.Wi)(Wt)&&(Wt=yt(),Pt=yield Wt),Wt})).apply(this,arguments)}function Kt(M,x,C,D,R){const N=(0,er.RG)(x?be.q_.COMPRESSED_RGBA8_ETC2_EAC:be.q_.COMPRESSED_RGB8_ETC2);return Math.ceil(C*D*N*(R&&M>1?(4**M-1)/(3*4**(M-1)):1))}function tr(M){return M.getNumImages()>=1&&!M.isUASTC()}function ar(M){return M.getFaces()>=1&&M.isETC1S()}function wt(){return wt=(0,y.Z)(function*(M,x,C){(0,I.Wi)(Pt)&&(Pt=yield Gt());const D=new Pt.BasisFile(new Uint8Array(C));if(!tr(D))return null;D.startTranscoding();const R=rr(M,x,D.getNumLevels(0),D.getHasAlpha(),D.getImageWidth(0,0),D.getImageHeight(0,0),(N,U)=>D.getImageTranscodedSizeInBytes(0,N,U),(N,U,G)=>D.transcodeImage(G,0,N,U,0,0));return D.close(),D.delete(),R}),wt.apply(this,arguments)}function Zt(){return Zt=(0,y.Z)(function*(M,x,C){(0,I.Wi)(Pt)&&(Pt=yield Gt());const D=new Pt.KTX2File(new Uint8Array(C));if(!ar(D))return null;D.startTranscoding();const R=rr(M,x,D.getLevels(),D.getHasAlpha(),D.getWidth(),D.getHeight(),(N,U)=>D.getImageTranscodedSizeInBytes(N,0,0,U),(N,U,G)=>D.transcodeImage(G,N,0,0,U,0,-1,-1));return D.close(),D.delete(),R}),Zt.apply(this,arguments)}function rr(M,x,C,D,R,N,U,G){const{compressedTextureETC:ee,compressedTextureS3TC:X}=M.capabilities,[ae,Te]=ee?D?[bt.ETC2_RGBA,be.q_.COMPRESSED_RGBA8_ETC2_EAC]:[bt.ETC1_RGB,be.q_.COMPRESSED_RGB8_ETC2]:X?D?[bt.BC3_RGBA,be.q_.COMPRESSED_RGBA_S3TC_DXT5_EXT]:[bt.BC1_RGB,be.q_.COMPRESSED_RGB_S3TC_DXT1_EXT]:[bt.RGBA32,be.VI.RGBA],Ie=x.hasMipmap?C:Math.min(1,C),Le=[];for(let $e=0;$e<Ie;$e++)Le.push(new Uint8Array(U($e,ae))),G($e,ae,Le[$e]);const Fe=Le.length>1,Ye=Fe?be.cw.LINEAR_MIPMAP_LINEAR:be.cw.LINEAR,Ue={...x,samplingMode:Ye,hasMipmap:Fe,internalFormat:Te,width:R,height:N};return new Lt.x(M,Ue,{type:"compressed",levels:Le})}const Rt=Ce.Z.getLogger("esri.views.3d.webgl-engine.lib.DDSUtil");function kt(M){return M.charCodeAt(0)+(M.charCodeAt(1)<<8)+(M.charCodeAt(2)<<16)+(M.charCodeAt(3)<<24)}const Mr=kt("DXT1"),ri=kt("DXT3"),ii=kt("DXT5");var vr,fi=v(12155),vi=v(85775),gi=v(38210);class Nt extends Be.c{constructor(x,C){super(),this._data=x,this.type=me.U.Texture,this._glTexture=null,this._powerOfTwoStretchInfo=null,this._loadingPromise=null,this._loadingController=null,this.events=new Xe.Z,this._passParameters=new jt,this.params=C||{},this.params.mipmap=!1!==this.params.mipmap,this.params.noUnpackFlip=this.params.noUnpackFlip||!1,this.params.preMultiplyAlpha=this.params.preMultiplyAlpha||!1,this.params.wrap=this.params.wrap||{s:be.e8.REPEAT,t:be.e8.REPEAT},this.params.powerOfTwoResizeMode=this.params.powerOfTwoResizeMode||ce.CE.STRETCH,this.estimatedTexMemRequired=Nt._estimateTexMemRequired(this._data,this.params),this._startPreload()}_startPreload(){const x=this._data;(0,I.Wi)(x)||(x instanceof HTMLVideoElement?this._startPreloadVideoElement(x):x instanceof HTMLImageElement&&this._startPreloadImageElement(x))}_startPreloadVideoElement(x){if(!((0,dt.jc)(x.src)||"auto"===x.preload&&x.crossOrigin)){x.preload="auto",x.crossOrigin="anonymous";const C=!x.paused;if(x.src=x.src,C&&x.autoplay){const D=()=>{x.removeEventListener("canplay",D),x.play()};x.addEventListener("canplay",D)}}}_startPreloadImageElement(x){(0,dt.HK)(x.src)||(0,dt.jc)(x.src)||x.crossOrigin||(x.crossOrigin="anonymous",x.src=x.src)}static _getDataDimensions(x){return x instanceof HTMLVideoElement?{width:x.videoWidth,height:x.videoHeight}:x}static _estimateTexMemRequired(x,C){if((0,I.Wi)(x))return 0;if((0,Ge.eP)(x)||(0,Ge.lq)(x))return C.encoding===Nt.KTX2_ENCODING?function Yt(M,x){if((0,I.Wi)(Pt))return M.byteLength;const C=new Pt.KTX2File(new Uint8Array(M)),D=ar(C)?Kt(C.getLevels(),C.getHasAlpha(),C.getWidth(),C.getHeight(),x):0;return C.close(),C.delete(),D}(x,C.mipmap):C.encoding===Nt.BASIS_ENCODING?function Xt(M,x){if((0,I.Wi)(Pt))return M.byteLength;const C=new Pt.BasisFile(new Uint8Array(M)),D=tr(C)?Kt(C.getNumLevels(0),C.getHasAlpha(),C.getImageWidth(0,0),C.getImageHeight(0,0),x):0;return C.close(),C.delete(),D}(x,C.mipmap):x.byteLength;const{width:D,height:R}=x instanceof Image||x instanceof ImageData||x instanceof HTMLCanvasElement||x instanceof HTMLVideoElement?Nt._getDataDimensions(x):C;return(C.mipmap?4/3:1)*D*R*(C.components||4)||0}dispose(){this._data=void 0}get width(){return this.params.width}get height(){return this.params.height}_createDescriptor(x){var C;return{target:be.No.TEXTURE_2D,pixelFormat:be.VI.RGBA,dataType:be.Br.UNSIGNED_BYTE,wrapMode:this.params.wrap,flipped:!this.params.noUnpackFlip,samplingMode:this.params.mipmap?be.cw.LINEAR_MIPMAP_LINEAR:be.cw.LINEAR,hasMipmap:this.params.mipmap,preMultiplyAlpha:this.params.preMultiplyAlpha,maxAnisotropy:null!==(C=this.params.maxAnisotropy)&&void 0!==C?C:this.params.mipmap?x.parameters.maxMaxAnisotropy:1}}get glTexture(){return this._glTexture}load(x,C){if((0,I.pC)(this._glTexture))return this._glTexture;if((0,I.pC)(this._loadingPromise))return this._loadingPromise;const D=this._data;return(0,I.Wi)(D)?(this._glTexture=new Lt.x(x,this._createDescriptor(x),null),this._glTexture):"string"==typeof D?this._loadFromURL(x,C,D):D instanceof Image?this._loadFromImageElement(x,C,D):D instanceof HTMLVideoElement?this._loadFromVideoElement(x,C,D):D instanceof ImageData||D instanceof HTMLCanvasElement?this._loadFromImage(x,D,C):((0,Ge.eP)(D)||(0,Ge.lq)(D))&&this.params.encoding===Nt.DDS_ENCODING?(this._data=void 0,this._loadFromDDSData(x,D)):((0,Ge.eP)(D)||(0,Ge.lq)(D))&&this.params.encoding===Nt.KTX2_ENCODING?(this._data=void 0,this._loadFromKTX2(x,D)):((0,Ge.eP)(D)||(0,Ge.lq)(D))&&this.params.encoding===Nt.BASIS_ENCODING?(this._data=void 0,this._loadFromBasis(x,D)):(0,Ge.lq)(D)?this._loadFromPixelData(x,D):(0,Ge.eP)(D)?this._loadFromPixelData(x,new Uint8Array(D)):null}get requiresFrameUpdates(){return this._data instanceof HTMLVideoElement}frameUpdate(x,C,D){if(!(this._data instanceof HTMLVideoElement)||(0,I.Wi)(this._glTexture)||this._data.readyState<vr.HAVE_CURRENT_DATA||D===this._data.currentTime)return D;if((0,I.pC)(this._powerOfTwoStretchInfo)){const{framebuffer:R,vao:N,sourceTexture:U}=this._powerOfTwoStretchInfo;U.setData(this._data),this._drawStretchedTexture(x,C,R,N,U,this._glTexture)}else{const{videoWidth:R,videoHeight:N}=this._data,{width:U,height:G}=this._glTexture.descriptor;R!==U||N!==G?this._glTexture.updateData(0,0,0,Math.min(R,U),Math.min(N,G),this._data):this._glTexture.setData(this._data)}return this._glTexture.descriptor.hasMipmap&&this._glTexture.generateMipmap(),this.params.updateCallback&&this.params.updateCallback(),this._data.currentTime}_loadFromDDSData(x,C){return this._glTexture=function _i(M,x,C){var D;const{textureData:R,internalFormat:N,width:U,height:G}=(0,I.s3)(function mi(M,x){const C=new Int32Array(M,0,31);if(542327876!==C[0])return Rt.error("Invalid magic number in DDS header"),null;if(!(4&C[20]))return Rt.error("Unsupported format, must contain a FourCC code"),null;const D=C[21];let R,N;switch(D){case Mr:R=8,N=be.q_.COMPRESSED_RGB_S3TC_DXT1_EXT;break;case ri:R=16,N=be.q_.COMPRESSED_RGBA_S3TC_DXT3_EXT;break;case ii:R=16,N=be.q_.COMPRESSED_RGBA_S3TC_DXT5_EXT;break;default:return Rt.error("Unsupported FourCC code:",function ir(M){return String.fromCharCode(255&M,M>>8&255,M>>16&255,M>>24&255)}(D)),null}let U=1,G=C[4],ee=C[3];!(3&G)&&!(3&ee)||(Rt.warn("Rounding up compressed texture size to nearest multiple of 4."),G=G+3&-4,ee=ee+3&-4);const X=G,ae=ee;let Te,Ie;131072&C[2]&&!1!==x&&(U=Math.max(1,C[7])),1===U||(0,rt.wt)(G)&&(0,rt.wt)(ee)||(Rt.warn("Ignoring mipmaps of non power of two sized compressed texture."),U=1);let Le=C[1]+4;const Fe=[];for(let Ye=0;Ye<U;++Ye)Ie=(G+3>>2)*(ee+3>>2)*R,Te=new Uint8Array(M,Le,Ie),Fe.push(Te),Le+=Ie,G=Math.max(1,G>>1),ee=Math.max(1,ee>>1);return{textureData:{type:"compressed",levels:Fe},internalFormat:N,width:X,height:ae}}(C,null!==(D=x.hasMipmap)&&void 0!==D&&D));return x.samplingMode=R.levels.length>1?be.cw.LINEAR_MIPMAP_LINEAR:be.cw.LINEAR,x.hasMipmap=R.levels.length>1,x.internalFormat=N,x.width=U,x.height=G,new Lt.x(M,x,R)}(x,this._createDescriptor(x),C),this._glTexture}_loadFromKTX2(x,C){return this._loadAsync(()=>function Bt(M,x,C){return Zt.apply(this,arguments)}(x,this._createDescriptor(x),C).then(D=>(this._glTexture=D,D)))}_loadFromBasis(x,C){return this._loadAsync(()=>function lr(M,x,C){return wt.apply(this,arguments)}(x,this._createDescriptor(x),C).then(D=>(this._glTexture=D,D)))}_loadFromPixelData(x,C){(0,Je.hu)(this.params.width>0&&this.params.height>0);const D=this._createDescriptor(x);return D.pixelFormat=1===this.params.components?be.VI.LUMINANCE:3===this.params.components?be.VI.RGB:be.VI.RGBA,D.width=this.params.width,D.height=this.params.height,this._glTexture=new Lt.x(x,D,C),this._glTexture}_loadFromURL(x,C,D){var R=this;return this._loadAsync(function(){var N=(0,y.Z)(function*(U){const G=yield(0,ue.t)(D,{signal:U});return(0,at.k_)(U),R._loadFromImage(x,G,C)});return function(U){return N.apply(this,arguments)}}())}_loadFromImageElement(x,C,D){var R=this;return D.complete?this._loadFromImage(x,D,C):this._loadAsync(function(){var N=(0,y.Z)(function*(U){const G=yield(0,mt.fY)(D,D.src,!1,U);return(0,at.k_)(U),R._loadFromImage(x,G,C)});return function(U){return N.apply(this,arguments)}}())}_loadFromVideoElement(x,C,D){return D.readyState>=vr.HAVE_CURRENT_DATA?this._loadFromImage(x,D,C):this._loadFromVideoElementAsync(x,C,D)}_loadFromVideoElementAsync(x,C,D){return this._loadAsync(R=>new Promise((N,U)=>{const G=()=>{D.removeEventListener("loadeddata",ee),D.removeEventListener("error",X),(0,I.hw)(ae)},ee=()=>{D.readyState>=vr.HAVE_CURRENT_DATA&&(G(),N(this._loadFromImage(x,D,C)))},X=Te=>{G(),U(Te||new Ee.Z("Failed to load video"))};D.addEventListener("loadeddata",ee),D.addEventListener("error",X);const ae=(0,at.fu)(R,()=>X((0,at.zE)()))}))}_loadFromImage(x,C,D){const R=Nt._getDataDimensions(C);this.params.width=R.width,this.params.height=R.height;const N=this._createDescriptor(x);return N.pixelFormat=3===this.params.components?be.VI.RGB:be.VI.RGBA,!this._requiresPowerOfTwo(x,N)||(0,rt.wt)(R.width)&&(0,rt.wt)(R.height)?(N.width=R.width,N.height=R.height,this._glTexture=new Lt.x(x,N,C),this._glTexture):(this._glTexture=this._makePowerOfTwoTexture(x,C,R,N,D),this._glTexture)}_loadAsync(x){const C=new AbortController;this._loadingController=C;const D=x(C.signal);this._loadingPromise=D;const R=()=>{this._loadingController===C&&(this._loadingController=null),this._loadingPromise===D&&(this._loadingPromise=null)};return D.then(R,R),D}_requiresPowerOfTwo(x,C){const D=be.e8.CLAMP_TO_EDGE,R="number"==typeof C.wrapMode?C.wrapMode===D:C.wrapMode.s===D&&C.wrapMode.t===D;return!(0,gi.Z)(x.gl)&&(C.hasMipmap||!R)}_makePowerOfTwoTexture(x,C,D,R,N){const{width:U,height:G}=D,ee=(0,rt.Sf)(U),X=(0,rt.Sf)(G);let ae;switch(R.width=ee,R.height=X,this.params.powerOfTwoResizeMode){case ce.CE.PAD:R.textureCoordinateScaleFactor=[U/ee,G/X],ae=new Lt.x(x,R),ae.updateData(0,0,0,U,G,C);break;case ce.CE.STRETCH:case null:case void 0:ae=this._stretchToPowerOfTwo(x,C,R,N());break;default:(0,tt.Bg)(this.params.powerOfTwoResizeMode)}return R.hasMipmap&&ae.generateMipmap(),ae}_stretchToPowerOfTwo(x,C,D,R){const N=new Lt.x(x,D),U=new vi.X(x,{colorTarget:be.Lm.TEXTURE,depthStencilTarget:be.OU.NONE},N),G=new Lt.x(x,{target:be.No.TEXTURE_2D,pixelFormat:D.pixelFormat,dataType:be.Br.UNSIGNED_BYTE,wrapMode:be.e8.CLAMP_TO_EDGE,samplingMode:be.cw.LINEAR,flipped:!!D.flipped,maxAnisotropy:8,preMultiplyAlpha:D.preMultiplyAlpha},C),ee=(0,fi.ow)(x),X=x.getBoundFramebufferObject();return this._drawStretchedTexture(x,R,U,ee,G,N),this.requiresFrameUpdates?this._powerOfTwoStretchInfo={vao:ee,sourceTexture:G,framebuffer:U}:(ee.dispose(!0),G.dispose(),U.detachColorTexture(),U.dispose()),x.bindFramebuffer(X),N}_drawStretchedTexture(x,C,D,R,N,U){this._passParameters.texture=N,x.bindFramebuffer(D);const G=x.getViewport();x.setViewport(0,0,U.descriptor.width,U.descriptor.height),x.bindTechnique(C,this._passParameters,null),x.bindVAO(R),x.drawArrays(be.MX.TRIANGLE_STRIP,0,(0,er._V)(R,"geometry")),x.bindFramebuffer(null),x.setViewport(G.x,G.y,G.width,G.height),this._passParameters.texture=null}unload(){if((0,I.pC)(this._powerOfTwoStretchInfo)){const{framebuffer:x,vao:C,sourceTexture:D}=this._powerOfTwoStretchInfo;C.dispose(!0),D.dispose(),x.dispose(),this._glTexture=null,this._powerOfTwoStretchInfo=null}if((0,I.pC)(this._glTexture)&&(this._glTexture.dispose(),this._glTexture=null),(0,I.pC)(this._loadingController)){const x=this._loadingController;this._loadingController=null,this._loadingPromise=null,x.abort()}this.events.emit("unloaded")}}Nt.DDS_ENCODING="image/vnd-ms.dds",Nt.KTX2_ENCODING="image/ktx2",Nt.BASIS_ENCODING="image/x.basis",function(M){M[M.HAVE_NOTHING=0]="HAVE_NOTHING",M[M.HAVE_METADATA=1]="HAVE_METADATA",M[M.HAVE_CURRENT_DATA=2]="HAVE_CURRENT_DATA",M[M.HAVE_FUTURE_DATA=3]="HAVE_FUTURE_DATA",M[M.HAVE_ENOUGH_DATA=4]="HAVE_ENOUGH_DATA"}(vr||(vr={}));var _r,pi=v(8314),yr=v(59617),Nr=v(19625),Mt=v(13934),gr=v(26859),ur=v(96395),pr=v(92724),Ti=v(44621),Fr=v(40723),Tr=v(88569);!function(M){M[M.INTEGRATED_MESH=0]="INTEGRATED_MESH",M[M.OPAQUE_TERRAIN=1]="OPAQUE_TERRAIN",M[M.OPAQUE_MATERIAL=2]="OPAQUE_MATERIAL",M[M.TRANSPARENT_MATERIAL=3]="TRANSPARENT_MATERIAL",M[M.TRANSPARENT_TERRAIN=4]="TRANSPARENT_TERRAIN",M[M.TRANSPARENT_DEPTH_WRITE_DISABLED_MATERIAL=5]="TRANSPARENT_DEPTH_WRITE_DISABLED_MATERIAL",M[M.OCCLUDED_TERRAIN=6]="OCCLUDED_TERRAIN",M[M.OCCLUDER_MATERIAL=7]="OCCLUDER_MATERIAL",M[M.TRANSPARENT_OCCLUDER_MATERIAL=8]="TRANSPARENT_OCCLUDER_MATERIAL",M[M.OCCLUSION_PIXELS=9]="OCCLUSION_PIXELS",M[M.POSTPROCESSING_ENVIRONMENT_OPAQUE=10]="POSTPROCESSING_ENVIRONMENT_OPAQUE",M[M.POSTPROCESSING_ENVIRONMENT_TRANSPARENT=11]="POSTPROCESSING_ENVIRONMENT_TRANSPARENT",M[M.LASERLINES=12]="LASERLINES",M[M.LASERLINES_CONTRAST_CONTROL=13]="LASERLINES_CONTRAST_CONTROL",M[M.HUD_MATERIAL=14]="HUD_MATERIAL",M[M.LABEL_MATERIAL=15]="LABEL_MATERIAL",M[M.LINE_CALLOUTS=16]="LINE_CALLOUTS",M[M.LINE_CALLOUTS_HUD_DEPTH=17]="LINE_CALLOUTS_HUD_DEPTH",M[M.DRAPED_MATERIAL=18]="DRAPED_MATERIAL",M[M.DRAPED_WATER=19]="DRAPED_WATER",M[M.VOXEL=20]="VOXEL",M[M.MAX_SLOTS=21]="MAX_SLOTS"}(_r||(_r={}));var xi=v(48977),Mi=v(78451),Ei=v(14658),Hr=v(2071);const or=(0,S.c)(),Or=(0,S.c)(),mr=(0,S.c)(),Wr=new class Ai{constructor(x=0){this.offset=x,this.sphere=(0,Hr.c)(),this.tmpVertex=(0,S.c)()}applyToVertex(x,C,D){const R=this.objectTransform.transform;let N=R[0]*x+R[4]*C+R[8]*D+R[12],U=R[1]*x+R[5]*C+R[9]*D+R[13],G=R[2]*x+R[6]*C+R[10]*D+R[14];const ee=this.offset/Math.sqrt(N*N+U*U+G*G);N+=N*ee,U+=U*ee,G+=G*ee;const X=this.objectTransform.inverse;return this.tmpVertex[0]=X[0]*N+X[4]*U+X[8]*G+X[12],this.tmpVertex[1]=X[1]*N+X[5]*U+X[9]*G+X[13],this.tmpVertex[2]=X[2]*N+X[6]*U+X[10]*G+X[14],this.tmpVertex}applyToMinMax(x,C){const D=this.offset/Math.sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);x[0]+=x[0]*D,x[1]+=x[1]*D,x[2]+=x[2]*D;const R=this.offset/Math.sqrt(C[0]*C[0]+C[1]*C[1]+C[2]*C[2]);C[0]+=C[0]*R,C[1]+=C[1]*R,C[2]+=C[2]*R}applyToAabb(x){const C=this.offset/Math.sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);x[0]+=x[0]*C,x[1]+=x[1]*C,x[2]+=x[2]*C;const D=this.offset/Math.sqrt(x[3]*x[3]+x[4]*x[4]+x[5]*x[5]);return x[3]+=x[3]*D,x[4]+=x[4]*D,x[5]+=x[5]*D,x}applyToBoundingSphere(x){const C=Math.sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]),D=this.offset/C;return this.sphere[0]=x[0]+x[0]*D,this.sphere[1]=x[1]+x[1]*D,this.sphere[2]=x[2]+x[2]*D,this.sphere[3]=x[3]+x[3]*this.offset/C,this.sphere}};new class Pi{constructor(x=0){this.componentLocalOriginLength=0,this._tmpVertex=(0,S.c)(),this._mbs=(0,Hr.c)(),this._obb={center:(0,S.c)(),halfSize:(0,Ei.c)(),quaternion:null},this._totalOffset=0,this._offset=0,this._resetOffset(x)}_resetOffset(x){this._offset=x,this._totalOffset=x}set offset(x){this._resetOffset(x)}get offset(){return this._offset}set componentOffset(x){this._totalOffset=this._offset+x}set localOrigin(x){this.componentLocalOriginLength=Math.sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2])}applyToVertex(x,C,D){const R=x,N=C,U=D+this.componentLocalOriginLength,G=this._totalOffset/Math.sqrt(R*R+N*N+U*U);return this._tmpVertex[0]=x+R*G,this._tmpVertex[1]=C+N*G,this._tmpVertex[2]=D+U*G,this._tmpVertex}applyToAabb(x){const C=x[0],D=x[1],R=x[2]+this.componentLocalOriginLength,N=x[3],U=x[4],G=x[5]+this.componentLocalOriginLength,ee=C*N<0?0:Math.min(Math.abs(C),Math.abs(N)),X=D*U<0?0:Math.min(Math.abs(D),Math.abs(U)),ae=R*G<0?0:Math.min(Math.abs(R),Math.abs(G)),Te=Math.sqrt(ee*ee+X*X+ae*ae);if(Te<this._totalOffset)return x[0]-=C<0?this._totalOffset:0,x[1]-=D<0?this._totalOffset:0,x[2]-=R<0?this._totalOffset:0,x[3]+=N>0?this._totalOffset:0,x[4]+=U>0?this._totalOffset:0,x[5]+=G>0?this._totalOffset:0,x;const Ie=Math.max(Math.abs(C),Math.abs(N)),Le=Math.max(Math.abs(D),Math.abs(U)),Fe=Math.max(Math.abs(R),Math.abs(G)),Ye=Math.sqrt(Ie*Ie+Le*Le+Fe*Fe),Ue=this._totalOffset/Ye,$e=this._totalOffset/Te;return x[0]+=C*(C>0?Ue:$e),x[1]+=D*(D>0?Ue:$e),x[2]+=R*(R>0?Ue:$e),x[3]+=N*(N<0?Ue:$e),x[4]+=U*(U<0?Ue:$e),x[5]+=G*(G<0?Ue:$e),x}applyToMbs(x){const C=Math.sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]),D=this._totalOffset/C;return this._mbs[0]=x[0]+x[0]*D,this._mbs[1]=x[1]+x[1]*D,this._mbs[2]=x[2]+x[2]*D,this._mbs[3]=x[3]+x[3]*this._totalOffset/C,this._mbs}applyToObb(x){const C=x.center,D=this._totalOffset/Math.sqrt(C[0]*C[0]+C[1]*C[1]+C[2]*C[2]);this._obb.center[0]=C[0]+C[0]*D,this._obb.center[1]=C[1]+C[1]*D,this._obb.center[2]=C[2]+C[2]*D,(0,A.q)(this._obb.halfSize,x.halfSize,x.quaternion),(0,A.a)(this._obb.halfSize,this._obb.halfSize,x.center);const R=this._totalOffset/Math.sqrt(this._obb.halfSize[0]*this._obb.halfSize[0]+this._obb.halfSize[1]*this._obb.halfSize[1]+this._obb.halfSize[2]*this._obb.halfSize[2]);return this._obb.halfSize[0]+=this._obb.halfSize[0]*R,this._obb.halfSize[1]+=this._obb.halfSize[1]*R,this._obb.halfSize[2]+=this._obb.halfSize[2]*R,(0,A.b)(this._obb.halfSize,this._obb.halfSize,x.center),(0,xi.c)(jr,x.quaternion),(0,A.q)(this._obb.halfSize,this._obb.halfSize,jr),this._obb.halfSize[0]*=this._obb.halfSize[0]<0?-1:1,this._obb.halfSize[1]*=this._obb.halfSize[1]<0?-1:1,this._obb.halfSize[2]*=this._obb.halfSize[2]<0?-1:1,this._obb.quaternion=x.quaternion,this._obb}},new class Oi{constructor(x=0){this.offset=x,this.tmpVertex=(0,S.c)()}applyToVertex(x,C,D){const R=x+this.localOrigin[0],N=C+this.localOrigin[1],U=D+this.localOrigin[2],G=this.offset/Math.sqrt(R*R+N*N+U*U);return this.tmpVertex[0]=x+R*G,this.tmpVertex[1]=C+N*G,this.tmpVertex[2]=D+U*G,this.tmpVertex}applyToAabb(x){for(let N=0;N<3;++N)or[N]=x[0+N]+this.localOrigin[N],Or[N]=x[3+N]+this.localOrigin[N],mr[N]=or[N];const C=this.applyToVertex(or[0],or[1],or[2]);for(let N=0;N<3;++N)x[N]=C[N],x[N+3]=C[N];const D=N=>{const U=this.applyToVertex(N[0],N[1],N[2]);for(let G=0;G<3;++G)x[G+0]=Math.min(x[G+0],U[G]),x[G+3]=Math.max(x[G+3],U[G])};for(let N=1;N<8;++N){for(let U=0;U<3;++U)mr[U]=N&1<<U?Or[U]:or[U];D(mr)}let R=0;for(let N=0;N<3;++N)or[N]*Or[N]<0&&(R|=1<<N);if(0!==R&&7!==R)for(let N=0;N<8;++N)if(!(R&N)){for(let U=0;U<3;++U)mr[U]=R[U]?0:N&1<<U?or[U]:Or[U];D(mr)}for(let N=0;N<3;++N)x[N+0]-=this.localOrigin[N],x[N+3]-=this.localOrigin[N];return x}};const jr=(0,Mi.a)();function Ci(M,x,C,D){const R=C.typedBuffer,N=C.typedBufferStride,U=M.length;D*=N;for(let G=0;G<U;++G){const ee=2*M[G];R[D]=x[ee],R[D+1]=x[ee+1],D+=N}}function Gr(M,x,C,D,R){const N=C.typedBuffer,U=C.typedBufferStride,G=M.length;if(D*=U,null==R||1===R)for(let ee=0;ee<G;++ee){const X=3*M[ee];N[D]=x[X],N[D+1]=x[X+1],N[D+2]=x[X+2],D+=U}else for(let ee=0;ee<G;++ee){const X=3*M[ee];for(let ae=0;ae<R;++ae)N[D]=x[X],N[D+1]=x[X+1],N[D+2]=x[X+2],D+=U}}function yi(M,x,C,D,R,N=1){if(!C)return void Gr(M,x,D,R,N);const U=D.typedBuffer,G=D.typedBufferStride,ee=M.length,X=C[0],ae=C[1],Te=C[2],Ie=C[4],Le=C[5],Fe=C[6],Ye=C[8],Ue=C[9],$e=C[10],De=C[12],ot=C[13],_t=C[14];R*=G;let Et=0,qe=0,Ze=0;const lt=$r(C)?je=>{Et=x[je]+De,qe=x[je+1]+ot,Ze=x[je+2]+_t}:je=>{const Ve=x[je],it=x[je+1],nt=x[je+2];Et=X*Ve+Ie*it+Ye*nt+De,qe=ae*Ve+Le*it+Ue*nt+ot,Ze=Te*Ve+Fe*it+$e*nt+_t};if(1===N)for(let je=0;je<ee;++je)lt(3*M[je]),U[R]=Et,U[R+1]=qe,U[R+2]=Ze,R+=G;else for(let je=0;je<ee;++je){lt(3*M[je]);for(let Ve=0;Ve<N;++Ve)U[R]=Et,U[R+1]=qe,U[R+2]=Ze,R+=G}}function Si(M,x,C,D,R,N=1){if(!C)return void Gr(M,x,D,R,N);const U=C,G=D.typedBuffer,ee=D.typedBufferStride,X=M.length,ae=U[0],Te=U[1],Ie=U[2],Le=U[4],Fe=U[5],Ye=U[6],Ue=U[8],$e=U[9],De=U[10],ot=!(0,H.x)(U);R*=ee;let qe=0,Ze=0,lt=0;const je=$r(U)?Ve=>{qe=x[Ve],Ze=x[Ve+1],lt=x[Ve+2]}:Ve=>{const it=x[Ve],nt=x[Ve+1],pt=x[Ve+2];qe=ae*it+Le*nt+Ue*pt,Ze=Te*it+Fe*nt+$e*pt,lt=Ie*it+Ye*nt+De*pt};if(1===N)if(ot)for(let Ve=0;Ve<X;++Ve){je(3*M[Ve]);const it=qe*qe+Ze*Ze+lt*lt;if(it<.999999&&it>1e-6){const nt=1/Math.sqrt(it);G[R]=qe*nt,G[R+1]=Ze*nt,G[R+2]=lt*nt}else G[R]=qe,G[R+1]=Ze,G[R+2]=lt;R+=ee}else for(let Ve=0;Ve<X;++Ve)je(3*M[Ve]),G[R]=qe,G[R+1]=Ze,G[R+2]=lt,R+=ee;else for(let Ve=0;Ve<X;++Ve){if(je(3*M[Ve]),ot){const it=qe*qe+Ze*Ze+lt*lt;if(it<.999999&&it>1e-6){const nt=1/Math.sqrt(it);qe*=nt,Ze*=nt,lt*=nt}}for(let it=0;it<N;++it)G[R]=qe,G[R+1]=Ze,G[R+2]=lt,R+=ee}}function Li(M,x,C,D,R,N=1){if(!C)return void function Di(M,x,C,D,R=1){const N=C.typedBuffer,U=C.typedBufferStride,G=M.length;if(D*=U,1===R)for(let ee=0;ee<G;++ee){const X=4*M[ee];N[D]=x[X],N[D+1]=x[X+1],N[D+2]=x[X+2],N[D+3]=x[X+3],D+=U}else for(let ee=0;ee<G;++ee){const X=4*M[ee];for(let ae=0;ae<R;++ae)N[D]=x[X],N[D+1]=x[X+1],N[D+2]=x[X+2],N[D+3]=x[X+3],D+=U}}(M,x,D,R,N);const G=D.typedBuffer,ee=D.typedBufferStride,X=M.length,ae=C[0],Te=C[1],Ie=C[2],Le=C[4],Fe=C[5],Ye=C[6],Ue=C[8],$e=C[9],De=C[10],ot=!(0,H.x)(C);if(R*=ee,1===N)for(let qe=0;qe<X;++qe){const Ze=4*M[qe],lt=x[Ze],je=x[Ze+1],Ve=x[Ze+2],it=x[Ze+3];let nt=ae*lt+Le*je+Ue*Ve,pt=Te*lt+Fe*je+$e*Ve,Ft=Ie*lt+Ye*je+De*Ve;if(ot){const Vt=nt*nt+pt*pt+Ft*Ft;if(Vt<.999999&&Vt>1e-6){const $t=1/Math.sqrt(Vt);nt*=$t,pt*=$t,Ft*=$t}}G[R]=nt,G[R+1]=pt,G[R+2]=Ft,G[R+3]=it,R+=ee}else for(let qe=0;qe<X;++qe){const Ze=4*M[qe],lt=x[Ze],je=x[Ze+1],Ve=x[Ze+2],it=x[Ze+3];let nt=ae*lt+Le*je+Ue*Ve,pt=Te*lt+Fe*je+$e*Ve,Ft=Ie*lt+Ye*je+De*Ve;if(ot){const Vt=nt*nt+pt*pt+Ft*Ft;if(Vt<.999999&&Vt>1e-6){const $t=1/Math.sqrt(Vt);nt*=$t,pt*=$t,Ft*=$t}}for(let Vt=0;Vt<N;++Vt)G[R]=nt,G[R+1]=pt,G[R+2]=Ft,G[R+3]=it,R+=ee}}function Kr(M,x,C,D,R,N=1){const U=D.typedBuffer,G=D.typedBufferStride,ee=M.length;if(R*=G,C!==x.length||4!==C)if(1!==N)if(4!==C)for(let X=0;X<ee;++X){const ae=3*M[X];for(let Te=0;Te<N;++Te)U[R]=x[ae],U[R+1]=x[ae+1],U[R+2]=x[ae+2],U[R+3]=255,R+=G}else for(let X=0;X<ee;++X){const ae=4*M[X];for(let Te=0;Te<N;++Te)U[R]=x[ae],U[R+1]=x[ae+1],U[R+2]=x[ae+2],U[R+3]=x[ae+3],R+=G}else{if(4===C){for(let X=0;X<ee;++X){const ae=4*M[X];U[R]=x[ae],U[R+1]=x[ae+1],U[R+2]=x[ae+2],U[R+3]=x[ae+3],R+=G}return}for(let X=0;X<ee;++X){const ae=3*M[X];U[R]=x[ae],U[R+1]=x[ae+1],U[R+2]=x[ae+2],U[R+3]=255,R+=G}}else{U[R]=x[0],U[R+1]=x[1],U[R+2]=x[2],U[R+3]=x[3];const X=new Uint32Array(D.typedBuffer.buffer,D.start),ae=G/4,Te=X[R/=4];R+=ae;const Ie=ee*N;for(let Le=1;Le<Ie;++Le)X[R]=Te,R+=ae}}function Ri(M,x,C,D,R=1){const N=x.typedBuffer,U=x.typedBufferStride;if(D*=U,1===R)for(let G=0;G<C;++G)N[D]=M[0],N[D+1]=M[1],N[D+2]=M[2],N[D+3]=M[3],D+=U;else for(let G=0;G<C;++G)for(let ee=0;ee<R;++ee)N[D]=M[0],N[D+1]=M[1],N[D+2]=M[2],N[D+3]=M[3],D+=U}function $r(M){return 1===M[0]&&0===M[1]&&0===M[2]&&0===M[4]&&1===M[5]&&0===M[6]&&0===M[8]&&0===M[9]&&1===M[10]}var Jr=v(50229),Pr=v(36603),wi=v(21799),Ui=v(67022),Bi=v(7228),Xr=v(651),Ni=v(91056),Fi=v(39114),Hi=v(12407);const Wi={mask:255},zi={function:{func:be.wb.ALWAYS,ref:ce.hU.OutlineVisualElementMask,mask:ce.hU.OutlineVisualElementMask},operation:{fail:be.xS.KEEP,zFail:be.xS.KEEP,zPass:be.xS.ZERO}},Vi={function:{func:be.wb.ALWAYS,ref:ce.hU.OutlineVisualElementMask,mask:ce.hU.OutlineVisualElementMask},operation:{fail:be.xS.KEEP,zFail:be.xS.KEEP,zPass:be.xS.REPLACE}};var Ar=v(44835),ji=v(96160),Gi=v(57596),br=v(2078);class Ki extends wi.d4{constructor(){super(...arguments),this.isSchematic=!1,this.usePBR=!1,this.mrrFactors=(0,S.f)(0,1,.5),this.hasVertexColors=!1,this.hasSymbolColors=!1,this.doubleSided=!1,this.doubleSidedType="normal",this.cullFace=ce.Vr.Back,this.emissiveFactor=(0,S.f)(0,0,0),this.instancedDoublePrecision=!1,this.normals="default",this.receiveSSAO=!0,this.receiveShadows=!0,this.castShadows=!0,this.shadowMappingEnabled=!1,this.ambient=(0,S.f)(.2,.2,.2),this.diffuse=(0,S.f)(.8,.8,.8),this.externalColor=(0,ft.f)(1,1,1,1),this.colorMixMode="multiply",this.opacity=1,this.layerOpacity=1,this.origin=(0,S.c)(),this.hasSlicePlane=!1,this.hasSliceHighlight=!0,this.offsetTransparentBackfaces=!1,this.vvSizeEnabled=!1,this.vvSizeMinSize=[1,1,1],this.vvSizeMaxSize=[100,100,100],this.vvSizeOffset=[0,0,0],this.vvSizeFactor=[1,1,1],this.vvSizeValue=[1,1,1],this.vvColorEnabled=!1,this.vvColorValues=[0,0,0,0,0,0,0,0],this.vvColorColors=[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],this.vvSymbolAnchor=[0,0,0],this.vvSymbolRotationMatrix=(0,V.c)(),this.vvOpacityEnabled=!1,this.vvOpacityValues=[],this.vvOpacityOpacities=[],this.transparent=!1,this.writeDepth=!0,this.customDepthTest=ce.Gv.Less,this.textureAlphaMode=ce.JJ.Blend,this.textureAlphaCutoff=Ui.F,this.textureAlphaPremultiplied=!1,this.hasOccludees=!1,this.renderOccluded=Fr.yD.Occlude}}class xr extends Ni.A{initializeConfiguration(x,C){C.hasWebGL2Context=x.rctx.type===Gi.zO.WEBGL2,C.spherical=x.viewingMode===yr.JY.Global,C.doublePrecisionRequiresObfuscation=(0,Bi.I)(x.rctx),C.textureCoordinateType=C.hasColorTexture||C.hasMetallicRoughnessTexture||C.hasEmissionTexture||C.hasOcclusionTexture||C.hasNormalTexture?Pr.N.Default:Pr.N.None,C.objectAndLayerIdColorInstanced=C.instanced}initializeProgram(x){return this._initializeProgram(x,xr.shader)}_initializeProgram(x,C){return new Hi.$(x.rctx,C.get().build(this.configuration),Fi.i)}_convertDepthTestFunction(x){return x===ce.Gv.Lequal?be.wb.LEQUAL:be.wb.LESS}_makePipeline(x,C){const D=this.configuration,R=x===Ar.A.NONE,N=x===Ar.A.FrontFace;return(0,br.sm)({blending:D.output!==Mt.H.Color&&D.output!==Mt.H.Alpha||!D.transparent?null:R?Tr.wu:(0,Tr.j7)(x),culling:$i(D)&&(0,br.zp)(D.cullFace),depthTest:{func:(0,Tr.Bh)(x,this._convertDepthTestFunction(D.customDepthTest))},depthWrite:R||N?D.writeDepth&&br.LZ:null,colorWrite:br.BK,stencilWrite:D.hasOccludees?Wi:null,stencilTest:D.hasOccludees?C?Vi:zi:null,polygonOffset:R||N?null:(0,Tr.je)(D.enableOffset)})}initializePipeline(){return this._occludeePipelineState=this._makePipeline(this.configuration.transparencyPassType,!0),this._makePipeline(this.configuration.transparencyPassType,!1)}getPipelineState(x,C){return C?this._occludeePipelineState:super.getPipelineState(x,C)}}function $i(M){return M.cullFace!==ce.Vr.None||!M.hasSlicePlane&&!M.transparent&&!M.doubleSidedMode}xr.shader=new Xr.J(ji.D,()=>v.e(3907).then(v.bind(v,83907)));var we=v(17626),Re=v(87601),Ji=v(37847);class nr extends Re.m{constructor(){super(...arguments),this.hasWebGL2Context=!1}}(0,we._)([(0,Re.o)({constValue:!0})],nr.prototype,"hasSliceHighlight",void 0),(0,we._)([(0,Re.o)({constValue:!1})],nr.prototype,"hasSliceInVertexProgram",void 0),(0,we._)([(0,Re.o)({constValue:!1})],nr.prototype,"instancedDoublePrecision",void 0),(0,we._)([(0,Re.o)({constValue:!1})],nr.prototype,"useLegacyTerrainShading",void 0),(0,we._)([(0,Re.o)({constValue:!1})],nr.prototype,"hasModelTransformation",void 0),(0,we._)([(0,Re.o)({constValue:Ji.P.Pass})],nr.prototype,"pbrTextureBindType",void 0),(0,we._)([(0,Re.o)()],nr.prototype,"hasWebGL2Context",void 0);class We extends nr{constructor(){super(...arguments),this.output=Mt.H.Color,this.alphaDiscardMode=ce.JJ.Opaque,this.doubleSidedMode=ur.q.None,this.pbrMode=pr.f7.Disabled,this.cullFace=ce.Vr.None,this.transparencyPassType=Ar.A.NONE,this.normalType=gr.h.Attribute,this.textureCoordinateType=Pr.N.None,this.customDepthTest=ce.Gv.Less,this.spherical=!1,this.hasVertexColors=!1,this.hasSymbolColors=!1,this.hasVerticalOffset=!1,this.hasSlicePlane=!1,this.hasSliceHighlight=!0,this.hasColorTexture=!1,this.hasMetallicRoughnessTexture=!1,this.hasEmissionTexture=!1,this.hasOcclusionTexture=!1,this.hasNormalTexture=!1,this.hasScreenSizePerspective=!1,this.hasVertexTangents=!1,this.hasOccludees=!1,this.hasMultipassTerrain=!1,this.hasModelTransformation=!1,this.offsetBackfaces=!1,this.vvSize=!1,this.vvColor=!1,this.receiveShadows=!1,this.receiveAmbientOcclusion=!1,this.textureAlphaPremultiplied=!1,this.instanced=!1,this.instancedColor=!1,this.objectAndLayerIdColorInstanced=!1,this.instancedDoublePrecision=!1,this.doublePrecisionRequiresObfuscation=!1,this.writeDepth=!0,this.transparent=!1,this.enableOffset=!0,this.cullAboveGround=!1,this.snowCover=!1,this.hasColorTextureTransform=!1,this.hasEmissionTextureTransform=!1,this.hasNormalTextureTransform=!1,this.hasOcclusionTextureTransform=!1,this.hasMetallicRoughnessTextureTransform=!1}}(0,we._)([(0,Re.o)({count:Mt.H.COUNT})],We.prototype,"output",void 0),(0,we._)([(0,Re.o)({count:ce.JJ.COUNT})],We.prototype,"alphaDiscardMode",void 0),(0,we._)([(0,Re.o)({count:ur.q.COUNT})],We.prototype,"doubleSidedMode",void 0),(0,we._)([(0,Re.o)({count:pr.f7.COUNT})],We.prototype,"pbrMode",void 0),(0,we._)([(0,Re.o)({count:ce.Vr.COUNT})],We.prototype,"cullFace",void 0),(0,we._)([(0,Re.o)({count:Ar.A.COUNT})],We.prototype,"transparencyPassType",void 0),(0,we._)([(0,Re.o)({count:gr.h.COUNT})],We.prototype,"normalType",void 0),(0,we._)([(0,Re.o)({count:Pr.N.COUNT})],We.prototype,"textureCoordinateType",void 0),(0,we._)([(0,Re.o)({count:ce.Gv.COUNT})],We.prototype,"customDepthTest",void 0),(0,we._)([(0,Re.o)()],We.prototype,"spherical",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasVertexColors",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasSymbolColors",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasVerticalOffset",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasSlicePlane",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasSliceHighlight",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasColorTexture",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasMetallicRoughnessTexture",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasEmissionTexture",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasOcclusionTexture",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasNormalTexture",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasScreenSizePerspective",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasVertexTangents",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasOccludees",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasMultipassTerrain",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasModelTransformation",void 0),(0,we._)([(0,Re.o)()],We.prototype,"offsetBackfaces",void 0),(0,we._)([(0,Re.o)()],We.prototype,"vvSize",void 0),(0,we._)([(0,Re.o)()],We.prototype,"vvColor",void 0),(0,we._)([(0,Re.o)()],We.prototype,"receiveShadows",void 0),(0,we._)([(0,Re.o)()],We.prototype,"receiveAmbientOcclusion",void 0),(0,we._)([(0,Re.o)()],We.prototype,"textureAlphaPremultiplied",void 0),(0,we._)([(0,Re.o)()],We.prototype,"instanced",void 0),(0,we._)([(0,Re.o)()],We.prototype,"instancedColor",void 0),(0,we._)([(0,Re.o)()],We.prototype,"objectAndLayerIdColorInstanced",void 0),(0,we._)([(0,Re.o)()],We.prototype,"instancedDoublePrecision",void 0),(0,we._)([(0,Re.o)()],We.prototype,"doublePrecisionRequiresObfuscation",void 0),(0,we._)([(0,Re.o)()],We.prototype,"writeDepth",void 0),(0,we._)([(0,Re.o)()],We.prototype,"transparent",void 0),(0,we._)([(0,Re.o)()],We.prototype,"enableOffset",void 0),(0,we._)([(0,Re.o)()],We.prototype,"cullAboveGround",void 0),(0,we._)([(0,Re.o)()],We.prototype,"snowCover",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasColorTextureTransform",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasEmissionTextureTransform",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasNormalTextureTransform",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasOcclusionTextureTransform",void 0),(0,we._)([(0,Re.o)()],We.prototype,"hasMetallicRoughnessTextureTransform",void 0),(0,we._)([(0,Re.o)({constValue:!0})],We.prototype,"hasVvInstancing",void 0),(0,we._)([(0,Re.o)({constValue:!1})],We.prototype,"useCustomDTRExponentForWater",void 0),(0,we._)([(0,Re.o)({constValue:!1})],We.prototype,"supportsTextureAtlas",void 0),(0,we._)([(0,Re.o)({constValue:!0})],We.prototype,"useFillLights",void 0);var Xi=v(77133);class Cr extends xr{initializeConfiguration(x,C){super.initializeConfiguration(x,C),C.hasMetallicRoughnessTexture=!1,C.hasEmissionTexture=!1,C.hasOcclusionTexture=!1,C.hasNormalTexture=!1,C.hasModelTransformation=!1,C.normalType=gr.h.Attribute,C.doubleSidedMode=ur.q.WindingOrder,C.hasVertexTangents=!1}initializeProgram(x){return this._initializeProgram(x,Cr.shader)}}Cr.shader=new Xr.J(Xi.R,()=>v.e(3959).then(v.bind(v,93959)));class Yr extends Fr.F5{constructor(x){super(x,Qi),this.supportsEdges=!0,this._configuration=new We,this._vertexBufferLayout=function qi(M){const x=M.textureId||M.normalTextureId||M.metallicRoughnessTextureId||M.emissiveTextureId||M.occlusionTextureId,C=(0,Nr.U$)().vec3f(re.T.POSITION).vec3f(re.T.NORMAL);return M.hasVertexTangents&&C.vec4f(re.T.TANGENT),x&&C.vec2f(re.T.UV0),M.hasVertexColors&&C.vec4u8(re.T.COLOR),M.hasSymbolColors&&C.vec4u8(re.T.SYMBOLCOLOR),(0,pi.Z)("enable-feature:objectAndLayerId-rendering")&&C.vec4u8(re.T.OBJECTANDLAYERIDCOLOR),C}(this.parameters),this._instanceBufferLayout=x.instanced?function es(M){let x=(0,Nr.U$)();return x=M.instancedDoublePrecision?x.vec3f(re.T.MODELORIGINHI).vec3f(re.T.MODELORIGINLO).mat3f(re.T.MODEL).mat3f(re.T.MODELNORMAL):x.mat4f(re.T.MODEL).mat4f(re.T.MODELNORMAL),(0,I.pC)(M.instanced)&&M.instanced.includes("color")&&(x=x.vec4f(re.T.INSTANCECOLOR)),(0,I.pC)(M.instanced)&&M.instanced.includes("featureAttribute")&&(x=x.vec4f(re.T.INSTANCEFEATUREATTRIBUTE)),(0,I.pC)(M.instanced)&&M.instanced.includes("objectAndLayerIdColor")&&(x=x.vec4u8(re.T.OBJECTANDLAYERIDCOLOR_INSTANCED)),x}(this.parameters):null}isVisibleForOutput(x){return x!==Mt.H.Shadow&&x!==Mt.H.ShadowExludeHighlight&&x!==Mt.H.ShadowHighlight||this.parameters.castShadows}isVisible(){const x=this.parameters;if(!super.isVisible()||0===x.layerOpacity)return!1;const{instanced:C,hasVertexColors:D,hasSymbolColors:R,vvColorEnabled:N}=x,U=(0,I.pC)(C)&&C.includes("color"),G="replace"===x.colorMixMode,ee=x.opacity>0,X=x.externalColor&&x.externalColor[3]>0;return D&&(U||N||R)?!!G||ee:D?G?X:ee:U||N||R?!!G||ee:G?X:ee}getConfiguration(x,C){return this._configuration.output=x,this._configuration.hasNormalTexture=!!this.parameters.normalTextureId,this._configuration.hasColorTexture=!!this.parameters.textureId,this._configuration.hasVertexTangents=this.parameters.hasVertexTangents,this._configuration.instanced=!!this.parameters.instanced,this._configuration.instancedDoublePrecision=this.parameters.instancedDoublePrecision,this._configuration.vvSize=this.parameters.vvSizeEnabled,this._configuration.hasVerticalOffset=(0,I.pC)(this.parameters.verticalOffset),this._configuration.hasScreenSizePerspective=(0,I.pC)(this.parameters.screenSizePerspective),this._configuration.hasSlicePlane=this.parameters.hasSlicePlane,this._configuration.hasSliceHighlight=this.parameters.hasSliceHighlight,this._configuration.alphaDiscardMode=this.parameters.textureAlphaMode,this._configuration.normalType="screenDerivative"===this.parameters.normals?gr.h.ScreenDerivative:gr.h.Attribute,this._configuration.transparent=this.parameters.transparent,this._configuration.writeDepth=this.parameters.writeDepth,(0,I.pC)(this.parameters.customDepthTest)&&(this._configuration.customDepthTest=this.parameters.customDepthTest),this._configuration.hasOccludees=this.parameters.hasOccludees,this._configuration.cullFace=this.parameters.hasSlicePlane?ce.Vr.None:this.parameters.cullFace,this._configuration.hasMultipassTerrain=C.multipassTerrain.enabled,this._configuration.cullAboveGround=C.multipassTerrain.cullAboveGround,this._configuration.hasModelTransformation=(0,I.pC)(this.parameters.modelTransformation),x!==Mt.H.Color&&x!==Mt.H.Alpha||(this._configuration.hasVertexColors=this.parameters.hasVertexColors,this._configuration.hasSymbolColors=this.parameters.hasSymbolColors,this._configuration.doubleSidedMode=this.parameters.treeRendering?ur.q.WindingOrder:this.parameters.doubleSided&&"normal"===this.parameters.doubleSidedType?ur.q.View:this.parameters.doubleSided&&"winding-order"===this.parameters.doubleSidedType?ur.q.WindingOrder:ur.q.None,this._configuration.instancedColor=(0,I.pC)(this.parameters.instanced)&&this.parameters.instanced.includes("color"),this._configuration.receiveShadows=this.parameters.receiveShadows&&this.parameters.shadowMappingEnabled,this._configuration.receiveAmbientOcclusion=!!C.ssaoHelper.ready&&this.parameters.receiveSSAO,this._configuration.vvColor=this.parameters.vvColorEnabled,this._configuration.textureAlphaPremultiplied=!!this.parameters.textureAlphaPremultiplied,this._configuration.pbrMode=this.parameters.usePBR?this.parameters.isSchematic?pr.f7.Schematic:pr.f7.Normal:pr.f7.Disabled,this._configuration.hasMetallicRoughnessTexture=!!this.parameters.metallicRoughnessTextureId,this._configuration.hasEmissionTexture=!!this.parameters.emissiveTextureId,this._configuration.hasOcclusionTexture=!!this.parameters.occlusionTextureId,this._configuration.offsetBackfaces=!(!this.parameters.transparent||!this.parameters.offsetTransparentBackfaces),this._configuration.transparencyPassType=C.transparencyPassType,this._configuration.enableOffset=C.camera.relativeElevation<Tr.ve,this._configuration.snowCover=this.hasSnowCover(C),this._configuration.hasColorTextureTransform=!!this.parameters.colorTextureTransformMatrix,this._configuration.hasNormalTextureTransform=!!this.parameters.normalTextureTransformMatrix,this._configuration.hasEmissionTextureTransform=!!this.parameters.emissiveTextureTransformMatrix,this._configuration.hasOcclusionTextureTransform=!!this.parameters.occlusionTextureTransformMatrix,this._configuration.hasMetallicRoughnessTextureTransform=!!this.parameters.metallicRoughnessTextureTransformMatrix),this._configuration}hasSnowCover(x){return(0,I.pC)(x.weather)&&x.weatherVisible&&"snowy"===x.weather.type&&"enabled"===x.weather.snowCover}intersect(x,C,D,R,N,U,G){if((0,I.pC)(this.parameters.verticalOffset)){const ee=R.camera;(0,A.s)(Lr,D[12],D[13],D[14]);let X=null;switch(R.viewingMode){case yr.JY.Global:X=(0,A.n)(Zr,Lr);break;case yr.JY.Local:X=(0,A.c)(Zr,is)}let ae=0;const Te=(0,A.b)(ss,Lr,ee.eye),Ie=(0,A.l)(Te),Le=(0,A.g)(Te,Te,1/Ie);let Fe=null;this.parameters.screenSizePerspective&&(Fe=(0,A.e)(X,Le)),ae+=(0,Jr.Hx)(ee,Ie,this.parameters.verticalOffset,Fe,this.parameters.screenSizePerspective),(0,A.g)(X,X,ae),(0,A.t)(Sr,X,R.transform.inverseRotation),N=(0,A.b)(ts,N,Sr),U=(0,A.b)(rs,U,Sr)}(0,Jr.Bw)(x,C,R,N,U,function bi(M){return(0,I.pC)(M)?(Wr.offset=M,Wr):null}(R.verticalOffset),G)}requiresSlot(x,C){return!(C!==Mt.H.Color&&C!==Mt.H.Alpha&&C!==Mt.H.Depth&&C!==Mt.H.Normal&&C!==Mt.H.Shadow&&C!==Mt.H.ShadowHighlight&&C!==Mt.H.ShadowExludeHighlight&&C!==Mt.H.Highlight&&C!==Mt.H.ObjectAndLayerIdColor||x!==(this.parameters.transparent?this.parameters.writeDepth?_r.TRANSPARENT_MATERIAL:_r.TRANSPARENT_DEPTH_WRITE_DISABLED_MATERIAL:_r.OPAQUE_MATERIAL)&&x!==_r.DRAPED_MATERIAL&&C!==Mt.H.ObjectAndLayerIdColor)}createGLMaterial(x){return new Yi(x)}createBufferWriter(){return new ki(this._vertexBufferLayout,this._instanceBufferLayout)}}class Yi extends Ti.F{constructor(x){super({...x,...x.material.parameters})}_updateParameters(x){const C=this._material.parameters;this.updateTexture(C.textureId);const D=x.camera.viewInverseTransposeMatrix;return(0,A.s)(C.origin,D[3],D[7],D[11]),this._material.setParameters(this.textureBindParameters),this.ensureTechnique(C.treeRendering?Cr:xr,x)}_updateShadowState(x){x.shadowMap.enabled!==this._material.parameters.shadowMappingEnabled&&this._material.setParameters({shadowMappingEnabled:x.shadowMap.enabled})}_updateOccludeeState(x){x.hasOccludees!==this._material.parameters.hasOccludees&&this._material.setParameters({hasOccludees:x.hasOccludees})}beginSlot(x){return this._output!==Mt.H.Color&&this._output!==Mt.H.Alpha||(this._updateShadowState(x),this._updateOccludeeState(x)),this._updateParameters(x)}}const Qi=new class Zi extends Ki{constructor(){super(...arguments),this.initTextureTransparent=!1,this.treeRendering=!1,this.hasVertexTangents=!1}};class ki{constructor(x,C){this.vertexBufferLayout=x,this.instanceBufferLayout=C}allocate(x){return this.vertexBufferLayout.createBuffer(x)}elementCount(x){return x.indices.get(re.T.POSITION).length}write(x,C,D,R,N){!function Ii(M,x,C,D,R,N){for(const U of x.fieldNames){const G=M.vertexAttributes.get(U),ee=M.indices.get(U);if(G&&ee)switch(U){case re.T.POSITION:{(0,Je.hu)(3===G.size);const X=R.getField(U,K.ct);X&&yi(ee,G.data,C,X,N);break}case re.T.NORMAL:{(0,Je.hu)(3===G.size);const X=R.getField(U,K.ct);X&&Si(ee,G.data,D,X,N);break}case re.T.UV0:{(0,Je.hu)(2===G.size);const X=R.getField(U,K.Eu);X&&Ci(ee,G.data,X,N);break}case re.T.COLOR:{(0,Je.hu)(3===G.size||4===G.size);const X=R.getField(U,K.mc);X&&Kr(ee,G.data,G.size,X,N);break}case re.T.SYMBOLCOLOR:{(0,Je.hu)(3===G.size||4===G.size);const X=R.getField(U,K.mc);X&&Kr(ee,G.data,G.size,X,N);break}case re.T.TANGENT:{(0,Je.hu)(4===G.size);const X=R.getField(U,K.ek);X&&Li(ee,G.data,D,X,N);break}}else if(U===re.T.OBJECTANDLAYERIDCOLOR&&(0,I.pC)(M.objectAndLayerIdColor)&&4===M.objectAndLayerIdColor.length){const X=M.indices.get(re.T.POSITION);if(X){const ae=X.length,Te=R.getField(U,K.mc);Ri(M.objectAndLayerIdColor,Te,ae,N)}}}}(D,this.vertexBufferLayout,x,C,R,N)}}const ts=(0,S.c)(),rs=(0,S.c)(),is=(0,S.f)(0,0,1),Zr=(0,S.c)(),Sr=(0,S.c)(),Lr=(0,S.c)(),ss=(0,S.c)(),sr=Ce.Z.getLogger("esri.views.3d.layers.graphics.objectResourceUtils");function as(M,x){return Rr.apply(this,arguments)}function Rr(){return Rr=(0,y.Z)(function*(M,x){const C=yield os(M,x),D=yield us(C.textureDefinitions,x);let R=0;for(const N in D)if(D.hasOwnProperty(N)){const U=D[N];R+=null!=U&&U.image?U.image.width*U.image.height*4:0}return{resource:C,textures:D,size:R+(0,ve.Ul)(C)}}),Rr.apply(this,arguments)}function os(M,x){return Ir.apply(this,arguments)}function Ir(){return Ir=(0,y.Z)(function*(M,x){const C=(0,I.pC)(x)&&x.streamDataRequester;if(C)return ns(M,C,x);const D=yield(0,ge.q6)((0,le.default)(M,(0,I.Wg)(x)));if(!0===D.ok)return D.value.data;(0,at.r9)(D.error),Qr(D.error)}),Ir.apply(this,arguments)}function ns(M,x,C){return wr.apply(this,arguments)}function wr(){return wr=(0,y.Z)(function*(M,x,C){const D=yield(0,ge.q6)(x.request(M,"json",C));if(!0===D.ok)return D.value;(0,at.r9)(D.error),Qr(D.error.details.url)}),wr.apply(this,arguments)}function Qr(M){throw new Ee.Z("",`Request for object resource failed: ${M}`)}function ls(M){const x=M.params,C=x.topology;let D=!0;switch(x.vertexAttributes||(sr.warn("Geometry must specify vertex attributes"),D=!1),x.topology){case"PerAttributeArray":break;case"Indexed":case null:case void 0:{const N=x.faces;if(N){if(x.vertexAttributes)for(const U in x.vertexAttributes){const G=N[U];G&&G.values?(null!=G.valueType&&"UInt32"!==G.valueType&&(sr.warn(`Unsupported indexed geometry indices type '${G.valueType}', only UInt32 is currently supported`),D=!1),null!=G.valuesPerElement&&1!==G.valuesPerElement&&(sr.warn(`Unsupported indexed geometry values per element '${G.valuesPerElement}', only 1 is currently supported`),D=!1)):(sr.warn(`Indexed geometry does not specify face indices for '${U}' attribute`),D=!1)}}else sr.warn("Indexed geometries must specify faces"),D=!1;break}default:sr.warn(`Unsupported topology '${C}'`),D=!1}M.params.material||(sr.warn("Geometry requires material"),D=!1);const R=M.params.vertexAttributes;for(const N in R)R[N].values||(sr.warn("Geometries with externally defined attributes are not yet supported"),D=!1);return D}function cs(M,x){const C=[],D=[],R=[],N=[],U=M.resource,G=xe.G.parse(U.version||"1.0","wosr");_s.validate(G);const ee=U.model.name,X=U.model.geometries,ae=U.materialDefinitions,Te=M.textures;let Ie=0;const Le=new Map;for(let Fe=0;Fe<X.length;Fe++){const Ye=X[Fe];if(!ls(Ye))continue;const Ue=hs(Ye),$e=Ye.params.vertexAttributes,De=[];for(const je in $e){const Ve=$e[je];De.push([je,{data:Ve.values,size:Ve.valuesPerElement,exclusive:!0}])}const ot=[];if("PerAttributeArray"!==Ye.params.topology){const je=Ye.params.faces;for(const Ve in je)ot.push([Ve,je[Ve].values])}const _t=Te&&Te[Ue.texture];if(_t&&!Le.has(Ue.texture)){const{image:je,params:Ve}=_t,it=new Nt(je,Ve);N.push(it),Le.set(Ue.texture,it)}const Et=Le.get(Ue.texture),qe=Et?Et.id:void 0;let Ze=R[Ue.material]?R[Ue.material][Ue.texture]:null;if(!Ze){const je=ae[Ue.material.substring(Ue.material.lastIndexOf("/")+1)].params;1===je.transparency&&(je.transparency=0);const Ve=_t&&_t.alphaChannelUsage,it=je.transparency>0||"transparency"===Ve||"maskAndTransparency"===Ve,nt=_t?kr(_t.alphaChannelUsage):void 0,pt={ambient:(0,S.d)(je.diffuse),diffuse:(0,S.d)(je.diffuse),opacity:1-(je.transparency||0),transparent:it,textureAlphaMode:nt,textureAlphaCutoff:.33,textureId:qe,initTextureTransparent:!0,doubleSided:!0,cullFace:ce.Vr.None,colorMixMode:je.externalColorMixMode||"tint",textureAlphaPremultiplied:!!_t&&!!_t.params.preMultiplyAlpha};(0,I.pC)(x)&&x.materialParamsMixin&&Object.assign(pt,x.materialParamsMixin),Ze=new Yr(pt),R[Ue.material]||(R[Ue.material]={}),R[Ue.material][Ue.texture]=Ze}D.push(Ze);const lt=new Ae(De,ot);Ie+=ot.position?ot.position.length:0,C.push(lt)}return{engineResources:[{name:ee,stageResources:{textures:N,materials:D,geometries:C},pivotOffset:U.model.pivotOffset,numberOfVertices:Ie,lodThreshold:null}],referenceBoundingBox:ds(C)}}function ds(M){const x=(0,j.cS)();return M.forEach(C=>{const D=C.boundingInfo;(0,I.pC)(D)&&((0,j.pp)(x,D.getBBMin()),(0,j.pp)(x,D.getBBMax()))}),x}function us(M,x){return Ur.apply(this,arguments)}function Ur(){return Ur=(0,y.Z)(function*(M,x){const C=[];for(const N in M){const U=M[N],G=U.images[0].data;if(!G){sr.warn("Externally referenced texture data is not yet supported");continue}const ee=U.encoding+";base64,"+G,X="/textureDefinitions/"+N,ae="rgba"===U.channels?U.alphaChannelUsage||"transparency":"none",Te={noUnpackFlip:!0,wrap:{s:be.e8.REPEAT,t:be.e8.REPEAT},preMultiplyAlpha:kr(ae)!==ce.JJ.Opaque},Ie=(0,I.pC)(x)&&x.disableTextures?Promise.resolve(null):(0,ue.t)(ee,x);C.push(Ie.then(Le=>({refId:X,image:Le,params:Te,alphaChannelUsage:ae})))}const D=yield Promise.all(C),R={};for(const N of D)R[N.refId]=N;return R}),Ur.apply(this,arguments)}function kr(M){switch(M){case"mask":return ce.JJ.Mask;case"maskAndTransparency":return ce.JJ.MaskBlend;case"none":return ce.JJ.Opaque;default:return ce.JJ.Blend}}function hs(M){const x=M.params;return{id:1,material:x.material,texture:x.texture,region:x.texture}}const _s=new xe.G(1,2,"wosr");var fr=v(79331),ms=v(35995),qr=v(63470),fs=v(9554);function vs(M,x){return Br.apply(this,arguments)}function Br(){return Br=(0,y.Z)(function*(M,x){const C=ei((0,w.pJ)(M));if("wosr"===C.fileType){const ae=yield x.cache?x.cache.loadWOSR(C.url,x):as(C.url,x),{engineResources:Te,referenceBoundingBox:Ie}=cs(ae,x);return{lods:Te,referenceBoundingBox:Ie,isEsriSymbolResource:!1,isWosr:!0}}const D=yield x.cache?x.cache.loadGLTF(C.url,x,x.usePBR):(0,q.Q)(new te.C(x.streamDataRequester),C.url,x,x.usePBR),R=(0,I.U2)(D.model.meta,"ESRI_proxyEllipsoid"),N=D.meta.isEsriSymbolResource&&(0,I.pC)(R)&&D.meta.uri.includes("/RealisticTrees/");N&&!D.customMeta.esriTreeRendering&&(D.customMeta.esriTreeRendering=!0,xs(D,R));const U=D.meta.isEsriSymbolResource?{usePBR:x.usePBR,isSchematic:!1,treeRendering:N,mrrFactors:[0,1,.2]}:{usePBR:x.usePBR,isSchematic:!1,treeRendering:!1,mrrFactors:[0,1,.5]},G={...x.materialParamsMixin,treeRendering:N},{engineResources:ee,referenceBoundingBox:X}=ti(D,U,G,x.skipHighLods&&null==C.specifiedLodIndex?{skipHighLods:!0}:{skipHighLods:!1,singleLodIndex:C.specifiedLodIndex});return{lods:ee,referenceBoundingBox:X,isEsriSymbolResource:D.meta.isEsriSymbolResource,isWosr:!1}}),Br.apply(this,arguments)}function ei(M){const x=M.match(/(.*\.(gltf|glb))(\?lod=([0-9]+))?$/);return x?{fileType:"gltf",url:x[1],specifiedLodIndex:null!=x[4]?Number(x[4]):null}:M.match(/(.*\.(json|json\.gz))$/)?{fileType:"wosr",url:M,specifiedLodIndex:null}:{fileType:"unknown",url:M,specifiedLodIndex:null}}function ti(M,x,C,D){const R=M.model,N=new Array,U=new Map,G=new Map,ee=R.lods.length,X=(0,j.cS)();return R.lods.forEach((ae,Te)=>{const Ie=!0===D.skipHighLods&&(ee>1&&0===Te||ee>3&&1===Te)||!1===D.skipHighLods&&null!=D.singleLodIndex&&Te!==D.singleLodIndex;if(Ie&&0!==Te)return;const Le=new Array;let Fe=0;if(ae.parts.forEach(Ue=>{const{geometry:$e,vertexCount:De}=function gs(M){const x=function Ts(M,x){switch(x){case be.MX.TRIANGLES:return(0,$.nh)(M);case be.MX.TRIANGLE_STRIP:return(0,$.DA)(M);case be.MX.TRIANGLE_FAN:return(0,$.jX)(M)}}(M.indices||M.attributes.position.count,M.primitiveType),C=M.attributes.position.count,D=(0,Z.gS)(K.ct,C);(0,Q.t)(D,M.attributes.position,M.transform);const R=[[re.T.POSITION,{data:D.typedBuffer,size:D.elementCount,exclusive:!0}]],N=[[re.T.POSITION,x]];if((0,I.pC)(M.attributes.normal)){const U=(0,Z.gS)(K.ct,C);(0,W.b)(Dr,M.transform),(0,Q.a)(U,M.attributes.normal,Dr),R.push([re.T.NORMAL,{data:U.typedBuffer,size:U.elementCount,exclusive:!0}]),N.push([re.T.NORMAL,x])}if((0,I.pC)(M.attributes.tangent)){const U=(0,Z.gS)(K.ek,C);(0,W.b)(Dr,M.transform),(0,z.t)(U,M.attributes.tangent,Dr),R.push([re.T.TANGENT,{data:U.typedBuffer,size:U.elementCount,exclusive:!0}]),N.push([re.T.TANGENT,x])}if((0,I.pC)(M.attributes.texCoord0)){const U=(0,Z.gS)(K.Eu,C);(0,ms.n)(U,M.attributes.texCoord0),R.push([re.T.UV0,{data:U.typedBuffer,size:U.elementCount,exclusive:!0}]),N.push([re.T.UV0,x])}if((0,I.pC)(M.attributes.color)){const U=(0,Z.gS)(K.mc,C);if(4===M.attributes.color.elementCount)M.attributes.color instanceof K.ek?(0,z.s)(U,M.attributes.color,255):M.attributes.color instanceof K.mc?(0,qr.c)(U,M.attributes.color):M.attributes.color instanceof K.v6&&(0,z.s)(U,M.attributes.color,1/256);else{(0,qr.f)(U,255,255,255,255);const G=new K.ne(U.buffer,0,4);M.attributes.color instanceof K.ct?(0,Q.s)(G,M.attributes.color,255):M.attributes.color instanceof K.ne?(0,fs.c)(G,M.attributes.color):M.attributes.color instanceof K.mw&&(0,Q.s)(G,M.attributes.color,1/256)}R.push([re.T.COLOR,{data:U.typedBuffer,size:U.elementCount,exclusive:!0}]),N.push([re.T.COLOR,x])}return{geometry:new Ae(R,N),vertexCount:C}}(Ue);Le.push($e),Fe+=De;const ot=$e.boundingInfo;(0,I.pC)(ot)&&0===Te&&((0,j.pp)(X,ot.getBBMin()),(0,j.pp)(X,ot.getBBMax()))}),Ie)return;const Ye=new de(ae.name,{textures:new Array,materials:new Array,geometries:Le},ae.lodThreshold,[0,0,0],Fe);N.push(Ye),ae.parts.forEach(Ue=>{const $e=Ue.material+(Ue.attributes.normal?"_normal":"")+(Ue.attributes.color?"_color":"")+(Ue.attributes.texCoord0?"_texCoord0":"")+(Ue.attributes.tangent?"_tangent":""),De=R.materials.get(Ue.material),ot=(0,I.pC)(Ue.attributes.texCoord0),_t=(0,I.pC)(Ue.attributes.normal);if((0,I.Wi)(De))return;const Et=function ps(M){switch(M){case"BLEND":return ce.JJ.Blend;case"MASK":return ce.JJ.Mask;case"OPAQUE":case null:case void 0:return ce.JJ.Opaque}}(De.alphaMode);if(!U.has($e)){if(ot){const pt=(Ft,Vt=!1)=>{if((0,I.pC)(Ft)&&!G.has(Ft)){const $t=R.textures.get(Ft);(0,I.pC)($t)&&G.set(Ft,new Nt($t.data,Vt?{...$t.parameters,preMultiplyAlpha:Vt}:$t.parameters))}};pt(De.textureColor,Et!==ce.JJ.Opaque),pt(De.textureNormal),pt(De.textureOcclusion),pt(De.textureEmissive),pt(De.textureMetallicRoughness)}const qe=De.color[0]**(1/fr.K),Ze=De.color[1]**(1/fr.K),lt=De.color[2]**(1/fr.K),je=De.emissiveFactor[0]**(1/fr.K),Ve=De.emissiveFactor[1]**(1/fr.K),it=De.emissiveFactor[2]**(1/fr.K),nt=(0,I.pC)(De.textureColor)&&ot?G.get(De.textureColor):null;U.set($e,new Yr({...x,transparent:Et===ce.JJ.Blend,customDepthTest:ce.Gv.Lequal,textureAlphaMode:Et,textureAlphaCutoff:De.alphaCutoff,diffuse:[qe,Ze,lt],ambient:[qe,Ze,lt],opacity:De.opacity,doubleSided:De.doubleSided,doubleSidedType:"winding-order",cullFace:De.doubleSided?ce.Vr.None:ce.Vr.Back,hasVertexColors:!!Ue.attributes.color,hasVertexTangents:!!Ue.attributes.tangent,normals:_t?"default":"screenDerivative",castShadows:!0,receiveSSAO:!0,textureId:(0,I.pC)(nt)?nt.id:void 0,colorMixMode:De.colorMixMode,normalTextureId:(0,I.pC)(De.textureNormal)&&ot?G.get(De.textureNormal).id:void 0,textureAlphaPremultiplied:(0,I.pC)(nt)&&!!nt.params.preMultiplyAlpha,occlusionTextureId:(0,I.pC)(De.textureOcclusion)&&ot?G.get(De.textureOcclusion).id:void 0,emissiveTextureId:(0,I.pC)(De.textureEmissive)&&ot?G.get(De.textureEmissive).id:void 0,metallicRoughnessTextureId:(0,I.pC)(De.textureMetallicRoughness)&&ot?G.get(De.textureMetallicRoughness).id:void 0,emissiveFactor:[je,Ve,it],mrrFactors:[De.metallicFactor,De.roughnessFactor,x.mrrFactors[2]],isSchematic:!1,colorTextureTransformMatrix:ie(De.colorTextureTransform),normalTextureTransformMatrix:ie(De.normalTextureTransform),occlusionTextureTransformMatrix:ie(De.occlusionTextureTransform),emissiveTextureTransformMatrix:ie(De.emissiveTextureTransform),metallicRoughnessTextureTransformMatrix:ie(De.metallicRoughnessTextureTransform),...C}))}if(Ye.stageResources.materials.push(U.get($e)),ot){const qe=Ze=>{(0,I.pC)(Ze)&&Ye.stageResources.textures.push(G.get(Ze))};qe(De.textureColor),qe(De.textureNormal),qe(De.textureOcclusion),qe(De.textureEmissive),qe(De.textureMetallicRoughness)}})}),{engineResources:N,referenceBoundingBox:X}}const Dr=(0,V.c)();function xs(M,x){for(let C=0;C<M.model.lods.length;++C){const D=M.model.lods[C];for(const R of D.parts){const N=R.attributes.normal;if((0,I.Wi)(N))return;const U=R.attributes.position,G=U.count,ee=(0,S.c)(),X=(0,S.c)(),ae=(0,S.c)(),Te=(0,Z.gS)(K.mc,G),Ie=(0,Z.gS)(K.ct,G),Le=(0,H.a)((0,L.c)(),R.transform);for(let Fe=0;Fe<G;Fe++){U.getVec(Fe,X),N.getVec(Fe,ee),(0,A.m)(X,X,R.transform),(0,A.b)(ae,X,x.center),(0,A.C)(ae,ae,x.radius);const Ye=ae[2],Ue=(0,A.l)(ae),$e=Math.min(.45+.55*Ue*Ue,1);(0,A.C)(ae,ae,x.radius),null!==Le&&(0,A.m)(ae,ae,Le),(0,A.n)(ae,ae),C+1!==M.model.lods.length&&M.model.lods.length>1&&(0,A.h)(ae,ae,ee,Ye>-1?.2:Math.min(-4*Ye-3.8,1)),Ie.setVec(Fe,ae),Te.set(Fe,0,255*$e),Te.set(Fe,1,255*$e),Te.set(Fe,2,255*$e),Te.set(Fe,3,255)}R.attributes.normal=Ie,R.attributes.color=Te}}}},19625:(fe,Y,v)=>{v.d(Y,{U$:()=>V});var y=v(60479),w=v(81096);class I{constructor(L,A){this.layout=L,this.buffer="number"==typeof A?new ArrayBuffer(A*L.stride):A;for(const S of L.fieldNames){const j=L.fields.get(S);this[S]=new j.constructor(this.buffer,j.offset,this.stride)}}get stride(){return this.layout.stride}get count(){return this.buffer.byteLength/this.stride}get byteLength(){return this.buffer.byteLength}getField(L,A){const S=this[L];return S&&S.elementCount===A.ElementCount&&S.elementType===A.ElementType?S:null}slice(L,A){return new I(this.layout,this.buffer.slice(L*this.stride,A*this.stride))}copyFrom(L,A,S,j){const K=this.stride;if(K%4==0){const Q=new Uint32Array(L.buffer,A*K,j*K/4);new Uint32Array(this.buffer,S*K,j*K/4).set(Q)}else{const Q=new Uint8Array(L.buffer,A*K,j*K);new Uint8Array(this.buffer,S*K,j*K).set(Q)}}}class W{constructor(){this.stride=0,this.fields=new Map,this.fieldNames=[]}vec2f(L,A){return this._appendField(L,y.Eu,A),this}vec2f64(L,A){return this._appendField(L,y.q6,A),this}vec3f(L,A){return this._appendField(L,y.ct,A),this}vec3f64(L,A){return this._appendField(L,y.fP,A),this}vec4f(L,A){return this._appendField(L,y.ek,A),this}vec4f64(L,A){return this._appendField(L,y.Cd,A),this}mat3f(L,A){return this._appendField(L,y.gK,A),this}mat3f64(L,A){return this._appendField(L,y.ey,A),this}mat4f(L,A){return this._appendField(L,y.bj,A),this}mat4f64(L,A){return this._appendField(L,y.O1,A),this}vec4u8(L,A){return this._appendField(L,y.mc,A),this}f32(L,A){return this._appendField(L,y.ly,A),this}f64(L,A){return this._appendField(L,y.oS,A),this}u8(L,A){return this._appendField(L,y.D_,A),this}u16(L,A){return this._appendField(L,y.av,A),this}i8(L,A){return this._appendField(L,y.Hz,A),this}vec2i8(L,A){return this._appendField(L,y.Vs,A),this}vec2i16(L,A){return this._appendField(L,y.or,A),this}vec2u8(L,A){return this._appendField(L,y.xA,A),this}vec4u16(L,A){return this._appendField(L,y.v6,A),this}u32(L,A){return this._appendField(L,y.Nu,A),this}_appendField(L,A,S){const j=A.ElementCount*(0,w.n1)(A.ElementType);this.fields.set(L,{size:j,constructor:A,offset:this.stride,optional:S}),this.stride+=j,this.fieldNames.push(L)}alignTo(L){return this.stride=Math.floor((this.stride+L-1)/L)*L,this}hasField(L){return this.fieldNames.includes(L)}createBuffer(L){return new I(this,L)}createView(L){return new I(this,L)}clone(){const L=new W;return L.stride=this.stride,L.fields=new Map,this.fields.forEach((A,S)=>L.fields.set(S,A)),L.fieldNames=this.fieldNames.slice(),L.BufferType=this.BufferType,L}}function V(){return new W}},52382:(fe,Y,v)=>{v.d(Y,{Zu:()=>H,bA:()=>L,qj:()=>A});var y=v(13934),w=v(51040),I=v(95285),W=v(17625);function V(S){S.varyings.add("linearDepth","float")}function H(S){S.vertex.uniforms.add(new I.A("nearFar",(j,K)=>K.camera.nearFar))}function L(S){S.vertex.code.add(W.H`float calculateLinearDepth(vec2 nearFar,float z) {
return (-z - nearFar[0]) / (nearFar[1] - nearFar[0]);
}`)}function A(S,j){const{vertex:K}=S;switch(j.output){case y.H.Color:if(j.receiveShadows)return V(S),void K.code.add(W.H`void forwardLinearDepth() { linearDepth = gl_Position.w; }`);break;case y.H.Depth:case y.H.Shadow:case y.H.ShadowHighlight:case y.H.ShadowExludeHighlight:return S.include(w.up,j),V(S),H(S),L(S),void K.code.add(W.H`void forwardLinearDepth() {
linearDepth = calculateLinearDepth(nearFar, vPosition_view.z);
}`)}K.code.add(W.H`void forwardLinearDepth() {}`)}},73132:(fe,Y,v)=>{v.d(Y,{w:()=>w});var y=v(17625);function w(I){I.vertex.code.add(y.H`vec4 offsetBackfacingClipPosition(vec4 posClip, vec3 posWorld, vec3 normalWorld, vec3 camPosWorld) {
vec3 camToVert = posWorld - camPosWorld;
bool isBackface = dot(camToVert, normalWorld) > 0.0;
if (isBackface) {
posClip.z += 0.0000003 * posClip.w;
}
return posClip;
}`)}},98071:(fe,Y,v)=>{v.d(Y,{k:()=>I});var y=v(17625),w=v(16396);function I(W,V=!0){W.attributes.add(w.T.POSITION,"vec2"),V&&W.varyings.add("uv","vec2"),W.vertex.code.add(y.H`
    void main(void) {
      gl_Position = vec4(position, 0.0, 1.0);
      ${V?y.H`uv = position * 0.5 + vec2(0.5);`:""}
    }
  `)}},13934:(fe,Y,v)=>{var y,w;v.d(Y,{H:()=>y}),(w=y||(y={}))[w.Color=0]="Color",w[w.Depth=1]="Depth",w[w.Normal=2]="Normal",w[w.Shadow=3]="Shadow",w[w.ShadowHighlight=4]="ShadowHighlight",w[w.ShadowExludeHighlight=5]="ShadowExludeHighlight",w[w.Highlight=6]="Highlight",w[w.Alpha=7]="Alpha",w[w.ObjectAndLayerIdColor=8]="ObjectAndLayerIdColor",w[w.COUNT=9]="COUNT"},78925:(fe,Y,v)=>{v.d(Y,{f5:()=>K});var y=v(62208),w=v(28347),I=v(43703),W=v(84161),V=v(28093),H=v(77739),A=(v(97139),v(17625));function K(le,ge){!function Q(le,ge,ve){if(!ge.hasSlicePlane){const xe=A.H`#define rejectBySlice(_pos_) false
#define discardBySlice(_pos_) {}
#define highlightSlice(_color_, _pos_) (_color_)`;return ge.hasSliceInVertexProgram&&le.vertex.code.add(xe),void le.fragment.code.add(xe)}le.extensions.add("GL_OES_standard_derivatives"),ge.hasSliceInVertexProgram&&le.vertex.uniforms.add(ve),le.fragment.uniforms.add(ve);const Ee=A.H`struct SliceFactors {
float front;
float side0;
float side1;
float side2;
float side3;
};
SliceFactors calculateSliceFactors(vec3 pos) {
vec3 rel = pos - slicePlaneOrigin;
vec3 slicePlaneNormal = -cross(slicePlaneBasis1, slicePlaneBasis2);
float slicePlaneW = -dot(slicePlaneNormal, slicePlaneOrigin);
float basis1Len2 = dot(slicePlaneBasis1, slicePlaneBasis1);
float basis2Len2 = dot(slicePlaneBasis2, slicePlaneBasis2);
float basis1Dot = dot(slicePlaneBasis1, rel);
float basis2Dot = dot(slicePlaneBasis2, rel);
return SliceFactors(
dot(slicePlaneNormal, pos) + slicePlaneW,
-basis1Dot - basis1Len2,
basis1Dot - basis1Len2,
-basis2Dot - basis2Len2,
basis2Dot - basis2Len2
);
}
bool sliceByFactors(SliceFactors factors) {
return factors.front < 0.0
&& factors.side0 < 0.0
&& factors.side1 < 0.0
&& factors.side2 < 0.0
&& factors.side3 < 0.0;
}
bool sliceEnabled() {
return dot(slicePlaneBasis1, slicePlaneBasis1) != 0.0;
}
bool sliceByPlane(vec3 pos) {
return sliceEnabled() && sliceByFactors(calculateSliceFactors(pos));
}
#define rejectBySlice(_pos_) sliceByPlane(_pos_)
#define discardBySlice(_pos_) { if (sliceByPlane(_pos_)) discard; }`,Ce=A.H`vec4 applySliceHighlight(vec4 color, vec3 pos) {
SliceFactors factors = calculateSliceFactors(pos);
const float HIGHLIGHT_WIDTH = 1.0;
const vec4 HIGHLIGHT_COLOR = vec4(0.0, 0.0, 0.0, 0.3);
factors.front /= (2.0 * HIGHLIGHT_WIDTH) * fwidth(factors.front);
factors.side0 /= (2.0 * HIGHLIGHT_WIDTH) * fwidth(factors.side0);
factors.side1 /= (2.0 * HIGHLIGHT_WIDTH) * fwidth(factors.side1);
factors.side2 /= (2.0 * HIGHLIGHT_WIDTH) * fwidth(factors.side2);
factors.side3 /= (2.0 * HIGHLIGHT_WIDTH) * fwidth(factors.side3);
if (sliceByFactors(factors)) {
return color;
}
float highlightFactor = (1.0 - step(0.5, factors.front))
* (1.0 - step(0.5, factors.side0))
* (1.0 - step(0.5, factors.side1))
* (1.0 - step(0.5, factors.side2))
* (1.0 - step(0.5, factors.side3));
return mix(color, vec4(HIGHLIGHT_COLOR.rgb, color.a), highlightFactor * HIGHLIGHT_COLOR.a);
}`,at=ge.hasSliceHighlight?A.H`
        ${Ce}
        #define highlightSlice(_color_, _pos_) (sliceEnabled() ? applySliceHighlight(_color_, _pos_) : (_color_))
      `:A.H`#define highlightSlice(_color_, _pos_) (_color_)`;ge.hasSliceInVertexProgram&&le.vertex.code.add(Ee),le.fragment.code.add(Ee),le.fragment.code.add(at)}(le,ge,[new H.B("slicePlaneOrigin",(ve,Ee)=>function q(le,ge,ve){if((0,y.Wi)(ve.slicePlane))return V.Z;const Ee=z(le,ge,ve),Ce=Z(Ee,ve.slicePlane),at=te(le,Ee,ve);return(0,y.pC)(at)?(0,W.m)(J,Ce,at):Ce}(ge,ve,Ee)),new H.B("slicePlaneBasis1",(ve,Ee)=>{var Ce;return $(ge,ve,Ee,null===(Ce=(0,y.Wg)(Ee.slicePlane))||void 0===Ce?void 0:Ce.basis1)}),new H.B("slicePlaneBasis2",(ve,Ee)=>{var Ce;return $(ge,ve,Ee,null===(Ce=(0,y.Wg)(Ee.slicePlane))||void 0===Ce?void 0:Ce.basis2)})])}function z(le,ge,ve){return le.instancedDoublePrecision?(0,W.s)(k,ve.camera.viewInverseTransposeMatrix[3],ve.camera.viewInverseTransposeMatrix[7],ve.camera.viewInverseTransposeMatrix[11]):ge.slicePlaneLocalOrigin}function Z(le,ge){return(0,y.pC)(le)?(0,W.b)(J,ge.origin,le):ge.origin}function te(le,ge,ve){return le.hasSliceTranslatedView?(0,y.pC)(ge)?(0,w.v)(de,ve.camera.viewMatrix,ge):ve.camera.viewMatrix:null}function $(le,ge,ve,Ee){if((0,y.Wi)(Ee)||(0,y.Wi)(ve.slicePlane))return V.Z;const Ce=z(le,ge,ve),at=Z(Ce,ve.slicePlane),xe=te(le,Ce,ve);return(0,y.pC)(xe)?((0,W.a)(ie,Ee,at),(0,W.m)(J,at,xe),(0,W.m)(ie,ie,xe),(0,W.b)(ie,ie,J)):Ee}const k=(0,V.c)(),J=(0,V.c)(),ie=(0,V.c)(),de=(0,I.c)()},24255:(fe,Y,v)=>{v.d(Y,{w:()=>I});var y=v(52382),w=v(17625);function I(W,V){if((0,y.bA)(W),V.hasModelTransformation)return W.vertex.code.add(w.H`vec4 transformPositionWithDepth(mat4 proj, mat4 view, mat4 model, vec3 pos, vec2 nearFar, out float depth) {
vec4 eye = view * (model * vec4(pos, 1.0));
depth = calculateLinearDepth(nearFar, eye.z);
return proj * eye;
}`),void W.vertex.code.add(w.H`vec4 transformPosition(mat4 proj, mat4 view, mat4 model, vec3 pos) {
return proj * (view * (model * vec4(pos, 1.0)));
}`);W.vertex.code.add(w.H`vec4 transformPositionWithDepth(mat4 proj, mat4 view, vec3 pos, vec2 nearFar, out float depth) {
vec4 eye = view * vec4(pos, 1.0);
depth = calculateLinearDepth(nearFar,eye.z);
return proj * eye;
}`),W.vertex.code.add(w.H`vec4 transformPosition(mat4 proj, mat4 view, vec3 pos) {
return proj * (view * vec4(pos, 1.0));
}`)}},60355:(fe,Y,v)=>{v.d(Y,{f:()=>z});var y=v(17626),w=v(84161),I=v(28093),W=v(13934),V=v(7228),H=v(99198),L=v(77739),A=v(17625),S=v(87601),j=v(16396),K=v(2757);function z(te,q){q.instanced&&q.instancedDoublePrecision&&(te.attributes.add(j.T.MODELORIGINHI,"vec3"),te.attributes.add(j.T.MODELORIGINLO,"vec3"),te.attributes.add(j.T.MODEL,"mat3"),te.attributes.add(j.T.MODELNORMAL,"mat3"));const $=te.vertex;q.instancedDoublePrecision&&($.include(V.$,q),$.uniforms.add(new L.B("viewOriginHi",(k,J)=>(0,K.U8)((0,w.s)(Z,J.camera.viewInverseTransposeMatrix[3],J.camera.viewInverseTransposeMatrix[7],J.camera.viewInverseTransposeMatrix[11]),Z))),$.uniforms.add(new L.B("viewOriginLo",(k,J)=>(0,K.GB)((0,w.s)(Z,J.camera.viewInverseTransposeMatrix[3],J.camera.viewInverseTransposeMatrix[7],J.camera.viewInverseTransposeMatrix[11]),Z)))),$.code.add(A.H`
    vec3 calculateVPos() {
      ${q.instancedDoublePrecision?"return model * localPosition().xyz;":"return localPosition().xyz;"}
    }
    `),$.code.add(A.H`
    vec3 subtractOrigin(vec3 _pos) {
      ${q.instancedDoublePrecision?A.H`
          vec3 originDelta = dpAdd(viewOriginHi, viewOriginLo, -modelOriginHi, -modelOriginLo);
          return _pos - originDelta;`:"return vpos;"}
    }
    `),$.code.add(A.H`
    vec3 dpNormal(vec4 _normal) {
      ${q.instancedDoublePrecision?"return normalize(modelNormal * _normal.xyz);":"return normalize(_normal.xyz);"}
    }
    `),q.output===W.H.Normal&&((0,H._8)($),$.code.add(A.H`
    vec3 dpNormalView(vec4 _normal) {
      ${q.instancedDoublePrecision?"return normalize((viewNormal * vec4(modelNormal * _normal.xyz, 1.0)).xyz);":"return normalize((viewNormal * _normal).xyz);"}
    }
    `)),q.hasVertexTangents&&$.code.add(A.H`
    vec4 dpTransformVertexTangent(vec4 _tangent) {
      ${q.instancedDoublePrecision?"return vec4(modelNormal * _tangent.xyz, _tangent.w);":"return _tangent;"}

    }
    `)}(0,y._)([(0,S.o)()],class Q extends S.m{constructor(){super(...arguments),this.instancedDoublePrecision=!1}}.prototype,"instancedDoublePrecision",void 0);const Z=(0,I.c)()},26859:(fe,Y,v)=>{v.d(Y,{O:()=>W,h:()=>V});var y=v(17625);function w(H){const L=y.H`vec3 decodeNormal(vec2 f) {
float z = 1.0 - abs(f.x) - abs(f.y);
return vec3(f + sign(f) * min(z, 0.0), z);
}`;H.vertex.code.add(L)}var V,H,I=v(16396);function W(H,L){L.normalType===V.Attribute&&(H.attributes.add(I.T.NORMAL,"vec3"),H.vertex.code.add(y.H`vec3 normalModel() {
return normal;
}`)),L.normalType===V.CompressedAttribute&&(H.include(w),H.attributes.add(I.T.NORMALCOMPRESSED,"vec2"),H.vertex.code.add(y.H`vec3 normalModel() {
return decodeNormal(normalCompressed);
}`)),L.normalType===V.ScreenDerivative&&(H.extensions.add("GL_OES_standard_derivatives"),H.fragment.code.add(y.H`vec3 screenDerivativeNormal(vec3 positionView) {
return normalize(cross(dFdx(positionView), dFdy(positionView)));
}`))}(H=V||(V={}))[H.Attribute=0]="Attribute",H[H.CompressedAttribute=1]="CompressedAttribute",H[H.Ground=2]="Ground",H[H.ScreenDerivative=3]="ScreenDerivative",H[H.COUNT=4]="COUNT"},84833:(fe,Y,v)=>{v.d(Y,{f:()=>I});var y=v(17625),w=v(16396);function I(W){W.attributes.add(w.T.POSITION,"vec3"),W.vertex.code.add(y.H`vec3 positionModel() { return position; }`)}},72326:(fe,Y,v)=>{v.d(Y,{R:()=>L});var y=v(9044),w=v(17625);function I(A){A.vertex.code.add(w.H`
    vec4 decodeSymbolColor(vec4 symbolColor, out int colorMixMode) {
      float symbolAlpha = 0.0;

      const float maxTint = 85.0;
      const float maxReplace = 170.0;
      const float scaleAlpha = 3.0;

      if (symbolColor.a > maxReplace) {
        colorMixMode = ${w.H.int(y.a9.Multiply)};
        symbolAlpha = scaleAlpha * (symbolColor.a - maxReplace);
      } else if (symbolColor.a > maxTint) {
        colorMixMode = ${w.H.int(y.a9.Replace)};
        symbolAlpha = scaleAlpha * (symbolColor.a - maxTint);
      } else if (symbolColor.a > 0.0) {
        colorMixMode = ${w.H.int(y.a9.Tint)};
        symbolAlpha = scaleAlpha * symbolColor.a;
      } else {
        colorMixMode = ${w.H.int(y.a9.Multiply)};
        symbolAlpha = 0.0;
      }

      return vec4(symbolColor.r, symbolColor.g, symbolColor.b, symbolAlpha);
    }
  `)}var W=v(18952),V=v(16396),H=v(50229);function L(A,S){S.hasSymbolColors?(A.include(I),A.attributes.add(V.T.SYMBOLCOLOR,"vec4"),A.varyings.add("colorMixMode","mediump float"),A.vertex.code.add(w.H`int symbolColorMixMode;
vec4 getSymbolColor() {
return decodeSymbolColor(symbolColor, symbolColorMixMode) * 0.003921568627451;
}
void forwardColorMixMode() {
colorMixMode = float(symbolColorMixMode) + 0.5;
}`)):(A.fragment.uniforms.add(new W._("colorMixMode",j=>H.FZ[j.colorMixMode])),A.vertex.code.add(w.H`vec4 getSymbolColor() { return vec4(1.0); }
void forwardColorMixMode() {}`))}},36603:(fe,Y,v)=>{v.d(Y,{D:()=>V,N:()=>W});var W,H,y=v(94573),w=v(17625),I=v(16396);function V(H,L){switch(L.textureCoordinateType){case W.Default:return H.attributes.add(I.T.UV0,"vec2"),H.varyings.add("vuv0","vec2"),void H.vertex.code.add(w.H`void forwardTextureCoordinates() {
vuv0 = uv0;
}`);case W.Compressed:return H.attributes.add(I.T.UV0,"vec2"),H.varyings.add("vuv0","vec2"),void H.vertex.code.add(w.H`vec2 getUV0() {
return uv0 / 16384.0;
}
void forwardTextureCoordinates() {
vuv0 = getUV0();
}`);case W.Atlas:return H.attributes.add(I.T.UV0,"vec2"),H.varyings.add("vuv0","vec2"),H.attributes.add(I.T.UVREGION,"vec4"),H.varyings.add("vuvRegion","vec4"),void H.vertex.code.add(w.H`void forwardTextureCoordinates() {
vuv0 = uv0;
vuvRegion = uvRegion;
}`);default:(0,y.Bg)(L.textureCoordinateType);case W.None:return void H.vertex.code.add(w.H`void forwardTextureCoordinates() {}`);case W.COUNT:return}}(H=W||(W={}))[H.None=0]="None",H[H.Default=1]="Default",H[H.Atlas=2]="Atlas",H[H.Compressed=3]="Compressed",H[H.COUNT=4]="COUNT"},58173:(fe,Y,v)=>{v.d(Y,{c:()=>I});var y=v(17625),w=v(16396);function I(W,V){V.hasVertexColors?(W.attributes.add(w.T.COLOR,"vec4"),W.varyings.add("vColor","vec4"),W.vertex.code.add(y.H`void forwardVertexColor() { vColor = color; }`),W.vertex.code.add(y.H`void forwardNormalizedVertexColor() { vColor = color * 0.003921568627451; }`)):W.vertex.code.add(y.H`void forwardVertexColor() {}
void forwardNormalizedVertexColor() {}`)}},21799:(fe,Y,v)=>{v.d(Y,{Bb:()=>A,d4:()=>S});var y=v(550),I=(v(4794),v(26859)),W=v(51040),V=v(17625),H=v(9546),L=v(91574);function A(K,Q){Q.normalType===I.h.Attribute||Q.normalType===I.h.CompressedAttribute?(K.include(I.O,Q),K.varyings.add("vNormalWorld","vec3"),K.varyings.add("vNormalView","vec3"),K.vertex.uniforms.add([new H.j("transformNormalGlobalFromModel",z=>z.transformNormalGlobalFromModel),new L.c("transformNormalViewFromGlobal",z=>z.transformNormalViewFromGlobal)]),K.vertex.code.add(V.H`void forwardNormal() {
vNormalWorld = transformNormalGlobalFromModel * normalModel();
vNormalView = transformNormalViewFromGlobal * vNormalWorld;
}`)):Q.normalType===I.h.Ground?(K.include(W.up,Q),K.varyings.add("vNormalWorld","vec3"),K.vertex.code.add(V.H`
    void forwardNormal() {
      vNormalWorld = ${Q.spherical?V.H`normalize(vPositionWorldCameraRelative);`:V.H`vec3(0.0, 0.0, 1.0);`}
    }
    `)):K.vertex.code.add(V.H`void forwardNormal() {}`)}class S extends W.su{constructor(){super(...arguments),this.transformNormalViewFromGlobal=(0,y.c)()}}},51040:(fe,Y,v)=>{v.d(Y,{su:()=>Z,up:()=>z});var y=v(550),w=v(43703),W=(v(14658),v(28093)),V=v(84833),H=v(7228),L=v(77739),A=v(97139),S=v(17625),j=v(9546),K=v(91574),Q=v(63123);function z(q,$){q.include(V.f);const k=q.vertex;k.include(H.$,$),q.varyings.add("vPositionWorldCameraRelative","vec3"),q.varyings.add("vPosition_view","vec3"),k.uniforms.add([new A.J("transformWorldFromViewTH",J=>J.transformWorldFromViewTH),new A.J("transformWorldFromViewTL",J=>J.transformWorldFromViewTL),new K.c("transformViewFromCameraRelativeRS",J=>J.transformViewFromCameraRelativeRS),new Q.g("transformProjFromView",J=>J.transformProjFromView),new j.j("transformWorldFromModelRS",J=>J.transformWorldFromModelRS),new L.B("transformWorldFromModelTH",J=>J.transformWorldFromModelTH),new L.B("transformWorldFromModelTL",J=>J.transformWorldFromModelTL)]),k.code.add(S.H`vec3 positionWorldCameraRelative() {
vec3 rotatedModelPosition = transformWorldFromModelRS * positionModel();
vec3 transform_CameraRelativeFromModel = dpAdd(
transformWorldFromModelTL,
transformWorldFromModelTH,
-transformWorldFromViewTL,
-transformWorldFromViewTH
);
return transform_CameraRelativeFromModel + rotatedModelPosition;
}`),k.code.add(S.H`
    void forwardPosition(float fOffset) {
      vPositionWorldCameraRelative = positionWorldCameraRelative();
      if (fOffset != 0.0) {
        vPositionWorldCameraRelative += fOffset * ${$.spherical?S.H`normalize(transformWorldFromViewTL + vPositionWorldCameraRelative)`:S.H`vec3(0.0, 0.0, 1.0)`};
      }

      vPosition_view = transformViewFromCameraRelativeRS * vPositionWorldCameraRelative;
      gl_Position = transformProjFromView * vec4(vPosition_view, 1.0);
    }
  `),q.fragment.uniforms.add(new A.J("transformWorldFromViewTL",J=>J.transformWorldFromViewTL)),k.code.add(S.H`vec3 positionWorld() {
return transformWorldFromViewTL + vPositionWorldCameraRelative;
}`),q.fragment.code.add(S.H`vec3 positionWorld() {
return transformWorldFromViewTL + vPositionWorldCameraRelative;
}`)}class Z extends S.K{constructor(){super(...arguments),this.transformWorldFromViewTH=(0,W.c)(),this.transformWorldFromViewTL=(0,W.c)(),this.transformViewFromCameraRelativeRS=(0,y.c)(),this.transformProjFromView=(0,w.c)()}}},85982:(fe,Y,v)=>{v.d(Y,{i:()=>V});var y=v(94573),w=v(36603),I=v(17625);function W(H){H.extensions.add("GL_EXT_shader_texture_lod"),H.extensions.add("GL_OES_standard_derivatives"),H.fragment.code.add(I.H`#ifndef GL_EXT_shader_texture_lod
float calcMipMapLevel(const vec2 ddx, const vec2 ddy) {
float deltaMaxSqr = max(dot(ddx, ddx), dot(ddy, ddy));
return max(0.0, 0.5 * log2(deltaMaxSqr));
}
#endif
vec4 textureAtlasLookup(sampler2D texture, vec2 textureSize, vec2 textureCoordinates, vec4 atlasRegion) {
vec2 atlasScale = atlasRegion.zw - atlasRegion.xy;
vec2 uvAtlas = fract(textureCoordinates) * atlasScale + atlasRegion.xy;
float maxdUV = 0.125;
vec2 dUVdx = clamp(dFdx(textureCoordinates), -maxdUV, maxdUV) * atlasScale;
vec2 dUVdy = clamp(dFdy(textureCoordinates), -maxdUV, maxdUV) * atlasScale;
#ifdef GL_EXT_shader_texture_lod
return texture2DGradEXT(texture, uvAtlas, dUVdx, dUVdy);
#else
vec2 dUVdxAuto = dFdx(uvAtlas);
vec2 dUVdyAuto = dFdy(uvAtlas);
float mipMapLevel = calcMipMapLevel(dUVdx * textureSize, dUVdy * textureSize);
float autoMipMapLevel = calcMipMapLevel(dUVdxAuto * textureSize, dUVdyAuto * textureSize);
return texture2D(texture, uvAtlas, mipMapLevel - autoMipMapLevel);
#endif
}`)}function V(H,L){switch(H.include(w.D,L),H.fragment.code.add(I.H`
  struct TextureLookupParameter {
    vec2 uv;
    ${L.supportsTextureAtlas?"vec2 size;":""}
  } vtc;
  `),L.textureCoordinateType){case w.N.Default:case w.N.Compressed:return void H.fragment.code.add(I.H`vec4 textureLookup(sampler2D texture, TextureLookupParameter params) {
return texture2D(texture, params.uv);
}`);case w.N.Atlas:return H.include(W),void H.fragment.code.add(I.H`vec4 textureLookup(sampler2D texture, TextureLookupParameter params) {
return textureAtlasLookup(texture, params.size, params.uv, vuvRegion);
}`);default:(0,y.Bg)(L.textureCoordinateType);case w.N.None:case w.N.COUNT:return}}},52071:(fe,Y,v)=>{v.d(Y,{L:()=>K});var y=v(993),w=v(4794),I=v(69960),W=v(17625);function V(Z){Z.vertex.code.add(W.H`float screenSizePerspectiveMinSize(float size, vec4 factor) {
float nonZeroSize = 1.0 - step(size, 0.0);
return (
factor.z * (
1.0 +
nonZeroSize *
2.0 * factor.w / (
size + (1.0 - nonZeroSize)
)
)
);
}`),Z.vertex.code.add(W.H`float screenSizePerspectiveViewAngleDependentFactor(float absCosAngle) {
return absCosAngle * absCosAngle * absCosAngle;
}`),Z.vertex.code.add(W.H`vec4 screenSizePerspectiveScaleFactor(float absCosAngle, float distanceToCamera, vec4 params) {
return vec4(
min(params.x / (distanceToCamera - params.y), 1.0),
screenSizePerspectiveViewAngleDependentFactor(absCosAngle),
params.z,
params.w
);
}`),Z.vertex.code.add(W.H`float applyScreenSizePerspectiveScaleFactorFloat(float size, vec4 factor) {
return max(mix(size * factor.x, size, factor.y), screenSizePerspectiveMinSize(size, factor));
}`),Z.vertex.code.add(W.H`float screenSizePerspectiveScaleFloat(float size, float absCosAngle, float distanceToCamera, vec4 params) {
return applyScreenSizePerspectiveScaleFactorFloat(
size,
screenSizePerspectiveScaleFactor(absCosAngle, distanceToCamera, params)
);
}`),Z.vertex.code.add(W.H`vec2 applyScreenSizePerspectiveScaleFactorVec2(vec2 size, vec4 factor) {
return mix(size * clamp(factor.x, screenSizePerspectiveMinSize(size.y, factor) / max(1e-5, size.y), 1.0), size, factor.y);
}`),Z.vertex.code.add(W.H`vec2 screenSizePerspectiveScaleVec2(vec2 size, float absCosAngle, float distanceToCamera, vec4 params) {
return applyScreenSizePerspectiveScaleFactorVec2(size, screenSizePerspectiveScaleFactor(absCosAngle, distanceToCamera, params));
}`)}const S=(0,w.c)();var j=v(99198);function K(Z,te){const q=Z.vertex;te.hasVerticalOffset?(function z(Z){Z.uniforms.add(new I.N("verticalOffset",(te,q)=>{const{minWorldLength:$,maxWorldLength:k,screenLength:J}=te.verticalOffset,ie=Math.tan(.5*q.camera.fovY)/(.5*q.camera.fullViewport[3]);return(0,y.s)(Q,J*(q.camera.pixelRatio||1),ie,$,k)}))}(q),te.hasScreenSizePerspective&&(Z.include(V),function L(Z){Z.uniforms.add(new I.N("screenSizePerspectiveAlignment",te=>function A(Z){return(0,y.s)(S,Z.parameters.divisor,Z.parameters.offset,Z.parameters.minPixelSize,Z.paddingPixelsOverride)}(te.screenSizePerspectiveAlignment||te.screenSizePerspective)))}(q),(0,j.hY)(Z.vertex,te)),q.code.add(W.H`
      vec3 calculateVerticalOffset(vec3 worldPos, vec3 localOrigin) {
        float viewDistance = length((view * vec4(worldPos, 1.0)).xyz);
        ${te.spherical?W.H`vec3 worldNormal = normalize(worldPos + localOrigin);`:W.H`vec3 worldNormal = vec3(0.0, 0.0, 1.0);`}
        ${te.hasScreenSizePerspective?W.H`
            float cosAngle = dot(worldNormal, normalize(worldPos - cameraPosition));
            float verticalOffsetScreenHeight = screenSizePerspectiveScaleFloat(verticalOffset.x, abs(cosAngle), viewDistance, screenSizePerspectiveAlignment);`:W.H`
            float verticalOffsetScreenHeight = verticalOffset.x;`}
        // Screen sized offset in world space, used for example for line callouts
        float worldOffset = clamp(verticalOffsetScreenHeight * verticalOffset.y * viewDistance, verticalOffset.z, verticalOffset.w);
        return worldNormal * worldOffset;
      }

      vec3 addVerticalOffset(vec3 worldPos, vec3 localOrigin) {
        return worldPos + calculateVerticalOffset(worldPos, localOrigin);
      }
    `)):q.code.add(W.H`vec3 addVerticalOffset(vec3 worldPos, vec3 localOrigin) { return worldPos; }`)}const Q=(0,w.c)()},75958:(fe,Y,v)=>{v.d(Y,{s:()=>at});var y=v(62208),w=v(43703),I=v(52382),W=v(13934),V=v(78925),H=v(24255),L=v(26859),A=v(17625),S=v(16396);function j(xe,ue){const ce=ue.output===W.H.ObjectAndLayerIdColor,Ke=ue.objectAndLayerIdColorInstanced;ce&&(xe.varyings.add("objectAndLayerIdColorVarying","vec4"),xe.attributes.add(Ke?S.T.OBJECTANDLAYERIDCOLOR_INSTANCED:S.T.OBJECTANDLAYERIDCOLOR,"vec4")),xe.vertex.code.add(A.H`
     void forwardObjectAndLayerIdColor() {
      ${ce?Ke?A.H`objectAndLayerIdColorVarying = objectAndLayerIdColor_instanced * 0.003921568627451;`:A.H`objectAndLayerIdColorVarying = objectAndLayerIdColor * 0.003921568627451;`:A.H``} }`),xe.fragment.code.add(A.H`
      void outputObjectAndLayerIdColor() {
        ${ce?A.H`gl_FragColor = objectAndLayerIdColorVarying;`:A.H``} }`)}var K=v(36603),Q=v(21799),z=v(19278);function Z(xe,ue){switch(xe.fragment.include(z.n),ue.output){case W.H.Shadow:case W.H.ShadowHighlight:case W.H.ShadowExludeHighlight:xe.extensions.add("GL_OES_standard_derivatives"),xe.fragment.code.add(A.H`float _calculateFragDepth(const in float depth) {
const float SLOPE_SCALE = 2.0;
const float BIAS = 20.0 * .000015259;
float m = max(abs(dFdx(depth)), abs(dFdy(depth)));
float result = depth + SLOPE_SCALE * m + BIAS;
return clamp(result, .0, .999999);
}
void outputDepth(float _linearDepth) {
gl_FragColor = float2rgba(_calculateFragDepth(_linearDepth));
}`);break;case W.H.Depth:xe.fragment.code.add(A.H`void outputDepth(float _linearDepth) {
gl_FragColor = float2rgba(_linearDepth);
}`)}}var te=v(4794),q=v(43177),$=v(35387),k=v(19755);const J=(0,te.f)(1,1,0,1),ie=(0,te.f)(1,0,1,1);function de(xe,ue){xe.fragment.uniforms.add((0,$.J)("depthTex",(ce,Ke)=>Ke.highlightDepthTexture,ue.hasWebGL2Context?k.D.None:k.D.InvSize)),xe.fragment.constants.add("occludedHighlightFlag","vec4",J).add("unoccludedHighlightFlag","vec4",ie),xe.fragment.code.add(A.H`
    void outputHighlight() {
      vec3 fragCoord = gl_FragCoord.xyz;

      float sceneDepth = ${(0,q.b6)(ue,"depthTex","fragCoord.xy")}.x;
      if (fragCoord.z > sceneDepth + 5e-7) {
        gl_FragColor = occludedHighlightFlag;
      }
      else {
        gl_FragColor = unoccludedHighlightFlag;
      }
    }
  `)}var le=v(67938),ge=v(72397),ve=v(99198),Ee=v(63123),Ce=v(42743);function at(xe,ue){const{vertex:ce,fragment:Ke}=xe,Je=ue.hasModelTransformation;Je&&ce.uniforms.add(new Ee.g("model",st=>(0,y.pC)(st.modelTransformation)?st.modelTransformation:w.I));const ke=ue.hasColorTexture&&ue.alphaDiscardMode!==Ce.JJ.Opaque;switch(ue.output){case W.H.Depth:case W.H.Shadow:case W.H.ShadowHighlight:case W.H.ShadowExludeHighlight:case W.H.ObjectAndLayerIdColor:(0,ve.Sv)(ce,ue),xe.include(H.w,ue),xe.include(K.D,ue),xe.include(le.k,ue),xe.include(Z,ue),xe.include(V.f5,ue),xe.include(j,ue),(0,I.Zu)(xe),xe.varyings.add("depth","float"),ke&&Ke.uniforms.add(new $.A("tex",st=>st.texture)),ce.code.add(A.H`
          void main(void) {
            vpos = calculateVPos();
            vpos = subtractOrigin(vpos);
            vpos = addVerticalOffset(vpos, localOrigin);
            gl_Position = transformPositionWithDepth(proj, view, ${Je?"model,":""} vpos, nearFar, depth);
            forwardTextureCoordinates();
            forwardObjectAndLayerIdColor();
          }
        `),xe.include(ge.z,ue),Ke.code.add(A.H`
          void main(void) {
            discardBySlice(vpos);
            ${ke?A.H`
                    vec4 texColor = texture2D(tex, ${ue.hasColorTextureTransform?A.H`colorUV`:A.H`vuv0`});
                    discardOrAdjustAlpha(texColor);`:""}
            ${ue.output===W.H.ObjectAndLayerIdColor?A.H`outputObjectAndLayerIdColor();`:A.H`outputDepth(depth);`}
          }
        `);break;case W.H.Normal:(0,ve.Sv)(ce,ue),xe.include(H.w,ue),xe.include(L.O,ue),xe.include(Q.Bb,ue),xe.include(K.D,ue),xe.include(le.k,ue),ke&&Ke.uniforms.add(new $.A("tex",st=>st.texture)),xe.varyings.add("vPositionView","vec3"),ce.code.add(A.H`
          void main(void) {
            vpos = calculateVPos();
            vpos = subtractOrigin(vpos);
            ${ue.normalType===L.h.Attribute?A.H`
            vNormalWorld = dpNormalView(vvLocalNormal(normalModel()));`:""}
            vpos = addVerticalOffset(vpos, localOrigin);
            gl_Position = transformPosition(proj, view, ${Je?"model,":""} vpos);
            forwardTextureCoordinates();
          }
        `),xe.include(V.f5,ue),xe.include(ge.z,ue),Ke.code.add(A.H`
          void main() {
            discardBySlice(vpos);
            ${ke?A.H`
                    vec4 texColor = texture2D(tex, ${ue.hasColorTextureTransform?A.H`colorUV`:A.H`vuv0`});
                    discardOrAdjustAlpha(texColor);`:""}

            ${ue.normalType===L.h.ScreenDerivative?A.H`
                vec3 normal = screenDerivativeNormal(vPositionView);`:A.H`
                vec3 normal = normalize(vNormalWorld);
                if (gl_FrontFacing == false) normal = -normal;`}
            gl_FragColor = vec4(vec3(0.5) + 0.5 * normal, 1.0);
          }
        `);break;case W.H.Highlight:(0,ve.Sv)(ce,ue),xe.include(H.w,ue),xe.include(K.D,ue),xe.include(le.k,ue),ke&&Ke.uniforms.add(new $.A("tex",st=>st.texture)),ce.code.add(A.H`
          void main(void) {
            vpos = calculateVPos();
            vpos = subtractOrigin(vpos);
            vpos = addVerticalOffset(vpos, localOrigin);
            gl_Position = transformPosition(proj, view, ${Je?"model,":""} vpos);
            forwardTextureCoordinates();
          }
        `),xe.include(V.f5,ue),xe.include(ge.z,ue),xe.include(de,ue),Ke.code.add(A.H`
          void main() {
            discardBySlice(vpos);
            ${ke?A.H`
                    vec4 texColor = texture2D(tex, ${ue.hasColorTextureTransform?A.H`colorUV`:A.H`vuv0`});
                    discardOrAdjustAlpha(texColor);`:""}
            outputHighlight();
          }
        `)}}},47923:(fe,Y,v)=>{v.d(Y,{S:()=>I});var y=v(19278),w=v(17625);function I(W){W.include(y.n),W.code.add(w.H`float linearDepthFromFloat(float depth, vec2 nearFar) {
return -(depth * (nearFar[1] - nearFar[0]) + nearFar[0]);
}
float linearDepthFromTexture(sampler2D depthTex, vec2 uv, vec2 nearFar) {
return linearDepthFromFloat(rgba2float(texture2D(depthTex, uv)), nearFar);
}`)}},29052:(fe,Y,v)=>{v.d(Y,{Q:()=>K});var y=v(36603),w=v(85982),I=v(96395),W=v(43177),V=v(17625),H=v(5864),L=v(35387),A=v(19755),S=v(37847),j=v(16396);function K(Q,z){const Z=Q.fragment;if(z.hasVertexTangents?(Q.attributes.add(j.T.TANGENT,"vec4"),Q.varyings.add("vTangent","vec4"),Z.code.add(z.doubleSidedMode===I.q.WindingOrder?V.H`mat3 computeTangentSpace(vec3 normal) {
float tangentHeadedness = gl_FrontFacing ? vTangent.w : -vTangent.w;
vec3 tangent = normalize(gl_FrontFacing ? vTangent.xyz : -vTangent.xyz);
vec3 bitangent = cross(normal, tangent) * tangentHeadedness;
return mat3(tangent, bitangent, normal);
}`:V.H`mat3 computeTangentSpace(vec3 normal) {
float tangentHeadedness = vTangent.w;
vec3 tangent = normalize(vTangent.xyz);
vec3 bitangent = cross(normal, tangent) * tangentHeadedness;
return mat3(tangent, bitangent, normal);
}`)):(Q.extensions.add("GL_OES_standard_derivatives"),Z.code.add(V.H`mat3 computeTangentSpace(vec3 normal, vec3 pos, vec2 st) {
vec3 Q1 = dFdx(pos);
vec3 Q2 = dFdy(pos);
vec2 stx = dFdx(st);
vec2 sty = dFdy(st);
float det = stx.t * sty.s - sty.t * stx.s;
vec3 T = stx.t * Q2 - sty.t * Q1;
T = T - normal * dot(normal, T);
T *= inversesqrt(max(dot(T,T), 1.e-10));
vec3 B = sign(det) * cross(normal, T);
return mat3(T, B, normal);
}`)),z.textureCoordinateType!==y.N.None){Q.include(w.i,z);const te=z.supportsTextureAtlas?z.hasWebGL2Context?A.D.None:A.D.Size:A.D.None;Z.uniforms.add(z.pbrTextureBindType===S.P.Pass?(0,L.J)("normalTexture",q=>q.textureNormal,te):(0,H.F)("normalTexture",q=>q.textureNormal,te)),Z.code.add(V.H`
    vec3 computeTextureNormal(mat3 tangentSpace, vec2 uv) {
      vtc.uv = uv;
      ${z.supportsTextureAtlas?V.H`vtc.size = ${(0,W.w_)(z,"normalTexture")};`:""}
      vec3 rawNormal = textureLookup(normalTexture, vtc).rgb * 2.0 - 1.0;
      return tangentSpace * rawNormal;
    }
  `)}}},53520:(fe,Y,v)=>{v.d(Y,{K:()=>xe});var y=v(43177),w=v(17625),I=v(35387),W=v(19755),A=(v(67831),v(70026),v(12155),v(651)),S=v(91056),j=v(39114),K=v(12407),Q=v(86962),z=v(2078);class Z extends S.A{initializeProgram(ce){return new K.$(ce.rctx,Z.shader.get().build(),j.i)}initializePipeline(){return(0,z.sm)({colorWrite:z.BK})}}Z.shader=new A.J(Q.S,()=>v.e(1902).then(v.bind(v,90857)));var te=v(52376);class q extends S.A{initializeProgram(ce){return new K.$(ce.rctx,q.shader.get().build(),j.i)}initializePipeline(){return(0,z.sm)({colorWrite:z.BK})}}function xe(ue,ce){const Ke=ue.fragment;ce.receiveAmbientOcclusion?(Ke.uniforms.add((0,I.J)("ssaoTex",(Je,ke)=>ke.ssaoHelper.colorTexture,ce.hasWebGL2Context?W.D.None:W.D.InvSize)),Ke.constants.add("blurSizePixelsInverse","float",.5),Ke.code.add(w.H`
      float evaluateAmbientOcclusionInverse() {
        vec2 ssaoTextureSizeInverse = ${(0,y.w_)(ce,"ssaoTex",!0)};
        return texture2D(ssaoTex, gl_FragCoord.xy * blurSizePixelsInverse * ssaoTextureSizeInverse).a;
      }

      float evaluateAmbientOcclusion() {
        return 1.0 - evaluateAmbientOcclusionInverse();
      }
    `)):Ke.code.add(w.H`float evaluateAmbientOcclusionInverse() { return 1.0; }
float evaluateAmbientOcclusion() { return 0.0; }`)}q.shader=new A.J(te.S,()=>v.e(3999).then(v.bind(v,73999))),v(99770),v(67969),v(85775),v(55086),v(26906)},36412:(fe,Y,v)=>{v.d(Y,{XP:()=>qt,PN:()=>It,sC:()=>ht});var y=v(94573),w=v(84161),I=v(28093),W=v(993),V=v(4794),H=v(92724),L=v(97139),A=v(69960),S=v(17625);function j(ye,Me){const pe=ye.fragment,He=void 0!==Me.lightingSphericalHarmonicsOrder?Me.lightingSphericalHarmonicsOrder:2;0===He?(pe.uniforms.add(new L.J("lightingAmbientSH0",(Se,Pe)=>(0,w.s)(K,Pe.lighting.sh.r[0],Pe.lighting.sh.g[0],Pe.lighting.sh.b[0]))),pe.code.add(S.H`vec3 calculateAmbientIrradiance(vec3 normal, float ambientOcclusion) {
vec3 ambientLight = 0.282095 * lightingAmbientSH0;
return ambientLight * (1.0 - ambientOcclusion);
}`)):1===He?(pe.uniforms.add([new A.N("lightingAmbientSH_R",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.r[0],Pe.lighting.sh.r[1],Pe.lighting.sh.r[2],Pe.lighting.sh.r[3])),new A.N("lightingAmbientSH_G",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.g[0],Pe.lighting.sh.g[1],Pe.lighting.sh.g[2],Pe.lighting.sh.g[3])),new A.N("lightingAmbientSH_B",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.b[0],Pe.lighting.sh.b[1],Pe.lighting.sh.b[2],Pe.lighting.sh.b[3]))]),pe.code.add(S.H`vec3 calculateAmbientIrradiance(vec3 normal, float ambientOcclusion) {
vec4 sh0 = vec4(
0.282095,
0.488603 * normal.x,
0.488603 * normal.z,
0.488603 * normal.y
);
vec3 ambientLight = vec3(
dot(lightingAmbientSH_R, sh0),
dot(lightingAmbientSH_G, sh0),
dot(lightingAmbientSH_B, sh0)
);
return ambientLight * (1.0 - ambientOcclusion);
}`)):2===He&&(pe.uniforms.add([new L.J("lightingAmbientSH0",(Se,Pe)=>(0,w.s)(K,Pe.lighting.sh.r[0],Pe.lighting.sh.g[0],Pe.lighting.sh.b[0])),new A.N("lightingAmbientSH_R1",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.r[1],Pe.lighting.sh.r[2],Pe.lighting.sh.r[3],Pe.lighting.sh.r[4])),new A.N("lightingAmbientSH_G1",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.g[1],Pe.lighting.sh.g[2],Pe.lighting.sh.g[3],Pe.lighting.sh.g[4])),new A.N("lightingAmbientSH_B1",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.b[1],Pe.lighting.sh.b[2],Pe.lighting.sh.b[3],Pe.lighting.sh.b[4])),new A.N("lightingAmbientSH_R2",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.r[5],Pe.lighting.sh.r[6],Pe.lighting.sh.r[7],Pe.lighting.sh.r[8])),new A.N("lightingAmbientSH_G2",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.g[5],Pe.lighting.sh.g[6],Pe.lighting.sh.g[7],Pe.lighting.sh.g[8])),new A.N("lightingAmbientSH_B2",(Se,Pe)=>(0,W.s)(Q,Pe.lighting.sh.b[5],Pe.lighting.sh.b[6],Pe.lighting.sh.b[7],Pe.lighting.sh.b[8]))]),pe.code.add(S.H`vec3 calculateAmbientIrradiance(vec3 normal, float ambientOcclusion) {
vec3 ambientLight = 0.282095 * lightingAmbientSH0;
vec4 sh1 = vec4(
0.488603 * normal.x,
0.488603 * normal.z,
0.488603 * normal.y,
1.092548 * normal.x * normal.y
);
vec4 sh2 = vec4(
1.092548 * normal.y * normal.z,
0.315392 * (3.0 * normal.z * normal.z - 1.0),
1.092548 * normal.x * normal.z,
0.546274 * (normal.x * normal.x - normal.y * normal.y)
);
ambientLight += vec3(
dot(lightingAmbientSH_R1, sh1),
dot(lightingAmbientSH_G1, sh1),
dot(lightingAmbientSH_B1, sh1)
);
ambientLight += vec3(
dot(lightingAmbientSH_R2, sh2),
dot(lightingAmbientSH_G2, sh2),
dot(lightingAmbientSH_B2, sh2)
);
return ambientLight * (1.0 - ambientOcclusion);
}`),Me.pbrMode!==H.f7.Normal&&Me.pbrMode!==H.f7.Schematic||pe.code.add(S.H`const vec3 skyTransmittance = vec3(0.9, 0.9, 1.0);
vec3 calculateAmbientRadiance(float ambientOcclusion)
{
vec3 ambientLight = 1.2 * (0.282095 * lightingAmbientSH0) - 0.2;
return ambientLight *= (1.0 - ambientOcclusion) * skyTransmittance;
}`))}const K=(0,I.c)(),Q=(0,V.c)();var z=v(53520),Z=v(31166),te=v(98898),q=v(39337),$=v(85930),k=v(37847);class J extends $.x{constructor(Me,pe){super(Me,"bool",k.P.Pass,(He,Se,Pe)=>He.setUniform1b(Me,pe(Se,Pe)))}}var ie=v(65787);function It(ye){ye.constants.add("ambientBoostFactor","float",.4)}function ht(ye){ye.uniforms.add(new ie.p("lightingGlobalFactor",(Me,pe)=>pe.lighting.globalFactor))}function qt(ye,Me){const pe=ye.fragment;switch(ye.include(z.K,Me),Me.pbrMode!==H.f7.Disabled&&ye.include(te.T,Me),ye.include(j,Me),ye.include(q.e),pe.code.add(S.H`
    const float GAMMA_SRGB = 2.1;
    const float INV_GAMMA_SRGB = 0.4761904;
    ${Me.pbrMode===H.f7.Disabled?"":"const vec3 GROUND_REFLECTANCE = vec3(0.2);"}
  `),It(pe),ht(pe),(0,Z.Pe)(pe),pe.code.add(S.H`
    float additionalDirectedAmbientLight(vec3 vPosWorld) {
      float vndl = dot(${Me.spherical?S.H`normalize(vPosWorld)`:S.H`vec3(0.0, 0.0, 1.0)`}, mainLightDirection);
      return smoothstep(0.0, 1.0, clamp(vndl * 2.5, 0.0, 1.0));
    }
  `),(0,Z.F1)(pe),pe.code.add(S.H`vec3 evaluateAdditionalLighting(float ambientOcclusion, vec3 vPosWorld) {
float additionalAmbientScale = additionalDirectedAmbientLight(vPosWorld);
return (1.0 - ambientOcclusion) * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor * mainLightIntensity;
}`),Me.pbrMode){case H.f7.Disabled:case H.f7.WaterOnIntegratedMesh:case H.f7.Water:ye.include(Z.kR,Me),pe.code.add(S.H`vec3 evaluateSceneLighting(vec3 normalWorld, vec3 albedo, float shadow, float ssao, vec3 additionalLight)
{
vec3 mainLighting = evaluateMainLighting(normalWorld, shadow);
vec3 ambientLighting = calculateAmbientIrradiance(normalWorld, ssao);
vec3 albedoLinear = pow(albedo, vec3(GAMMA_SRGB));
vec3 totalLight = mainLighting + ambientLighting + additionalLight;
totalLight = min(totalLight, vec3(PI));
vec3 outColor = vec3((albedoLinear / PI) * totalLight);
return pow(outColor, vec3(INV_GAMMA_SRGB));
}`);break;case H.f7.Normal:case H.f7.Schematic:pe.code.add(S.H`const float fillLightIntensity = 0.25;
const float horizonLightDiffusion = 0.4;
const float additionalAmbientIrradianceFactor = 0.02;
vec3 evaluateSceneLightingPBR(vec3 normal, vec3 albedo, float shadow, float ssao, vec3 additionalLight, vec3 viewDir, vec3 normalGround, vec3 mrr, vec3 _emission, float additionalAmbientIrradiance)
{
vec3 viewDirection = -viewDir;
vec3 mainLightDirection = mainLightDirection;
vec3 h = normalize(viewDirection + mainLightDirection);
PBRShadingInfo inputs;
inputs.NdotL = clamp(dot(normal, mainLightDirection), 0.001, 1.0);
inputs.NdotV = clamp(abs(dot(normal, viewDirection)), 0.001, 1.0);
inputs.NdotH = clamp(dot(normal, h), 0.0, 1.0);
inputs.VdotH = clamp(dot(viewDirection, h), 0.0, 1.0);
inputs.NdotNG = clamp(dot(normal, normalGround), -1.0, 1.0);
vec3 reflectedView = normalize(reflect(viewDirection, normal));
inputs.RdotNG = clamp(dot(reflectedView, normalGround), -1.0, 1.0);
inputs.albedoLinear = pow(albedo, vec3(GAMMA_SRGB));
inputs.ssao = ssao;
inputs.metalness = mrr[0];
inputs.roughness = clamp(mrr[1] * mrr[1], 0.001, 0.99);`),pe.code.add(S.H`inputs.f0 = (0.16 * mrr[2] * mrr[2]) * (1.0 - inputs.metalness) + inputs.albedoLinear * inputs.metalness;
inputs.f90 = vec3(clamp(dot(inputs.f0, vec3(50.0 * 0.33)), 0.0, 1.0));
inputs.diffuseColor = inputs.albedoLinear * (vec3(1.0) - inputs.f0) * (1.0 - inputs.metalness);`),Me.useFillLights?pe.uniforms.add(new J("hasFillLights",(He,Se)=>Se.enableFillLights)):pe.constants.add("hasFillLights","bool",!1),pe.code.add(S.H`vec3 ambientDir = vec3(5.0 * normalGround[1] - normalGround[0] * normalGround[2], - 5.0 * normalGround[0] - normalGround[2] * normalGround[1], normalGround[1] * normalGround[1] + normalGround[0] * normalGround[0]);
ambientDir = ambientDir != vec3(0.0)? normalize(ambientDir) : normalize(vec3(5.0, -1.0, 0.0));
inputs.NdotAmbDir = hasFillLights ? abs(dot(normal, ambientDir)) : 1.0;
vec3 mainLightIrradianceComponent = inputs.NdotL * (1.0 - shadow) * mainLightIntensity;
vec3 fillLightsIrradianceComponent = inputs.NdotAmbDir * mainLightIntensity * fillLightIntensity;
vec3 ambientLightIrradianceComponent = calculateAmbientIrradiance(normal, ssao) + additionalLight;
inputs.skyIrradianceToSurface = ambientLightIrradianceComponent + mainLightIrradianceComponent + fillLightsIrradianceComponent ;
inputs.groundIrradianceToSurface = GROUND_REFLECTANCE * ambientLightIrradianceComponent + mainLightIrradianceComponent + fillLightsIrradianceComponent ;`),pe.uniforms.add([new ie.p("lightingSpecularStrength",(He,Se)=>Se.lighting.mainLight.specularStrength),new ie.p("lightingEnvironmentStrength",(He,Se)=>Se.lighting.mainLight.environmentStrength)]),pe.code.add(S.H`vec3 horizonRingDir = inputs.RdotNG * normalGround - reflectedView;
vec3 horizonRingH = normalize(viewDirection + horizonRingDir);
inputs.NdotH_Horizon = dot(normal, horizonRingH);
vec3 mainLightRadianceComponent = lightingSpecularStrength * normalDistribution(inputs.NdotH, inputs.roughness) * mainLightIntensity * (1.0 - shadow);
vec3 horizonLightRadianceComponent = lightingEnvironmentStrength * normalDistribution(inputs.NdotH_Horizon, min(inputs.roughness + horizonLightDiffusion, 1.0)) * mainLightIntensity * fillLightIntensity;
vec3 ambientLightRadianceComponent = lightingEnvironmentStrength * calculateAmbientRadiance(ssao) + additionalLight;
inputs.skyRadianceToSurface = ambientLightRadianceComponent + mainLightRadianceComponent + horizonLightRadianceComponent;
inputs.groundRadianceToSurface = GROUND_REFLECTANCE * (ambientLightRadianceComponent + horizonLightRadianceComponent) + mainLightRadianceComponent;
inputs.averageAmbientRadiance = ambientLightIrradianceComponent[1] * (1.0 + GROUND_REFLECTANCE[1]);`),pe.code.add(S.H`
        vec3 reflectedColorComponent = evaluateEnvironmentIllumination(inputs);
        vec3 additionalMaterialReflectanceComponent = inputs.albedoLinear * additionalAmbientIrradiance;
        vec3 emissionComponent = pow(_emission, vec3(GAMMA_SRGB));
        vec3 outColorLinear = reflectedColorComponent + additionalMaterialReflectanceComponent + emissionComponent;
        ${Me.pbrMode===H.f7.Schematic?S.H`vec3 outColor = pow(max(vec3(0.0), outColorLinear - 0.005 * inputs.averageAmbientRadiance), vec3(INV_GAMMA_SRGB));`:S.H`vec3 outColor = pow(blackLevelSoftCompression(outColorLinear, inputs), vec3(INV_GAMMA_SRGB));`}
        return outColor;
      }
    `);break;default:(0,y.Bg)(Me.pbrMode);case H.f7.COUNT:}}v(21286),(0,I.c)(),(0,I.c)()},31166:(fe,Y,v)=>{v.d(Y,{F1:()=>V,Pe:()=>W,kR:()=>L});var y=v(97139),w=v(65787),I=v(17625);function W(A){A.uniforms.add(new y.J("mainLightDirection",(S,j)=>j.lighting.mainLight.direction))}function V(A){A.uniforms.add(new y.J("mainLightIntensity",(S,j)=>j.lighting.mainLight.intensity))}function L(A,S){const j=A.fragment;W(j),V(j),function H(A,S){S.useLegacyTerrainShading?A.uniforms.add(new w.p("lightingFixedFactor",(j,K)=>K.lighting.noonFactor*(1-K.lighting.globalFactor))):A.constants.add("lightingFixedFactor","float",0)}(j,S),j.code.add(I.H`vec3 evaluateMainLighting(vec3 normal_global, float shadowing) {
float dotVal = clamp(dot(normal_global, mainLightDirection), 0.0, 1.0);
dotVal = mix(dotVal, 1.0, lightingFixedFactor);
return mainLightIntensity * ((1.0 - shadowing) * dotVal);
}`)}},10109:(fe,Y,v)=>{v.d(Y,{l:()=>V});var y=v(47923),w=v(95285),I=v(17625),W=v(35387);function V(L,A){A.hasMultipassTerrain&&(L.fragment.include(y.S),L.fragment.uniforms.add(new W.A("terrainDepthTexture",(S,j)=>j.multipassTerrain.linearDepthTexture)),L.fragment.uniforms.add(new w.A("nearFar",(S,j)=>j.camera.nearFar)),L.fragment.uniforms.add(new w.A("inverseViewport",(S,j)=>j.inverseViewport)),L.fragment.code.add(I.H`
    void terrainDepthTest(vec4 fragCoord, float fragmentDepth){
      float terrainDepth = linearDepthFromTexture(terrainDepthTexture, fragCoord.xy * inverseViewport, nearFar);
      if(fragmentDepth ${A.cullAboveGround?">":"<="} terrainDepth){
        discard;
      }
    }
  `))}},96395:(fe,Y,v)=>{v.d(Y,{k:()=>I,q:()=>W});var W,V,y=v(94573),w=v(17625);function I(V,H){const L=V.fragment;switch(L.code.add(w.H`struct ShadingNormalParameters {
vec3 normalView;
vec3 viewDirection;
} shadingParams;`),H.doubleSidedMode){case W.None:L.code.add(w.H`vec3 shadingNormal(ShadingNormalParameters params) {
return normalize(params.normalView);
}`);break;case W.View:L.code.add(w.H`vec3 shadingNormal(ShadingNormalParameters params) {
return dot(params.normalView, params.viewDirection) > 0.0 ? normalize(-params.normalView) : normalize(params.normalView);
}`);break;case W.WindingOrder:L.code.add(w.H`vec3 shadingNormal(ShadingNormalParameters params) {
return gl_FrontFacing ? normalize(params.normalView) : normalize(-params.normalView);
}`);break;default:(0,y.Bg)(H.doubleSidedMode);case W.COUNT:}}(V=W||(W={}))[V.None=0]="None",V[V.View=1]="View",V[V.WindingOrder=2]="WindingOrder",V[V.COUNT=3]="COUNT"},98898:(fe,Y,v)=>{v.d(Y,{T:()=>V});var y=v(17625);function w(H){const L=H.fragment.code;L.add(y.H`vec3 evaluateDiffuseIlluminationHemisphere(vec3 ambientGround, vec3 ambientSky, float NdotNG)
{
return ((1.0 - NdotNG) * ambientGround + (1.0 + NdotNG) * ambientSky) * 0.5;
}`),L.add(y.H`float integratedRadiance(float cosTheta2, float roughness)
{
return (cosTheta2 - 1.0) / (cosTheta2 * (1.0 - roughness * roughness) - 1.0);
}`),L.add(y.H`vec3 evaluateSpecularIlluminationHemisphere(vec3 ambientGround, vec3 ambientSky, float RdotNG, float roughness)
{
float cosTheta2 = 1.0 - RdotNG * RdotNG;
float intRadTheta = integratedRadiance(cosTheta2, roughness);
float ground = RdotNG < 0.0 ? 1.0 - intRadTheta : 1.0 + intRadTheta;
float sky = 2.0 - ground;
return (ground * ambientGround + sky * ambientSky) * 0.5;
}`)}var I=v(92724),W=v(39337);function V(H,L){const A=H.fragment.code;H.include(W.e),L.pbrMode===I.f7.Water||L.pbrMode===I.f7.WaterOnIntegratedMesh?(A.add(y.H`
    struct PBRShadingWater
    {
        float NdotL;   // cos angle between normal and light direction
        float NdotV;   // cos angle between normal and view direction
        float NdotH;   // cos angle between normal and half vector
        float VdotH;   // cos angle between view direction and half vector
        float LdotH;   // cos angle between light direction and half vector
        float VdotN;   // cos angle between view direction and normal vector
    };

    float dtrExponent = ${L.useCustomDTRExponentForWater?"2.2":"2.0"};
    `),A.add(y.H`vec3 fresnelReflection(float angle, vec3 f0, float f90) {
return f0 + (f90 - f0) * pow(1.0 - angle, 5.0);
}`),A.add(y.H`float normalDistributionWater(float NdotH, float roughness)
{
float r2 = roughness * roughness;
float NdotH2 = NdotH * NdotH;
float denom = pow((NdotH2 * (r2 - 1.0) + 1.0), dtrExponent) * PI;
return r2 / denom;
}`),A.add(y.H`float geometricOcclusionKelemen(float LoH)
{
return 0.25 / (LoH * LoH);
}`),A.add(y.H`vec3 brdfSpecularWater(in PBRShadingWater props, float roughness, vec3 F0, float F0Max)
{
vec3  F = fresnelReflection(props.VdotH, F0, F0Max);
float dSun = normalDistributionWater(props.NdotH, roughness);
float V = geometricOcclusionKelemen(props.LdotH);
float diffusionSunHaze = mix(roughness + 0.045, roughness + 0.385, 1.0 - props.VdotH);
float strengthSunHaze  = 1.2;
float dSunHaze = normalDistributionWater(props.NdotH, diffusionSunHaze)*strengthSunHaze;
return ((dSun + dSunHaze) * V) * F;
}
vec3 tonemapACES(const vec3 x) {
return (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14);
}`)):L.pbrMode!==I.f7.Normal&&L.pbrMode!==I.f7.Schematic||(H.include(w),A.add(y.H`struct PBRShadingInfo
{
float NdotL;
float NdotV;
float NdotH;
float VdotH;
float LdotH;
float NdotNG;
float RdotNG;
float NdotAmbDir;
float NdotH_Horizon;
vec3 skyRadianceToSurface;
vec3 groundRadianceToSurface;
vec3 skyIrradianceToSurface;
vec3 groundIrradianceToSurface;
float averageAmbientRadiance;
float ssao;
vec3 albedoLinear;
vec3 f0;
vec3 f90;
vec3 diffuseColor;
float metalness;
float roughness;
};`),A.add(y.H`float normalDistribution(float NdotH, float roughness)
{
float a = NdotH * roughness;
float b = roughness / (1.0 - NdotH * NdotH + a * a);
return b * b * INV_PI;
}`),A.add(y.H`const vec4 c0 = vec4(-1.0, -0.0275, -0.572,  0.022);
const vec4 c1 = vec4( 1.0,  0.0425,  1.040, -0.040);
const vec2 c2 = vec2(-1.04, 1.04);
vec2 prefilteredDFGAnalytical(float roughness, float NdotV) {
vec4 r = roughness * c0 + c1;
float a004 = min(r.x * r.x, exp2(-9.28 * NdotV)) * r.x + r.y;
return c2 * a004 + r.zw;
}`),A.add(y.H`vec3 evaluateEnvironmentIllumination(PBRShadingInfo inputs) {
vec3 indirectDiffuse = evaluateDiffuseIlluminationHemisphere(inputs.groundIrradianceToSurface, inputs.skyIrradianceToSurface, inputs.NdotNG);
vec3 indirectSpecular = evaluateSpecularIlluminationHemisphere(inputs.groundRadianceToSurface, inputs.skyRadianceToSurface, inputs.RdotNG, inputs.roughness);
vec3 diffuseComponent = inputs.diffuseColor * indirectDiffuse * INV_PI;
vec2 dfg = prefilteredDFGAnalytical(inputs.roughness, inputs.NdotV);
vec3 specularColor = inputs.f0 * dfg.x + inputs.f90 * dfg.y;
vec3 specularComponent = specularColor * indirectSpecular;
return (diffuseComponent + specularComponent);
}`),A.add(y.H`float gamutMapChanel(float x, vec2 p){
return (x < p.x) ? mix(0.0, p.y, x/p.x) : mix(p.y, 1.0, (x - p.x) / (1.0 - p.x) );
}`),A.add(y.H`vec3 blackLevelSoftCompression(vec3 inColor, PBRShadingInfo inputs){
vec3 outColor;
vec2 p = vec2(0.02 * (inputs.averageAmbientRadiance), 0.0075 * (inputs.averageAmbientRadiance));
outColor.x = gamutMapChanel(inColor.x, p) ;
outColor.y = gamutMapChanel(inColor.y, p) ;
outColor.z = gamutMapChanel(inColor.z, p) ;
return outColor;
}`))}},92724:(fe,Y,v)=>{v.d(Y,{f7:()=>z,jV:()=>te});var z,q,y=v(14658),w=v(85982),I=v(43177),W=v(77739),V=v(97139),H=v(17625),L=v(5864),A=v(35387),S=v(19755),j=v(37847);function te(q,$){const k=q.fragment,J=$.hasMetallicRoughnessTexture||$.hasEmissionTexture||$.hasOcclusionTexture;if($.pbrMode===z.Normal&&J&&q.include(w.i,$),$.pbrMode!==z.Schematic)if($.pbrMode!==z.Disabled){if($.pbrMode===z.Normal){k.code.add(H.H`vec3 mrr;
vec3 emission;
float occlusion;`);const ie=$.supportsTextureAtlas?$.hasWebGL2Context?S.D.None:S.D.Size:S.D.None,de=$.pbrTextureBindType;$.hasMetallicRoughnessTexture&&(k.uniforms.add(de===j.P.Pass?(0,A.J)("texMetallicRoughness",le=>le.textureMetallicRoughness,ie):(0,L.F)("texMetallicRoughness",le=>le.textureMetallicRoughness,ie)),k.code.add(H.H`void applyMetallnessAndRoughness(TextureLookupParameter params) {
vec3 metallicRoughness = textureLookup(texMetallicRoughness, params).rgb;
mrr[0] *= metallicRoughness.b;
mrr[1] *= metallicRoughness.g;
}`)),$.hasEmissionTexture&&(k.uniforms.add(de===j.P.Pass?(0,A.J)("texEmission",le=>le.textureEmissive,ie):(0,L.F)("texEmission",le=>le.textureEmissive,ie)),k.code.add(H.H`void applyEmission(TextureLookupParameter params) {
emission *= textureLookup(texEmission, params).rgb;
}`)),$.hasOcclusionTexture?(k.uniforms.add(de===j.P.Pass?(0,A.J)("texOcclusion",le=>le.textureOcclusion,ie):(0,L.F)("texOcclusion",le=>le.textureOcclusion,ie)),k.code.add(H.H`void applyOcclusion(TextureLookupParameter params) {
occlusion *= textureLookup(texOcclusion, params).r;
}
float getBakedOcclusion() {
return occlusion;
}`)):k.code.add(H.H`float getBakedOcclusion() { return 1.0; }`),k.uniforms.add(de===j.P.Pass?[new V.J("emissionFactor",le=>le.emissiveFactor),new V.J("mrrFactors",le=>le.mrrFactors)]:[new W.B("emissionFactor",le=>le.emissiveFactor),new W.B("mrrFactors",le=>le.mrrFactors)]),k.code.add(H.H`
    void applyPBRFactors() {
      mrr = mrrFactors;
      emission = emissionFactor;
      occlusion = 1.0;
      ${J?H.H`vtc.uv = vuv0;`:""}
      ${$.hasMetallicRoughnessTextureTransform?H.H`vtc.uv = metallicRoughnessUV;`:""}
      ${$.hasMetallicRoughnessTexture?$.supportsTextureAtlas?H.H`
                vtc.size = ${(0,I.w_)($,"texMetallicRoughness")};
                applyMetallnessAndRoughness(vtc);`:H.H`applyMetallnessAndRoughness(vtc);`:""}
      ${$.hasEmissiveTextureTransform?H.H`vtc.uv = emissiveUV;`:""}
      ${$.hasEmissionTexture?$.supportsTextureAtlas?H.H`
                vtc.size = ${(0,I.w_)($,"texEmission")};
                applyEmission(vtc);`:H.H`applyEmission(vtc);`:""}
      ${$.hasOcclusionTextureTransform?H.H`vtc.uv = occlusionUV;`:""}
      ${$.hasOcclusionTexture?$.supportsTextureAtlas?H.H`
                vtc.size = ${(0,I.w_)($,"texOcclusion")};
                applyOcclusion(vtc);`:H.H`applyOcclusion(vtc);`:""}
    }
  `)}}else k.code.add(H.H`float getBakedOcclusion() { return 1.0; }`);else k.code.add(H.H`vec3 mrr = vec3(0.0, 0.6, 0.2);
vec3 emission = vec3(0.0);
float occlusion = 1.0;
void applyPBRFactors() {}
float getBakedOcclusion() { return 1.0; }`)}v(44621),(0,y.f)(0,.6,.2),(q=z||(z={}))[q.Disabled=0]="Disabled",q[q.Normal=1]="Normal",q[q.Schematic=2]="Schematic",q[q.Water=3]="Water",q[q.WaterOnIntegratedMesh=4]="WaterOnIntegratedMesh",q[q.COUNT=5]="COUNT"},39337:(fe,Y,v)=>{v.d(Y,{e:()=>w});var y=v(17625);function w(I){I.vertex.code.add(y.H`const float PI = 3.141592653589793;`),I.fragment.code.add(y.H`const float PI = 3.141592653589793;
const float LIGHT_NORMALIZATION = 1.0 / PI;
const float INV_PI = 0.3183098861837907;
const float HALF_PI = 1.570796326794897;`)}},72968:(fe,Y,v)=>{v.d(Y,{XE:()=>te,hb:()=>Z}),v(28093);var w=v(19278),I=v(43177),W=v(69960),V=v(18952),H=v(17625),L=v(85930),A=v(37847);class S extends L.x{constructor(k,J,ie){super(k,"mat4",A.P.Draw,(de,le,ge)=>de.setUniformMatrix4fv(k,J(le,ge)),ie)}}class j extends L.x{constructor(k,J,ie){super(k,"mat4",A.P.Pass,(de,le,ge)=>de.setUniformMatrix4fv(k,J(le,ge)),ie)}}var K=v(35387),Q=v(19755);function Z($,k){k.receiveShadows&&($.fragment.uniforms.add(new j("shadowMapMatrix",(J,ie)=>ie.shadowMap.getShadowMapMatrices(J.origin),4)),q($,k))}function te($,k){k.receiveShadows&&($.fragment.uniforms.add(new S("shadowMapMatrix",(J,ie)=>ie.shadowMap.getShadowMapMatrices(J.origin),4)),q($,k))}function q($,k){const J=$.fragment;J.include(w.n),J.uniforms.add([...(0,K.J)("shadowMapTex",(ie,de)=>de.shadowMap.depthTexture,k.hasWebGL2Context?Q.D.None:Q.D.Size),new V._("numCascades",(ie,de)=>de.shadowMap.numCascades),new W.N("cascadeDistances",(ie,de)=>de.shadowMap.cascadeDistances)]),J.code.add(H.H`
    int chooseCascade(float depth, out mat4 mat) {
      vec4 distance = cascadeDistances;

      // choose correct cascade
      int i = depth < distance[1] ? 0 : depth < distance[2] ? 1 : depth < distance[3] ? 2 : 3;

      mat = i == 0 ? shadowMapMatrix[0] : i == 1 ? shadowMapMatrix[1] : i == 2 ? shadowMapMatrix[2] : shadowMapMatrix[3];

      return i;
    }

    vec3 lightSpacePosition(vec3 _vpos, mat4 mat) {
      vec4 lv = mat * vec4(_vpos, 1.0);
      lv.xy /= lv.w;
      return 0.5 * lv.xyz + vec3(0.5);
    }

    vec2 cascadeCoordinates(int i, vec3 lvpos) {
      return vec2(float(i - 2 * (i / 2)) * 0.5, float(i / 2) * 0.5) + 0.5 * lvpos.xy;
    }

    float readShadowMapDepth(vec2 uv, sampler2D _depthTex) {
      return rgba2float(texture2D(_depthTex, uv));
    }

    float posIsInShadow(vec2 uv, vec3 lvpos, sampler2D _depthTex) {
      return readShadowMapDepth(uv, _depthTex) < lvpos.z ? 1.0 : 0.0;
    }

    float filterShadow(vec2 uv, vec3 lvpos, float textureSize, sampler2D _depthTex) {
      float halfPixelSize = 0.5 / textureSize;

      // filter, offset by half pixels
      vec2 st = fract((vec2(halfPixelSize) + uv) * textureSize);

      float s00 = posIsInShadow(uv + vec2(-halfPixelSize, -halfPixelSize), lvpos, _depthTex);
      float s10 = posIsInShadow(uv + vec2(halfPixelSize, -halfPixelSize), lvpos, _depthTex);
      float s11 = posIsInShadow(uv + vec2(halfPixelSize, halfPixelSize), lvpos, _depthTex);
      float s01 = posIsInShadow(uv + vec2(-halfPixelSize, halfPixelSize), lvpos, _depthTex);

      return mix(mix(s00, s10, st.x), mix(s01, s11, st.x), st.y);
    }

    float readShadowMap(const in vec3 _vpos, float _linearDepth) {
      mat4 mat;
      int i = chooseCascade(_linearDepth, mat);

      if (i >= numCascades) { return 0.0; }

      vec3 lvpos = lightSpacePosition(_vpos, mat);

      // vertex completely outside? -> no shadow
      if (lvpos.z >= 1.0) { return 0.0; }
      if (lvpos.x < 0.0 || lvpos.x > 1.0 || lvpos.y < 0.0 || lvpos.y > 1.0) { return 0.0; }

      // calc coord in cascade texture
      vec2 uv = cascadeCoordinates(i, lvpos);

      vec2 textureSize = ${(0,I.w_)(k,"shadowMapTex")};

      return filterShadow(uv, lvpos, textureSize.x, shadowMapTex);
    }
  `)}},70489:(fe,Y,v)=>{v.d(Y,{DT:()=>S,NI:()=>H,R5:()=>L,av:()=>V,jF:()=>A});var y=v(62208),w=v(49966),I=v(17625),W=v(91574);function V(j){j.vertex.uniforms.add(new W.c("colorTextureTransformMatrix",K=>(0,y.pC)(K.colorTextureTransformMatrix)?K.colorTextureTransformMatrix:(0,w.c)())),j.varyings.add("colorUV","vec2"),j.vertex.code.add(I.H`void forwardColorUV(){
colorUV = (colorTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)}function H(j){j.vertex.uniforms.add(new W.c("normalTextureTransformMatrix",K=>(0,y.pC)(K.normalTextureTransformMatrix)?K.normalTextureTransformMatrix:(0,w.c)())),j.varyings.add("normalUV","vec2"),j.vertex.code.add(I.H`void forwardNormalUV(){
normalUV = (normalTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)}function L(j){j.vertex.uniforms.add(new W.c("emissiveTextureTransformMatrix",K=>(0,y.pC)(K.emissiveTextureTransformMatrix)?K.emissiveTextureTransformMatrix:(0,w.c)())),j.varyings.add("emissiveUV","vec2"),j.vertex.code.add(I.H`void forwardEmissiveUV(){
emissiveUV = (emissiveTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)}function A(j){j.vertex.uniforms.add(new W.c("occlusionTextureTransformMatrix",K=>(0,y.pC)(K.occlusionTextureTransformMatrix)?K.occlusionTextureTransformMatrix:(0,w.c)())),j.varyings.add("occlusionUV","vec2"),j.vertex.code.add(I.H`void forwardOcclusionUV(){
occlusionUV = (occlusionTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)}function S(j){j.vertex.uniforms.add(new W.c("metallicRoughnessTextureTransformMatrix",K=>(0,y.pC)(K.metallicRoughnessTextureTransformMatrix)?K.metallicRoughnessTextureTransformMatrix:(0,w.c)())),j.varyings.add("metallicRoughnessUV","vec2"),j.vertex.code.add(I.H`void forwardMetallicRoughnessUV(){
metallicRoughnessUV = (metallicRoughnessTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)}},67938:(fe,Y,v)=>{v.d(Y,{k:()=>Z});var y=v(97139),w=v(85930),I=v(37847);class W extends w.x{constructor(q,$,k){super(q,"vec4",I.P.Pass,(J,ie,de)=>J.setUniform4fv(q,$(ie,de)),k)}}class V extends w.x{constructor(q,$,k){super(q,"float",I.P.Pass,(J,ie,de)=>J.setUniform1fv(q,$(ie,de)),k)}}var H=v(17625),L=v(91574),A=v(16396);function Z(te,q){q.hasVvInstancing&&(q.vvSize||q.vvColor)&&te.attributes.add(A.T.INSTANCEFEATUREATTRIBUTE,"vec4");const $=te.vertex;q.vvSize?($.uniforms.add(new y.J("vvSizeMinSize",k=>k.vvSizeMinSize)),$.uniforms.add(new y.J("vvSizeMaxSize",k=>k.vvSizeMaxSize)),$.uniforms.add(new y.J("vvSizeOffset",k=>k.vvSizeOffset)),$.uniforms.add(new y.J("vvSizeFactor",k=>k.vvSizeFactor)),$.uniforms.add(new L.c("vvSymbolRotationMatrix",k=>k.vvSymbolRotationMatrix)),$.uniforms.add(new y.J("vvSymbolAnchor",k=>k.vvSymbolAnchor)),$.code.add(H.H`vec3 vvScale(vec4 _featureAttribute) {
return clamp(vvSizeOffset + _featureAttribute.x * vvSizeFactor, vvSizeMinSize, vvSizeMaxSize);
}
vec4 vvTransformPosition(vec3 position, vec4 _featureAttribute) {
return vec4(vvSymbolRotationMatrix * ( vvScale(_featureAttribute) * (position + vvSymbolAnchor)), 1.0);
}`),$.code.add(H.H`
      const float eps = 1.192092896e-07;
      vec4 vvTransformNormal(vec3 _normal, vec4 _featureAttribute) {
        vec3 vvScale = clamp(vvSizeOffset + _featureAttribute.x * vvSizeFactor, vvSizeMinSize + eps, vvSizeMaxSize);
        return vec4(vvSymbolRotationMatrix * _normal / vvScale, 1.0);
      }

      ${q.hasVvInstancing?H.H`
      vec4 vvLocalNormal(vec3 _normal) {
        return vvTransformNormal(_normal, instanceFeatureAttribute);
      }

      vec4 localPosition() {
        return vvTransformPosition(position, instanceFeatureAttribute);
      }`:""}
    `)):$.code.add(H.H`vec4 localPosition() { return vec4(position, 1.0); }
vec4 vvLocalNormal(vec3 _normal) { return vec4(_normal, 1.0); }`),q.vvColor?($.constants.add("vvColorNumber","int",8),q.hasVvInstancing&&$.uniforms.add([new V("vvColorValues",k=>k.vvColorValues,8),new W("vvColorColors",k=>k.vvColorColors,8)]),$.code.add(H.H`
      vec4 vvGetColor(vec4 featureAttribute, float values[vvColorNumber], vec4 colors[vvColorNumber]) {
        float value = featureAttribute.y;
        if (value <= values[0]) {
          return colors[0];
        }

        for (int i = 1; i < vvColorNumber; ++i) {
          if (values[i] >= value) {
            float f = (value - values[i-1]) / (values[i] - values[i-1]);
            return mix(colors[i-1], colors[i], f);
          }
        }
        return colors[vvColorNumber - 1];
      }

      ${q.hasVvInstancing?H.H`
      vec4 vvColor() {
        return vvGetColor(instanceFeatureAttribute, vvColorValues, vvColorColors);
      }`:""}
    `)):$.code.add(H.H`vec4 vvColor() { return vec4(1.0); }`)}v(550),v(28093),v(40723)},67022:(fe,Y,v)=>{v.d(Y,{F:()=>y,b:()=>w});const y=.1,w=.001},72397:(fe,Y,v)=>{v.d(Y,{z:()=>S});var y=v(67022),w=v(17625);function I(Q){Q.fragment.code.add(w.H`
    #define discardOrAdjustAlpha(color) { if (color.a < ${w.H.float(y.b)}) { discard; } }
  `)}v(85930),v(37847);var L=v(65787),A=v(42743);function S(Q,z){!function K(Q,z,Z){const te=Q.fragment;switch(z.alphaDiscardMode!==A.JJ.Mask&&z.alphaDiscardMode!==A.JJ.MaskBlend||te.uniforms.add(Z),z.alphaDiscardMode){case A.JJ.Blend:return Q.include(I);case A.JJ.Opaque:te.code.add(w.H`void discardOrAdjustAlpha(inout vec4 color) {
color.a = 1.0;
}`);break;case A.JJ.Mask:te.code.add(w.H`#define discardOrAdjustAlpha(color) { if (color.a < textureAlphaCutoff) { discard; } else { color.a = 1.0; } }`);break;case A.JJ.MaskBlend:Q.fragment.code.add(w.H`#define discardOrAdjustAlpha(color) { if (color.a < textureAlphaCutoff) { discard; } }`)}}(Q,z,new L.p("textureAlphaCutoff",Z=>Z.textureAlphaCutoff))}},39832:(fe,Y,v)=>{v.d(Y,{G:()=>A,R:()=>K});var y=v(67831),w=v(99770),I=v(993),W=v(4794),V=v(95285),H=v(69960),L=v(17625);function A(z){z.fragment.uniforms.add(new H.N("projInfo",(Z,te)=>function S(z){const Z=z.camera.projectionMatrix;return 0===Z[11]?(0,I.s)(j,2/(z.camera.fullWidth*Z[0]),2/(z.camera.fullHeight*Z[5]),(1+Z[12])/Z[0],(1+Z[13])/Z[5]):(0,I.s)(j,-2/(z.camera.fullWidth*Z[0]),-2/(z.camera.fullHeight*Z[5]),(1-Z[8])/Z[0],(1-Z[9])/Z[5])}(te))),z.fragment.uniforms.add(new V.A("zScale",(Z,te)=>K(te))),z.fragment.code.add(L.H`vec3 reconstructPosition(vec2 fragCoord, float depth) {
return vec3((fragCoord * projInfo.xy + projInfo.zw) * (zScale.x * depth + zScale.y), depth);
}`)}const j=(0,W.c)();function K(z){return 0===z.camera.projectionMatrix[11]?(0,y.s)(Q,0,1):(0,y.s)(Q,1,0)}const Q=(0,w.a)()},7228:(fe,Y,v)=>{v.d(Y,{$:()=>I,I:()=>W});var y=v(8314),w=v(17625);function I({code:V},H){V.add(H.doublePrecisionRequiresObfuscation?w.H`vec3 dpPlusFrc(vec3 a, vec3 b) {
return mix(a, a + b, vec3(notEqual(b, vec3(0))));
}
vec3 dpMinusFrc(vec3 a, vec3 b) {
return mix(vec3(0), a - b, vec3(notEqual(a, b)));
}
vec3 dpAdd(vec3 hiA, vec3 loA, vec3 hiB, vec3 loB) {
vec3 t1 = dpPlusFrc(hiA, hiB);
vec3 e = dpMinusFrc(t1, hiA);
vec3 t2 = dpMinusFrc(hiB, e) + dpMinusFrc(hiA, dpMinusFrc(t1, e)) + loA + loB;
return t1 + t2;
}`:w.H`vec3 dpAdd(vec3 hiA, vec3 loA, vec3 hiB, vec3 loB) {
vec3 t1 = hiA + hiB;
vec3 e = t1 - hiA;
vec3 t2 = ((hiB - e) + (hiA - (t1 - e))) + loA + loB;
return t1 + t2;
}`)}function W(V){return!!(0,y.Z)("force-double-precision-obfuscation")||V.driverTest.doublePrecisionRequiresObfuscation}},49974:(fe,Y,v)=>{v.d(Y,{y:()=>W});var y=v(9044),w=v(17625);function I(V){V.code.add(w.H`vec4 premultiplyAlpha(vec4 v) {
return vec4(v.rgb * v.a, v.a);
}
vec3 rgb2hsv(vec3 c) {
vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
vec4 p = c.g < c.b ? vec4(c.bg, K.wz) : vec4(c.gb, K.xy);
vec4 q = c.r < p.x ? vec4(p.xyw, c.r) : vec4(c.r, p.yzx);
float d = q.x - min(q.w, q.y);
float e = 1.0e-10;
return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), min(d / (q.x + e), 1.0), q.x);
}
vec3 hsv2rgb(vec3 c) {
vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float rgb2v(vec3 c) {
return max(c.x, max(c.y, c.z));
}`)}function W(V){V.include(I),V.code.add(w.H`
    vec3 mixExternalColor(vec3 internalColor, vec3 textureColor, vec3 externalColor, int mode) {
      // workaround for artifacts in OSX using Intel Iris Pro
      // see: https://devtopia.esri.com/WebGIS/arcgis-js-api/issues/10475
      vec3 internalMixed = internalColor * textureColor;
      vec3 allMixed = internalMixed * externalColor;

      if (mode == ${w.H.int(y.a9.Multiply)}) {
        return allMixed;
      }
      if (mode == ${w.H.int(y.a9.Ignore)}) {
        return internalMixed;
      }
      if (mode == ${w.H.int(y.a9.Replace)}) {
        return externalColor;
      }

      // tint (or something invalid)
      float vIn = rgb2v(internalMixed);
      vec3 hsvTint = rgb2hsv(externalColor);
      vec3 hsvOut = vec3(hsvTint.x, hsvTint.y, vIn * hsvTint.z);
      return hsv2rgb(hsvOut);
    }

    float mixExternalOpacity(float internalOpacity, float textureOpacity, float externalOpacity, int mode) {
      // workaround for artifacts in OSX using Intel Iris Pro
      // see: https://devtopia.esri.com/WebGIS/arcgis-js-api/issues/10475
      float internalMixed = internalOpacity * textureOpacity;
      float allMixed = internalMixed * externalOpacity;

      if (mode == ${w.H.int(y.a9.Ignore)}) {
        return internalMixed;
      }
      if (mode == ${w.H.int(y.a9.Replace)}) {
        return externalOpacity;
      }

      // multiply or tint (or something invalid)
      return allMixed;
    }
  `)}},19278:(fe,Y,v)=>{v.d(Y,{n:()=>w});var y=v(17625);function w(I){I.code.add(y.H`const float MAX_RGBA_FLOAT =
255.0 / 256.0 +
255.0 / 256.0 / 256.0 +
255.0 / 256.0 / 256.0 / 256.0 +
255.0 / 256.0 / 256.0 / 256.0 / 256.0;
const vec4 FIXED_POINT_FACTORS = vec4(1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0);
vec4 float2rgba(const float value) {
float valueInValidDomain = clamp(value, 0.0, MAX_RGBA_FLOAT);
vec4 fixedPointU8 = floor(fract(valueInValidDomain * FIXED_POINT_FACTORS) * 256.0);
const float toU8AsFloat = 1.0 / 255.0;
return fixedPointU8 * toU8AsFloat;
}
const vec4 RGBA_2_FLOAT_FACTORS = vec4(
255.0 / (256.0),
255.0 / (256.0 * 256.0),
255.0 / (256.0 * 256.0 * 256.0),
255.0 / (256.0 * 256.0 * 256.0 * 256.0)
);
float rgba2float(vec4 rgba) {
return dot(rgba, RGBA_2_FLOAT_FACTORS);
}`)}},99198:(fe,Y,v)=>{v.d(Y,{hY:()=>K,Sv:()=>Q,_8:()=>te});var y=v(28347),w=v(55494),I=v(84161),W=v(28093),V=v(77739),H=v(97139),L=v(85930),A=v(37847);class S extends L.x{constructor($,k){super($,"mat4",A.P.Draw,(J,ie,de)=>J.setUniformMatrix4fv($,k(ie,de)))}}var j=v(63123);function K(q,$){$.instancedDoublePrecision?q.constants.add("cameraPosition","vec3",W.Z):q.uniforms.add(new V.B("cameraPosition",(k,J)=>(0,I.s)(Z,J.camera.viewInverseTransposeMatrix[3]-k.origin[0],J.camera.viewInverseTransposeMatrix[7]-k.origin[1],J.camera.viewInverseTransposeMatrix[11]-k.origin[2])))}function Q(q,$){if(!$.instancedDoublePrecision)return void q.uniforms.add([new j.g("proj",(J,ie)=>ie.camera.projectionMatrix),new S("view",(J,ie)=>(0,y.v)(z,ie.camera.viewMatrix,J.origin)),new V.B("localOrigin",J=>J.origin)]);const k=J=>(0,I.s)(Z,J.camera.viewInverseTransposeMatrix[3],J.camera.viewInverseTransposeMatrix[7],J.camera.viewInverseTransposeMatrix[11]);q.uniforms.add([new j.g("proj",(J,ie)=>ie.camera.projectionMatrix),new j.g("view",(J,ie)=>(0,y.v)(z,ie.camera.viewMatrix,k(ie))),new H.J("localOrigin",(J,ie)=>k(ie))])}const z=(0,w.c)(),Z=(0,W.c)();function te(q){q.uniforms.add(new j.g("viewNormal",($,k)=>k.camera.viewInverseTransposeMatrix))}},43177:(fe,Y,v)=>{v.d(Y,{aU:()=>I,b6:()=>V,o_:()=>w,w_:()=>W});var y=v(17625);const w="Size",I="InvSize";function W(H,L,A=!1,S=0){if(H.hasWebGL2Context){const j=y.H`vec2(textureSize(${L}, ${y.H.int(S)}))`;return A?"(1.0 / "+j+")":j}return A?L+I:L+w}function V(H,L,A,S=null,j=0){if(H.hasWebGL2Context)return y.H`texelFetch(${L}, ivec2(${A}), ${y.H.int(j)})`;let K=y.H`texture2D(${L}, ${A} * `;return K+=S?y.H`(${S}))`:y.H`${L+I})`,K}},32181:(fe,Y,v)=>{v.d(Y,{q:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"vec2",w.P.Draw,(L,A,S,j)=>L.setUniform2fv(V,H(A,S,j)))}}},95285:(fe,Y,v)=>{v.d(Y,{A:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"vec2",w.P.Pass,(L,A,S)=>L.setUniform2fv(V,H(A,S)))}}},77739:(fe,Y,v)=>{v.d(Y,{B:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"vec3",w.P.Draw,(L,A,S,j)=>L.setUniform3fv(V,H(A,S,j)))}}},97139:(fe,Y,v)=>{v.d(Y,{J:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"vec3",w.P.Pass,(L,A,S)=>L.setUniform3fv(V,H(A,S)))}}},69960:(fe,Y,v)=>{v.d(Y,{N:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"vec4",w.P.Pass,(L,A,S)=>L.setUniform4fv(V,H(A,S)))}}},65787:(fe,Y,v)=>{v.d(Y,{p:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"float",w.P.Pass,(L,A,S)=>L.setUniform1f(V,H(A,S)))}}},18952:(fe,Y,v)=>{v.d(Y,{_:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"int",w.P.Pass,(L,A,S)=>L.setUniform1i(V,H(A,S)))}}},9546:(fe,Y,v)=>{v.d(Y,{j:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"mat3",w.P.Draw,(L,A,S)=>L.setUniformMatrix3fv(V,H(A,S)))}}},91574:(fe,Y,v)=>{v.d(Y,{c:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"mat3",w.P.Pass,(L,A,S)=>L.setUniformMatrix3fv(V,H(A,S)))}}},63123:(fe,Y,v)=>{v.d(Y,{g:()=>I});var y=v(85930),w=v(37847);class I extends y.x{constructor(V,H){super(V,"mat4",w.P.Pass,(L,A,S)=>L.setUniformMatrix4fv(V,H(A,S)))}}},22355:(fe,Y,v)=>{v.d(Y,{kG:()=>H});var y=v(26584),w=v(63290),I=v(62208);const W=w.Z.getLogger("esri.views.3d.webgl-engine.core.shaderModules.shaderBuilder");class V{constructor(){this._includedModules=new Map}include($,k){if(this._includedModules.has($)){const J=this._includedModules.get($);if(J!==k){W.error("Trying to include shader module multiple times with different sets of options.");const ie=new Set;for(const de of Object.keys(J))J[de]!==$[de]&&ie.add(de);for(const de of Object.keys($))J[de]!==$[de]&&ie.add(de);ie.forEach(de=>console.error(`  ${de}: current ${J[de]} new ${$[de]}`))}}else this._includedModules.set($,k),$(this.builder,k)}}class H extends V{constructor(){super(...arguments),this.vertex=new S,this.fragment=new S,this.attributes=new j,this.varyings=new K,this.extensions=new Q,this.constants=new z}get fragmentUniforms(){return this.fragment.uniforms.entries}get builder(){return this}generate($){const k=this.extensions.generateSource($),J=this.attributes.generateSource($),ie=this.varyings.generateSource(),de="vertex"===$?this.vertex:this.fragment,le=de.uniforms.generateSource(),ge=de.code.generateSource(),ve="vertex"===$?te:Z,Ee=this.constants.generateSource().concat(de.constants.generateSource());return`\n${k.join("\n")}\n\n${ve}\n\n${Ee.join("\n")}\n\n${le.join("\n")}\n\n${J.join("\n")}\n\n${ie.join("\n")}\n\n${ge.join("\n")}`}generateBind($,k){const J=new Map;this.vertex.uniforms.entries.forEach(le=>{const ge=le.bind[$];(0,I.pC)(ge)&&J.set(le.name,ge)}),this.fragment.uniforms.entries.forEach(le=>{const ge=le.bind[$];(0,I.pC)(ge)&&J.set(le.name,ge)});const ie=Array.from(J.values()),de=ie.length;return(le,ge,ve)=>{for(let Ee=0;Ee<de;++Ee)ie[Ee](k,le,ge,ve)}}}class L{constructor(){this._entries=new Map}add($){if(!Array.isArray($))return this._add($);for(const k of $)this._add(k)}get($){return this._entries.get($)}_add($){if((0,I.Wi)($))W.error(`Trying to add null Uniform from ${(new Error).stack}.`);else{if(this._entries.has($.name)&&!this._entries.get($.name).equals($))throw new y.Z(`Duplicate uniform name ${$.name} for different uniform type`);this._entries.set($.name,$)}}generateSource(){return Array.from(this._entries.values()).map($=>(0,I.pC)($.arraySize)?`uniform ${$.type} ${$.name}[${$.arraySize}];`:`uniform ${$.type} ${$.name};`)}get entries(){return Array.from(this._entries.values())}}class A{constructor(){this._entries=new Array}add($){this._entries.push($)}generateSource(){return this._entries}}class S extends V{constructor(){super(...arguments),this.uniforms=new L,this.code=new A,this.constants=new z}get builder(){return this}}class j{constructor(){this._entries=new Array}add($,k){this._entries.push([$,k])}generateSource($){return"fragment"===$?[]:this._entries.map(k=>`attribute ${k[1]} ${k[0]};`)}}class K{constructor(){this._entries=new Array}add($,k){this._entries.push([$,k])}generateSource(){return this._entries.map($=>`varying ${$[1]} ${$[0]};`)}}class Q{constructor(){this._entries=new Set}add($){this._entries.add($)}generateSource($){const k="vertex"===$?Q.ALLOWLIST_VERTEX:Q.ALLOWLIST_FRAGMENT;return Array.from(this._entries).filter(J=>k.includes(J)).map(J=>`#extension ${J} : enable`)}}Q.ALLOWLIST_FRAGMENT=["GL_EXT_shader_texture_lod","GL_OES_standard_derivatives"],Q.ALLOWLIST_VERTEX=[];class z{constructor(){this._entries=new Set}add($,k,J){let ie="ERROR_CONSTRUCTOR_STRING";switch(k){case"float":ie=z._numberToFloatStr(J);break;case"int":ie=z._numberToIntStr(J);break;case"bool":ie=J.toString();break;case"vec2":ie=`vec2(${z._numberToFloatStr(J[0])},                            ${z._numberToFloatStr(J[1])})`;break;case"vec3":ie=`vec3(${z._numberToFloatStr(J[0])},                            ${z._numberToFloatStr(J[1])},                            ${z._numberToFloatStr(J[2])})`;break;case"vec4":ie=`vec4(${z._numberToFloatStr(J[0])},                            ${z._numberToFloatStr(J[1])},                            ${z._numberToFloatStr(J[2])},                            ${z._numberToFloatStr(J[3])})`;break;case"ivec2":ie=`ivec2(${z._numberToIntStr(J[0])},                             ${z._numberToIntStr(J[1])})`;break;case"ivec3":ie=`ivec3(${z._numberToIntStr(J[0])},                             ${z._numberToIntStr(J[1])},                             ${z._numberToIntStr(J[2])})`;break;case"ivec4":ie=`ivec4(${z._numberToIntStr(J[0])},                             ${z._numberToIntStr(J[1])},                             ${z._numberToIntStr(J[2])},                             ${z._numberToIntStr(J[3])})`;break;case"mat2":case"mat3":case"mat4":ie=`${k}(${Array.prototype.map.call(J,de=>z._numberToFloatStr(de)).join(", ")})`}return this._entries.add(`const ${k} ${$} = ${ie};`),this}static _numberToIntStr($){return $.toFixed(0)}static _numberToFloatStr($){return Number.isInteger($)?$.toFixed(1):$.toString()}generateSource(){return Array.from(this._entries)}}const Z="#ifdef GL_FRAGMENT_PRECISION_HIGH\n  precision highp float;\n  precision highp sampler2D;\n#else\n  precision mediump float;\n  precision mediump sampler2D;\n#endif",te="precision highp float;\nprecision highp sampler2D;"},5864:(fe,Y,v)=>{v.d(Y,{F:()=>j,R:()=>S});var y=v(62208),w=v(67831),I=v(99770),W=v(43177),V=v(32181),H=v(19755),L=v(85930),A=v(37847);class S extends L.x{constructor(z,Z){super(z,"sampler2D",A.P.Draw,(te,q,$)=>te.bindTexture(z,Z(q,$)))}}function j(Q,z,Z=H.D.None){const te=[new S(Q,z)];return Z&H.D.Size&&te.push(new V.q(Q+W.o_,($,k)=>{const J=z($,k);return(0,y.pC)(J)?(0,w.s)(K,J.descriptor.width,J.descriptor.height):I.Z})),Z&H.D.InvSize&&te.push(new V.q(Q+W.aU,($,k)=>{const J=z($,k);return(0,y.pC)(J)?(0,w.s)(K,1/J.descriptor.width,1/J.descriptor.height):I.Z})),te}const K=(0,I.a)()},35387:(fe,Y,v)=>{v.d(Y,{A:()=>S,J:()=>j});var y=v(62208),w=v(67831),I=v(99770),W=v(43177),V=v(95285),H=v(19755),L=v(85930),A=v(37847);class S extends L.x{constructor(z,Z){super(z,"sampler2D",A.P.Pass,(te,q,$)=>te.bindTexture(z,Z(q,$)))}}function j(Q,z,Z=H.D.None){const te=[new S(Q,z)];return Z&H.D.Size&&te.push(new V.A(Q+W.o_,($,k)=>{const J=z($,k);return(0,y.pC)(J)?(0,w.s)(K,J.descriptor.width,J.descriptor.height):I.Z})),Z&H.D.InvSize&&te.push(new V.A(Q+W.aU,($,k)=>{const J=z($,k);return(0,y.pC)(J)?(0,w.s)(K,1/J.descriptor.width,1/J.descriptor.height):I.Z})),te}const K=(0,I.a)()},19755:(fe,Y,v)=>{var y,w;v.d(Y,{D:()=>y}),(w=y||(y={}))[w.None=0]="None",w[w.Size=1]="Size",w[w.InvSize=2]="InvSize"},85930:(fe,Y,v)=>{v.d(Y,{x:()=>I});var y=v(62208),w=v(37847);class I{constructor(V,H,L,A,S=null){this.name=V,this.type=H,this.arraySize=S,this.bind={[w.P.Pass]:null,[w.P.Draw]:null},(0,y.pC)(L)&&(0,y.pC)(A)&&(this.bind[L]=A)}equals(V){return this.type===V.type&&this.name===V.name&&this.arraySize===V.arraySize}}},17625:(fe,Y,v)=>{v.d(Y,{H:()=>w,K:()=>y});class y{}function w(I,...W){let V="";for(let H=0;H<W.length;H++)V+=I[H]+W[H];return V+=I[I.length-1],V}var I;(I=w||(w={})).int=function W(H){return Math.round(H).toString()},I.float=function V(H){return H.toPrecision(8)}},37847:(fe,Y,v)=>{var y,w;v.d(Y,{P:()=>y}),(w=y||(y={}))[w.Pass=0]="Pass",w[w.Draw=1]="Draw"},651:(fe,Y,v)=>{v.d(Y,{J:()=>w});var y=v(15861);class w{constructor(W,V){this._module=W,this._loadModule=V}get(){return this._module}reload(){var W=this;return(0,y.Z)(function*(){return W._module=yield W._loadModule(),W._module})()}}},91056:(fe,Y,v)=>{v.d(Y,{A:()=>I});var y=v(62208),w=v(67969);class I{constructor(V,H,L){this.release=L,this.initializeConfiguration(V,H),this._configuration=H.snapshot(),this._program=this.initializeProgram(V),this._pipeline=this.initializePipeline(V.rctx.capabilities)}destroy(){this._program=(0,y.M2)(this._program),this._pipeline=this._configuration=null}reload(V){(0,y.M2)(this._program),this._program=this.initializeProgram(V),this._pipeline=this.initializePipeline(V.rctx.capabilities)}get program(){return this._program}get compiled(){return this.program.isCompiled}get key(){return this._configuration.key}get configuration(){return this._configuration}bindPipelineState(V,H=null,L){V.setPipelineState(this.getPipelineState(H,L))}ensureAttributeLocations(V){this.program.assertCompatibleVertexAttributeLocations(V)}get primitiveType(){return w.MX.TRIANGLES}getPipelineState(V,H){return this._pipeline}initializeConfiguration(V,H){}}},87601:(fe,Y,v)=>{v.d(Y,{m:()=>y,o:()=>w});class y{constructor(){this._key="",this._keyDirty=!1,this._parameterBits=this._parameterBits?this._parameterBits.map(()=>0):[],this._parameterNames||(this._parameterNames=[])}get key(){return this._keyDirty&&(this._keyDirty=!1,this._key=String.fromCharCode.apply(String,this._parameterBits)),this._key}snapshot(){const W=this._parameterNames,V={key:this.key};for(const H of W)V[H]=this[H];return V}}function w(I={}){return(W,V)=>{var H;if(W._parameterNames=null!==(H=W._parameterNames)&&void 0!==H?H:[],W._parameterNames.push(V),null!=I.constValue)Object.defineProperty(W,V,{get:()=>I.constValue});else{var L;const A=W._parameterNames.length-1,j=Math.ceil(Math.log2(I.count||2)),K=null!==(L=W._parameterBits)&&void 0!==L?L:[0];let Q=0;for(;K[Q]+j>16;)Q++,Q>=K.length&&K.push(0);W._parameterBits=K;const z=K[Q],Z=(1<<j)-1<<z;K[Q]+=j,Object.defineProperty(W,V,{get(){return this[A]},set(te){if(this[A]!==te&&(this[A]=te,this._keyDirty=!0,this._parameterBits[Q]=this._parameterBits[Q]&~Z|+te<<z&Z,"number"!=typeof te&&"boolean"!=typeof te))throw"Configuration value for "+V+" must be boolean or number, got "+typeof te}})}}}},12699:(fe,Y,v)=>{v.d(Y,{c:()=>w});var y=v(86236);class w{constructor(){this.id=(0,y.D)()}unload(){}}},24425:(fe,Y,v)=>{var y,w;v.d(Y,{U:()=>y}),(w=y||(y={}))[w.Layer=0]="Layer",w[w.Object=1]="Object",w[w.Geometry=2]="Geometry",w[w.Material=3]="Material",w[w.Texture=4]="Texture",w[w.COUNT=5]="COUNT"},39114:(fe,Y,v)=>{v.d(Y,{i:()=>w});var y=v(16396);const w=new Map([[y.T.POSITION,0],[y.T.NORMAL,1],[y.T.UV0,2],[y.T.COLOR,3],[y.T.SIZE,4],[y.T.TANGENT,4],[y.T.AUXPOS1,5],[y.T.SYMBOLCOLOR,5],[y.T.AUXPOS2,6],[y.T.FEATUREATTRIBUTE,6],[y.T.INSTANCEFEATUREATTRIBUTE,6],[y.T.INSTANCECOLOR,7],[y.T.OBJECTANDLAYERIDCOLOR,7],[y.T.OBJECTANDLAYERIDCOLOR_INSTANCED,7],[y.T.MODEL,8],[y.T.MODELNORMAL,12],[y.T.MODELORIGINHI,11],[y.T.MODELORIGINLO,15]])},44621:(fe,Y,v)=>{v.d(Y,{F:()=>H});var y=v(62208),w=v(10699),I=v(17625),W=v(42743);class V{constructor(S){this._material=S.material,this._techniqueRepository=S.techniqueRep,this._output=S.output}dispose(){this._techniqueRepository.release(this._technique)}get technique(){return this._technique}get _stippleTextureRepository(){return this._techniqueRepository.constructionContext.stippleTextureRepository}ensureTechnique(S,j,K=this._output){return this._technique=this._techniqueRepository.releaseAndAcquire(S,this._material.getConfiguration(K,j),this._technique),this._technique}ensureResources(S){return W.Rw.LOADED}}class H extends V{constructor(S){super(S),this._numLoading=0,this._disposed=!1,this._textureRepository=S.textureRep,this._textureId=S.textureId,this._acquire(S.textureId,j=>this._texture=j),this._acquire(S.normalTextureId,j=>this._textureNormal=j),this._acquire(S.emissiveTextureId,j=>this._textureEmissive=j),this._acquire(S.occlusionTextureId,j=>this._textureOcclusion=j),this._acquire(S.metallicRoughnessTextureId,j=>this._textureMetallicRoughness=j)}dispose(){this._texture=(0,y.RY)(this._texture),this._textureNormal=(0,y.RY)(this._textureNormal),this._textureEmissive=(0,y.RY)(this._textureEmissive),this._textureOcclusion=(0,y.RY)(this._textureOcclusion),this._textureMetallicRoughness=(0,y.RY)(this._textureMetallicRoughness),this._disposed=!0}ensureResources(S){return 0===this._numLoading?W.Rw.LOADED:W.Rw.LOADING}get textureBindParameters(){return new L((0,y.pC)(this._texture)?this._texture.glTexture:null,(0,y.pC)(this._textureNormal)?this._textureNormal.glTexture:null,(0,y.pC)(this._textureEmissive)?this._textureEmissive.glTexture:null,(0,y.pC)(this._textureOcclusion)?this._textureOcclusion.glTexture:null,(0,y.pC)(this._textureMetallicRoughness)?this._textureMetallicRoughness.glTexture:null)}updateTexture(S){((0,y.Wi)(this._texture)||S!==this._texture.id)&&(this._texture=(0,y.RY)(this._texture),this._textureId=S,this._acquire(this._textureId,j=>this._texture=j))}_acquire(S,j){if((0,y.Wi)(S))return void j(null);const K=this._textureRepository.acquire(S);if((0,w.y8)(K))return++this._numLoading,void K.then(Q=>{if(this._disposed)return(0,y.RY)(Q),void j(null);j(Q)}).finally(()=>--this._numLoading);j(K)}}class L extends I.K{constructor(S=null,j=null,K=null,Q=null,z=null){super(),this.texture=S,this.textureNormal=j,this.textureEmissive=K,this.textureOcclusion=Q,this.textureMetallicRoughness=z}}},40723:(fe,Y,v)=>{v.d(Y,{F5:()=>L,yD:()=>A});var A,j,y=v(62208),I=(v(17625),v(12699)),W=v(24425),V=v(39114),H=v(50229);class L extends I.c{constructor(K,Q){super(),this.type=W.U.Material,this.supportsEdges=!1,this._visible=!0,this._renderPriority=0,this._insertOrder=0,this._vertexAttributeLocations=V.i,this._parameters=(0,H.Uf)(K,Q),this.validateParameters(this._parameters)}dispose(){}get parameters(){return this._parameters}update(K){return!1}setParameters(K,Q=!0){(0,H.LO)(this._parameters,K)&&(this.validateParameters(this._parameters),Q&&this.parametersChanged())}validateParameters(K){}get visible(){return this._visible}set visible(K){K!==this._visible&&(this._visible=K,this.parametersChanged())}shouldRender(K){return this.isVisible()&&this.isVisibleForOutput(K.output)&&0!=(this.renderOccluded&K.renderOccludedMask)}isVisibleForOutput(K){return!0}get renderOccluded(){return this.parameters.renderOccluded}get renderPriority(){return this._renderPriority}set renderPriority(K){K!==this._renderPriority&&(this._renderPriority=K,this.parametersChanged())}get insertOrder(){return this._insertOrder}set insertOrder(K){K!==this._insertOrder&&(this._insertOrder=K,this.parametersChanged())}get vertexAttributeLocations(){return this._vertexAttributeLocations}isVisible(){return this._visible}parametersChanged(){(0,y.pC)(this.repository)&&this.repository.materialChanged(this)}}(j=A||(A={}))[j.Occlude=1]="Occlude",j[j.Transparent=2]="Transparent",j[j.OccludeAndTransparent=4]="OccludeAndTransparent",j[j.OccludeAndTransparentStencil=8]="OccludeAndTransparentStencil",j[j.Opaque=16]="Opaque"},88569:(fe,Y,v)=>{v.d(Y,{Bh:()=>Q,IB:()=>H,j7:()=>L,je:()=>K,ve:()=>S,wu:()=>W});var y=v(44835),w=v(67969),I=v(2078);const W=(0,I.wK)(w.zi.SRC_ALPHA,w.zi.ONE,w.zi.ONE_MINUS_SRC_ALPHA,w.zi.ONE_MINUS_SRC_ALPHA),V=(0,I.if)(w.zi.ONE,w.zi.ONE),H=(0,I.if)(w.zi.ZERO,w.zi.ONE_MINUS_SRC_ALPHA);function L(z){return z===y.A.FrontFace?null:z===y.A.Alpha?H:V}const S=5e5,j={factor:-1,units:-2};function K(z){return z?j:null}function Q(z,Z=w.wb.LESS){return z===y.A.NONE||z===y.A.FrontFace?Z:w.wb.LEQUAL}},12407:(fe,Y,v)=>{v.d(Y,{$:()=>V});var y=v(62208),w=v(77029),I=v(37847),W=v(81653);class V{constructor(L,A,S){this._context=L,this._locations=S,this._textures=new Map,this._freeTextureUnits=new w.Z({deallocator:null}),this._glProgram=L.programCache.acquire(A.generate("vertex"),A.generate("fragment"),S),this._glProgram.stop=()=>{throw new Error("Wrapped _glProgram used directly")},this.bindPass=A.generateBind(I.P.Pass,this),this.bindDraw=A.generateBind(I.P.Draw,this),this._fragmentUniforms=(0,W.hZ)()?A.fragmentUniforms:null}dispose(){this._glProgram.dispose()}get glName(){return this._glProgram.glName}get isCompiled(){return this._glProgram.isCompiled}setUniform1b(L,A){this._glProgram.setUniform1i(L,A?1:0)}setUniform1i(L,A){this._glProgram.setUniform1i(L,A)}setUniform1f(L,A){this._glProgram.setUniform1f(L,A)}setUniform2fv(L,A){this._glProgram.setUniform2fv(L,A)}setUniform3fv(L,A){this._glProgram.setUniform3fv(L,A)}setUniform4fv(L,A){this._glProgram.setUniform4fv(L,A)}setUniformMatrix3fv(L,A){this._glProgram.setUniformMatrix3fv(L,A)}setUniformMatrix4fv(L,A){this._glProgram.setUniformMatrix4fv(L,A)}setUniform1fv(L,A){this._glProgram.setUniform1fv(L,A)}setUniform1iv(L,A){this._glProgram.setUniform1iv(L,A)}setUniform2iv(L,A){this._glProgram.setUniform3iv(L,A)}setUniform3iv(L,A){this._glProgram.setUniform3iv(L,A)}setUniform4iv(L,A){this._glProgram.setUniform4iv(L,A)}assertCompatibleVertexAttributeLocations(L){L.locations!==this._locations&&console.error("VertexAttributeLocations are incompatible")}stop(){this._textures.clear(),this._freeTextureUnits.clear()}bindTexture(L,A){if((0,y.Wi)(A)||null==A.glName){const j=this._textures.get(L);return j&&(this._context.bindTexture(null,j.unit),this._freeTextureUnit(j),this._textures.delete(L)),null}let S=this._textures.get(L);return null==S?(S=this._allocTextureUnit(A),this._textures.set(L,S)):S.texture=A,this._context.useProgram(this),this.setUniform1i(L,S.unit),this._context.bindTexture(A,S.unit),S.unit}rebindTextures(){this._context.useProgram(this),this._textures.forEach((L,A)=>{this._context.bindTexture(L.texture,L.unit),this.setUniform1i(A,L.unit)}),(0,y.pC)(this._fragmentUniforms)&&this._fragmentUniforms.forEach(L=>{"sampler2D"!==L.type&&"samplerCube"!==L.type||this._textures.has(L.name)||console.error(`Texture sampler ${L.name} has no bound texture`)})}_allocTextureUnit(L){return{texture:L,unit:0===this._freeTextureUnits.length?this._textures.size:this._freeTextureUnits.pop()}}_freeTextureUnit(L){this._freeTextureUnits.push(L.unit)}}},44835:(fe,Y,v)=>{var y,w;v.d(Y,{A:()=>y}),(w=y||(y={}))[w.Color=0]="Color",w[w.Alpha=1]="Alpha",w[w.FrontFace=2]="FrontFace",w[w.NONE=3]="NONE",w[w.COUNT=4]="COUNT"},42743:(fe,Y,v)=>{var y,w,I,W,V,H,L,A,S,j,K,Q,z;v.d(Y,{CE:()=>S,Gv:()=>w,JJ:()=>K,MX:()=>A,Rw:()=>W,Vr:()=>y,hU:()=>V}),(z=y||(y={}))[z.None=0]="None",z[z.Front=1]="Front",z[z.Back=2]="Back",z[z.COUNT=3]="COUNT",function(z){z[z.Less=0]="Less",z[z.Lequal=1]="Lequal",z[z.COUNT=2]="COUNT"}(w||(w={})),function(z){z[z.BACKGROUND=0]="BACKGROUND",z[z.UPDATE=1]="UPDATE"}(I||(I={})),function(z){z[z.NOT_LOADED=0]="NOT_LOADED",z[z.LOADING=1]="LOADING",z[z.LOADED=2]="LOADED"}(W||(W={})),function(z){z[z.IntegratedMeshMaskExcluded=1]="IntegratedMeshMaskExcluded",z[z.OutlineVisualElementMask=2]="OutlineVisualElementMask"}(V||(V={})),function(z){z[z.ASYNC=0]="ASYNC",z[z.SYNC=1]="SYNC"}(H||(H={})),function(z){z[z.Highlight=0]="Highlight",z[z.MaskOccludee=1]="MaskOccludee",z[z.COUNT=2]="COUNT"}(L||(L={})),function(z){z[z.Triangle=0]="Triangle",z[z.Point=1]="Point",z[z.Line=2]="Line"}(A||(A={})),function(z){z[z.STRETCH=1]="STRETCH",z[z.PAD=2]="PAD"}(S||(S={})),function(z){z[z.CHANGED=0]="CHANGED",z[z.UNCHANGED=1]="UNCHANGED"}(j||(j={})),function(z){z[z.Blend=0]="Blend",z[z.Opaque=1]="Opaque",z[z.Mask=2]="Mask",z[z.MaskBlend=3]="MaskBlend",z[z.COUNT=4]="COUNT"}(K||(K={})),function(z){z[z.OFF=0]="OFF",z[z.ON=1]="ON"}(Q||(Q={}))},12155:(fe,Y,v)=>{v.d(Y,{ow:()=>te});var y=v(39114),w=v(16396),I=v(67969),W=v(40852);new W.G(w.T.POSITION,3,I.g.FLOAT,0,12),new W.G(w.T.POSITION,3,I.g.FLOAT,0,20),new W.G(w.T.UV0,2,I.g.FLOAT,12,20),new W.G(w.T.POSITION,3,I.g.FLOAT,0,32),new W.G(w.T.NORMAL,3,I.g.FLOAT,12,32),new W.G(w.T.UV0,2,I.g.FLOAT,24,32),new W.G(w.T.POSITION,3,I.g.FLOAT,0,16),new W.G(w.T.COLOR,4,I.g.UNSIGNED_BYTE,12,16);const S=[new W.G(w.T.POSITION,2,I.g.FLOAT,0,8)],j=[new W.G(w.T.POSITION,2,I.g.FLOAT,0,16),new W.G(w.T.UV0,2,I.g.FLOAT,8,16)];var K=v(49353);class Q extends K.U{}var z=v(83994);function te(de,le=S,ge=y.i,ve=-1,Ee=1){let Ce=null;return Ce=le===j?new Float32Array([ve,ve,0,0,Ee,ve,1,0,ve,Ee,0,1,Ee,Ee,1,1]):new Float32Array([ve,ve,Ee,ve,ve,Ee,Ee,Ee]),new Q(de,ge,{geometry:le},{geometry:z.f.createVertex(de,I.l1.STATIC_DRAW,Ce)})}v(55086)},50229:(fe,Y,v)=>{v.d(Y,{FZ:()=>Qe,Uf:()=>Se,Bw:()=>ct,LO:()=>Pe,Hx:()=>He});var y=v(85931),w=v(21286),I=v(62208),W=v(84161),V=v(28093),H=v(5548),L=v(42743);v(59617),(0,w.Vl)(10),(0,w.Vl)(12),(0,w.Vl)(70),(0,w.Vl)(40);const ge={scale:0,factor:0,minPixelSize:0,paddingPixels:0};var Ee=v(2282),Ce=v(16396),xe=(v(28347),v(43703));v(2757),new Float64Array(3),new Float32Array(6),(0,xe.c)();const ut=(0,H.Ue)();function ct(ne,oe,_e,re,Ae,et,tt){if(!function Je(ne){return!!(0,I.pC)(ne)&&!ne.visible}(oe))if(ne.boundingInfo)(0,Ee.hu)(ne.primitiveType===L.MX.Triangle),Oe(ne.boundingInfo,re,Ae,_e.tolerance,et,tt);else{const Xe=ne.indices.get(Ce.T.POSITION),rt=ne.vertexAttributes.get(Ce.T.POSITION);he(re,Ae,0,Xe.length/3,Xe,rt,void 0,et,tt)}}const se=(0,V.c)();function Oe(ne,oe,_e,re,Ae,et){if((0,I.Wi)(ne))return;const tt=function ye(ne,oe,_e){return(0,W.s)(_e,1/(oe[0]-ne[0]),1/(oe[1]-ne[1]),1/(oe[2]-ne[2]))}(oe,_e,se);if((0,H.op)(ut,ne.getBBMin()),(0,H.Tn)(ut,ne.getBBMax()),(0,I.pC)(Ae)&&Ae.applyToAabb(ut),function Me(ne,oe,_e,re){return function pe(ne,oe,_e,re,Ae){const et=(ne[0]-re-oe[0])*_e[0],tt=(ne[3]+re-oe[0])*_e[0];let Xe=Math.min(et,tt),rt=Math.max(et,tt);const Ge=(ne[1]-re-oe[1])*_e[1],dt=(ne[4]+re-oe[1])*_e[1];if(rt=Math.min(rt,Math.max(Ge,dt)),rt<0||(Xe=Math.max(Xe,Math.min(Ge,dt)),Xe>rt))return!1;const mt=(ne[2]-re-oe[2])*_e[2],ft=(ne[5]+re-oe[2])*_e[2];return rt=Math.min(rt,Math.max(mt,ft)),!(rt<0)&&(Xe=Math.max(Xe,Math.min(mt,ft)),!(Xe>rt)&&Xe<Ae)}(ne,oe,_e,re,1/0)}(ut,oe,tt,re)){const{primitiveIndices:Xe,indices:rt,position:Ge}=ne,dt=Xe?Xe.length:rt.length/3;if(dt>Jt){const mt=ne.getChildren();if(void 0!==mt){for(let ft=0;ft<8;++ft)void 0!==mt[ft]&&Oe(mt[ft],oe,_e,re,Ae,et);return}}he(oe,_e,0,dt,rt,Ge,Xe,Ae,et)}}const Tt=(0,V.c)();function he(ne,oe,_e,re,Ae,et,tt,Xe,rt){if(tt)return function ze(ne,oe,_e,re,Ae,et,tt,Xe,rt){const Ge=et.data,dt=et.stride||et.size,mt=ne[0],ft=ne[1],Ht=ne[2],Ot=oe[0]-mt,Ct=oe[1]-ft,Ut=oe[2]-Ht;for(let xt=_e;xt<re;++xt){const jt=tt[xt];let gt=3*jt,vt=dt*Ae[gt++],Dt=Ge[vt++],yt=Ge[vt++],St=Ge[vt];vt=dt*Ae[gt++];let bt=Ge[vt++],be=Ge[vt++],Lt=Ge[vt];vt=dt*Ae[gt];let er=Ge[vt++],Pt=Ge[vt++],Wt=Ge[vt];(0,I.pC)(Xe)&&([Dt,yt,St]=Xe.applyToVertex(Dt,yt,St,xt),[bt,be,Lt]=Xe.applyToVertex(bt,be,Lt,xt),[er,Pt,Wt]=Xe.applyToVertex(er,Pt,Wt,xt));const Gt=bt-Dt,zt=be-yt,Xt=Lt-St,Yt=er-Dt,Kt=Pt-yt,tr=Wt-St,ar=Ct*tr-Kt*Ut,lr=Ut*Yt-tr*Ot,wt=Ot*Kt-Yt*Ct,Bt=Gt*ar+zt*lr+Xt*wt;if(Math.abs(Bt)<=Number.EPSILON)continue;const Zt=mt-Dt,rr=ft-yt,Rt=Ht-St,Qt=Zt*ar+rr*lr+Rt*wt;if(Bt>0){if(Qt<0||Qt>Bt)continue}else if(Qt>0||Qt<Bt)continue;const cr=rr*Xt-zt*Rt,dr=Rt*Gt-Xt*Zt,kt=Zt*zt-Gt*rr,ir=Ot*cr+Ct*dr+Ut*kt;if(Bt>0){if(ir<0||Qt+ir>Bt)continue}else if(ir>0||Qt+ir<Bt)continue;const Mr=(Yt*cr+Kt*dr+tr*kt)/Bt;Mr>=0&&rt(Mr,qt(Gt,zt,Xt,Yt,Kt,tr,Tt),jt,!1)}}(ne,oe,_e,re,Ae,et,tt,Xe,rt);const Ge=et.data,dt=et.stride||et.size,mt=ne[0],ft=ne[1],Ht=ne[2],Ot=oe[0]-mt,Ct=oe[1]-ft,Ut=oe[2]-Ht;for(let xt=_e,jt=3*_e;xt<re;++xt){let gt=dt*Ae[jt++],vt=Ge[gt++],Dt=Ge[gt++],yt=Ge[gt];gt=dt*Ae[jt++];let St=Ge[gt++],bt=Ge[gt++],be=Ge[gt];gt=dt*Ae[jt++];let Lt=Ge[gt++],er=Ge[gt++],Pt=Ge[gt];(0,I.pC)(Xe)&&([vt,Dt,yt]=Xe.applyToVertex(vt,Dt,yt,xt),[St,bt,be]=Xe.applyToVertex(St,bt,be,xt),[Lt,er,Pt]=Xe.applyToVertex(Lt,er,Pt,xt));const Wt=St-vt,Gt=bt-Dt,zt=be-yt,Xt=Lt-vt,Yt=er-Dt,Kt=Pt-yt,tr=Ct*Kt-Yt*Ut,ar=Ut*Xt-Kt*Ot,lr=Ot*Yt-Xt*Ct,wt=Wt*tr+Gt*ar+zt*lr;if(Math.abs(wt)<=Number.EPSILON)continue;const Bt=mt-vt,Zt=ft-Dt,rr=Ht-yt,Rt=Bt*tr+Zt*ar+rr*lr;if(wt>0){if(Rt<0||Rt>wt)continue}else if(Rt>0||Rt<wt)continue;const Qt=Zt*zt-Gt*rr,cr=rr*Wt-zt*Bt,dr=Bt*Gt-Wt*Zt,kt=Ot*Qt+Ct*cr+Ut*dr;if(wt>0){if(kt<0||Rt+kt>wt)continue}else if(kt>0||Rt+kt<wt)continue;const ir=(Xt*Qt+Yt*cr+Kt*dr)/wt;ir>=0&&rt(ir,qt(Wt,Gt,zt,Xt,Yt,Kt,Tt),xt,!1)}}const It=(0,V.c)(),ht=(0,V.c)();function qt(ne,oe,_e,re,Ae,et,tt){return(0,W.s)(It,ne,oe,_e),(0,W.s)(ht,re,Ae,et),(0,W.f)(tt,It,ht),(0,W.n)(tt,tt),tt}function He(ne,oe,_e,re,Ae){let et=(_e.screenLength||0)*ne.pixelRatio;(0,I.pC)(Ae)&&(et=function k(ne,oe,_e,re){return function Z(ne,oe){return Math.max((0,w.t7)(ne*oe.scale,ne,oe.factor),function z(ne,oe){return 0===ne?oe.minPixelSize:oe.minPixelSize*(1+2*oe.paddingPixels/ne)}(ne,oe))}(ne,function Q(ne,oe,_e){const re=_e.parameters,Ae=_e.paddingPixelsOverride;return ge.scale=Math.min(re.divisor/(oe-re.offset),1),ge.factor=function K(ne){return Math.abs(ne*ne*ne)}(ne),ge.minPixelSize=re.minPixelSize,ge.paddingPixels=Ae,ge}(oe,_e,re))}(et,re,oe,Ae));const tt=et*Math.tan(.5*ne.fovY)/(.5*ne.fullHeight);return(0,w.uZ)(tt*oe,_e.minWorldLength||0,null!=_e.maxWorldLength?_e.maxWorldLength:1/0)}function Se(ne,oe){const _e=oe?Se(oe):{};for(const re in ne){let Ae=ne[re];Ae&&Ae.forEach&&(Ae=hr(Ae)),null==Ae&&re in _e||(_e[re]=Ae)}return _e}function Pe(ne,oe){let _e=!1;for(const re in oe){const Ae=oe[re];void 0!==Ae&&(Array.isArray(Ae)?null===ne[re]?(ne[re]=Ae.slice(),_e=!0):(0,y.Vx)(ne[re],Ae)&&(_e=!0):ne[re]!==Ae&&(_e=!0,ne[re]=Ae))}return _e}function hr(ne){const oe=[];return ne.forEach(_e=>oe.push(_e)),oe}const Qe={multiply:1,ignore:2,replace:3,tint:4},Jt=1e3},40852:(fe,Y,v)=>{v.d(Y,{G:()=>y});class y{constructor(I,W,V,H,L,A=!1,S=0){this.name=I,this.count=W,this.type=V,this.offset=H,this.stride=L,this.normalized=A,this.divisor=S}}},57596:(fe,Y,v)=>{v.d(Y,{Sh:()=>V,kr:()=>L,sj:()=>W,zO:()=>I});var I,K,y=v(8314),w=v(62208);function W(K,Q,z={}){const Z=V(K);for(;Z.length>1;){const te=L(Q,Z.shift(),z);if((0,w.pC)(te))return te}return function H(K,Q,z={}){if(!window.WebGLRenderingContext)return A(K,S),null;const Z=L(K,Q,z);return(0,w.Wi)(Z)&&A(K,j),Z}(Q,Z.shift(),z)}function V(K){const Q=(0,y.Z)("esri-force-webgl");if(Q===I.WEBGL1||Q===I.WEBGL2)return[Q];switch(K){case"2d":return(0,y.Z)("mac")&&(0,y.Z)("chrome")?[I.WEBGL1,I.WEBGL2]:[I.WEBGL2,I.WEBGL1];case"3d":return[I.WEBGL2,I.WEBGL1]}}function L(K,Q,z={}){const Z=Q===I.WEBGL1?["webgl","experimental-webgl","webkit-3d","moz-webgl"]:["webgl2"];let te=null;for(const q of Z){try{te=K.getContext(q,z)}catch($){}if(te)break}return te}function A(K,Q){const z=K.parentNode;z&&(z.innerHTML='<table style="background-color: #8CE; width: 100%; height: 100%;"><tr><td align="center"><div style="display: table-cell; vertical-align: middle;"><div style="">'+Q+"</div></div></td></tr></table>")}(K=I||(I={}))[K.WEBGL1=1]="WEBGL1",K[K.WEBGL2=2]="WEBGL2";const S='This page requires a browser that supports WebGL.<br/><a href="http://get.webgl.org">Click here to upgrade your browser.</a>',j='It doesn\'t appear your computer can support WebGL.<br/><a href="http://get.webgl.org/troubleshooting/">Click here for more information.</a>'},2757:(fe,Y,v)=>{function y(H,L,A){for(let S=0;S<A;++S)L[2*S]=H[S],L[2*S+1]=H[S]-L[2*S]}function I(H,L){const A=H.length;for(let S=0;S<A;++S)V[0]=H[S],L[S]=V[0];return L}function W(H,L){const A=H.length;for(let S=0;S<A;++S)V[0]=H[S],V[1]=H[S]-V[0],L[S]=V[1];return L}v.d(Y,{GB:()=>W,LF:()=>y,U8:()=>I});const V=new Float32Array(2)},2078:(fe,Y,v)=>{v.d(Y,{BK:()=>S,LZ:()=>A,if:()=>I,jp:()=>ct,sm:()=>k,wK:()=>W,zp:()=>L});var y=v(42743),w=v(67969);function I(se,Oe,Tt=w.db.ADD,he=[0,0,0,0]){return{srcRgb:se,srcAlpha:se,dstRgb:Oe,dstAlpha:Oe,opRgb:Tt,opAlpha:Tt,color:{r:he[0],g:he[1],b:he[2],a:he[3]}}}function W(se,Oe,Tt,he,ze=w.db.ADD,It=w.db.ADD,ht=[0,0,0,0]){return{srcRgb:se,srcAlpha:Oe,dstRgb:Tt,dstAlpha:he,opRgb:ze,opAlpha:It,color:{r:ht[0],g:ht[1],b:ht[2],a:ht[3]}}}const V={face:w.LR.BACK,mode:w.Wf.CCW},H={face:w.LR.FRONT,mode:w.Wf.CCW},L=se=>se===y.Vr.Back?V:se===y.Vr.Front?H:null,A={zNear:0,zFar:1},S={r:!0,g:!0,b:!0,a:!0};function j(se){return de.intern(se)}function K(se){return ge.intern(se)}function Q(se){return Ee.intern(se)}function z(se){return at.intern(se)}function Z(se){return ue.intern(se)}function te(se){return Ke.intern(se)}function q(se){return ke.intern(se)}function $(se){return Be.intern(se)}function k(se){return Ne.intern(se)}class J{constructor(Oe,Tt){this._makeKey=Oe,this._makeRef=Tt,this._interns=new Map}intern(Oe){var Tt;if(!Oe)return null;const he=this._makeKey(Oe),ze=this._interns;return ze.has(he)||ze.set(he,this._makeRef(Oe)),null!==(Tt=ze.get(he))&&void 0!==Tt?Tt:null}}function ie(se){return"["+se.join(",")+"]"}const de=new J(le,se=>({__tag:"Blending",...se}));function le(se){return se?ie([se.srcRgb,se.srcAlpha,se.dstRgb,se.dstAlpha,se.opRgb,se.opAlpha,se.color.r,se.color.g,se.color.b,se.color.a]):null}const ge=new J(ve,se=>({__tag:"Culling",...se}));function ve(se){return se?ie([se.face,se.mode]):null}const Ee=new J(Ce,se=>({__tag:"PolygonOffset",...se}));function Ce(se){return se?ie([se.factor,se.units]):null}const at=new J(xe,se=>({__tag:"DepthTest",...se}));function xe(se){return se?ie([se.func]):null}const ue=new J(ce,se=>({__tag:"StencilTest",...se}));function ce(se){return se?ie([se.function.func,se.function.ref,se.function.mask,se.operation.fail,se.operation.zFail,se.operation.zPass]):null}const Ke=new J(Je,se=>({__tag:"DepthWrite",...se}));function Je(se){return se?ie([se.zNear,se.zFar]):null}const ke=new J(st,se=>({__tag:"ColorWrite",...se}));function st(se){return se?ie([se.r,se.g,se.b,se.a]):null}const Be=new J(me,se=>({__tag:"StencilWrite",...se}));function me(se){return se?ie([se.mask]):null}const Ne=new J(function ut(se){return se?ie([le(se.blending),ve(se.culling),Ce(se.polygonOffset),xe(se.depthTest),ce(se.stencilTest),Je(se.depthWrite),st(se.colorWrite),me(se.stencilWrite)]):null},se=>({blending:j(se.blending),culling:K(se.culling),polygonOffset:Q(se.polygonOffset),depthTest:z(se.depthTest),stencilTest:Z(se.stencilTest),depthWrite:te(se.depthWrite),colorWrite:q(se.colorWrite),stencilWrite:$(se.stencilWrite)}));class ct{constructor(Oe){this._pipelineInvalid=!0,this._blendingInvalid=!0,this._cullingInvalid=!0,this._polygonOffsetInvalid=!0,this._depthTestInvalid=!0,this._stencilTestInvalid=!0,this._depthWriteInvalid=!0,this._colorWriteInvalid=!0,this._stencilWriteInvalid=!0,this._stateSetters=Oe}setPipeline(Oe){(this._pipelineInvalid||Oe!==this._pipeline)&&(this._setBlending(Oe.blending),this._setCulling(Oe.culling),this._setPolygonOffset(Oe.polygonOffset),this._setDepthTest(Oe.depthTest),this._setStencilTest(Oe.stencilTest),this._setDepthWrite(Oe.depthWrite),this._setColorWrite(Oe.colorWrite),this._setStencilWrite(Oe.stencilWrite),this._pipeline=Oe),this._pipelineInvalid=!1}invalidateBlending(){this._blendingInvalid=!0,this._pipelineInvalid=!0}invalidateCulling(){this._cullingInvalid=!0,this._pipelineInvalid=!0}invalidatePolygonOffset(){this._polygonOffsetInvalid=!0,this._pipelineInvalid=!0}invalidateDepthTest(){this._depthTestInvalid=!0,this._pipelineInvalid=!0}invalidateStencilTest(){this._stencilTestInvalid=!0,this._pipelineInvalid=!0}invalidateDepthWrite(){this._depthWriteInvalid=!0,this._pipelineInvalid=!0}invalidateColorWrite(){this._colorWriteInvalid=!0,this._pipelineInvalid=!0}invalidateStencilWrite(){this._stencilTestInvalid=!0,this._pipelineInvalid=!0}_setBlending(Oe){this._blending=this._setSubState(Oe,this._blending,this._blendingInvalid,this._stateSetters.setBlending),this._blendingInvalid=!1}_setCulling(Oe){this._culling=this._setSubState(Oe,this._culling,this._cullingInvalid,this._stateSetters.setCulling),this._cullingInvalid=!1}_setPolygonOffset(Oe){this._polygonOffset=this._setSubState(Oe,this._polygonOffset,this._polygonOffsetInvalid,this._stateSetters.setPolygonOffset),this._polygonOffsetInvalid=!1}_setDepthTest(Oe){this._depthTest=this._setSubState(Oe,this._depthTest,this._depthTestInvalid,this._stateSetters.setDepthTest),this._depthTestInvalid=!1}_setStencilTest(Oe){this._stencilTest=this._setSubState(Oe,this._stencilTest,this._stencilTestInvalid,this._stateSetters.setStencilTest),this._stencilTestInvalid=!1}_setDepthWrite(Oe){this._depthWrite=this._setSubState(Oe,this._depthWrite,this._depthWriteInvalid,this._stateSetters.setDepthWrite),this._depthWriteInvalid=!1}_setColorWrite(Oe){this._colorWrite=this._setSubState(Oe,this._colorWrite,this._colorWriteInvalid,this._stateSetters.setColorWrite),this._colorWriteInvalid=!1}_setStencilWrite(Oe){this._stencilWrite=this._setSubState(Oe,this._stencilWrite,this._stencilWriteInvalid,this._stateSetters.setStencilWrite),this._stencilTestInvalid=!1}_setSubState(Oe,Tt,he,ze){return(he||Oe!==Tt)&&(ze(Oe),this._pipelineInvalid=!0),Oe}}}}]);