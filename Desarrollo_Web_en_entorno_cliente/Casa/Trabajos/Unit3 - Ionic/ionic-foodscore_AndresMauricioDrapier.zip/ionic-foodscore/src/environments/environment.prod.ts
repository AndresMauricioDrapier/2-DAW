export const environment = {
  production: true,
  baseUrl: 'http://arturober.com:5010'
};
