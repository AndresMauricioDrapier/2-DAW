export interface Usuario {
  login: string;
  password: string;
}
