import { Body, Controller, Get, Post, Req, Res, Session } from '@nestjs/common';
import { UsuarioDto } from './dto/usuario-dto/usuario-dto';
import { UsuarioService } from './usuario.service';

@Controller('auth')
export class UsuarioController {
  constructor(private readonly usuarioService: UsuarioService) {}

  //GET /auth
  @Get()
  async listar(@Res() res) {
    return res.redirect('/auth/login');
  }

  // GET /auth/login
  @Get('/login')
  async llevarForm(@Res() res) {
    return res.render('public/iniciarSesion');
  }

  // POST /auth
  @Post()
  async crear(
    @Body() crearUsuarioDto: UsuarioDto,
    @Res() res,
    @Session() session,
    @Req() req,
  ) {
    this.usuarioService
      .login()
      .then((users) => {
        users.filter((user) => {
          if (
            user.login === crearUsuarioDto.login &&
            user.password === crearUsuarioDto.password
          ) {
            console.log(user, 'hola');
            session.set('usuario', user);
            // console.log(session.get('usuario'));
          }
        });
      })
      .catch((e) => {
        return res.render('public/error', { error: e });
        return res.redirect('/auth/login');
      });
  }

  // POST /auth  !PARA REGISTRARME DE PRUEBA
  // @Post()
  // async crear(
  //   @Body() crearUsuarioDto: UsuarioDto,
  //   @Res() res,
  //   @Session() session,
  // ) {
  //   this.usuarioService
  //     .insertar(crearUsuarioDto)
  //     .then((juego) => {
  //       if (juego) return res.redirect('/');
  //       else {
  //         throw new Error();
  //       }
  //     })
  //     .catch((error) => {
  //       return res.render('public/error', { error: error });
  //     });
  // }
}
