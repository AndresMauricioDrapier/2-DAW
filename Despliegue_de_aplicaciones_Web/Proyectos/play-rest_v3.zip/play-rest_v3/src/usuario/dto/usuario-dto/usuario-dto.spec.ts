import { UsuarioDto } from './usuario-dto';

describe('UsuarioDto', () => {
  it('should be defined', () => {
    expect(new UsuarioDto()).toBeDefined();
  });
});
