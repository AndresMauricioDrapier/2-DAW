import { JuegoDto } from './juego-dto';

describe('JuegoDto', () => {
  it('should be defined', () => {
    expect(new JuegoDto()).toBeDefined();
  });
});
